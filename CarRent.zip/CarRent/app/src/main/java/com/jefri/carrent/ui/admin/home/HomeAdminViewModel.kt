package com.jefri.carrent.ui.admin.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.model.User
import com.jefri.carrent.data.repository.AdminRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch
import java.util.Calendar

class HomeAdminViewModel(
    private val adminRepository: AdminRepository,
) : ViewModel() {

    private val _orderData = MutableLiveData<Result<List<Order>>>()
    val orderData: LiveData<Result<List<Order>>> get() = _orderData

    private val _mitraData = MutableLiveData<Result<List<User>>>()
    val mitraData: LiveData<Result<List<User>>> get() = _mitraData

    private val _user = MutableLiveData<Result<User?>>()
    val user: LiveData<Result<User?>>
        get() = _user

    private val listStatus = listOf("belum_dibayar", "menunggu_konfirmasi_admin")

    private val _isRefreshing = MediatorLiveData<Boolean>().apply { value = false }
    val isRefreshing: LiveData<Boolean> get() = _isRefreshing

    init {
        _isRefreshing.addSource(_orderData) { updateRefreshing() }
        _isRefreshing.addSource(_mitraData) { updateRefreshing() }

        getUserData()
        getOrderWaitingConfirmationData()
        getMitraInactiveData()
    }

    fun getOrderWaitingConfirmationData() {
        viewModelScope.launch {
            _orderData.value = Result.Loading
            val result = adminRepository.getOrdersData(
                status = listStatus
            )
            _orderData.value = result
        }
    }

    fun getMitraInactiveData() {
        viewModelScope.launch {
            _mitraData.value = Result.Loading
            val result = adminRepository.getMitraInactiveData()
            _mitraData.value = result
        }
    }

    fun getUserData() {
        _user.value = Result.Loading

        viewModelScope.launch {
            try {
                _user.value = Result.Success(adminRepository.getUserDataFromFirestore())
            } catch (e: Exception) {
                _user.value = Result.Error(e.message.toString())
            }
        }
    }

    private fun updateRefreshing() {
        val loadingOrder  = _orderData.value is Result.Loading
        val loadingMuatan = _mitraData.value is Result.Loading

        _isRefreshing.value = loadingOrder || loadingMuatan
    }

    fun refreshAll() {
        getOrderWaitingConfirmationData()
        getMitraInactiveData()
    }

    fun getGreetingText(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 4..10 -> "Selamat Pagi,"
            in 11..14 -> "Selamat Siang,"
            in 15..17 -> "Selamat Sore,"
            else -> "Selamat Malam,"
        }
    }
}