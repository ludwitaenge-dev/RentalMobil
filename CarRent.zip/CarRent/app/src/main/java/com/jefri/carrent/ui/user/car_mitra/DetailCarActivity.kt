package com.jefri.carrent.ui.user.car_mitra

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.bumptech.glide.Glide
import com.jefri.carrent.R
import com.jefri.carrent.data.model.Mobil
import com.jefri.carrent.databinding.ActivityDetailCarBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.user.add_transaction.add_data.AddTransactionDataActivity
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.ext.toAvatarInitial
import com.jefri.carrent.utils.ext.toRupiah
import kotlin.getValue
import com.jefri.carrent.utils.result.Result

class DetailCarActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailCarBinding

    private val viewModel by viewModels<CarMitraViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private lateinit var mobilId: String
    private lateinit var mobil: Mobil

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        binding = ActivityDetailCarBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
    }

    private fun init() {
        receiveExtraMobilId()
        getDetailMobilData()
        setupBtnListener()
    }

    private fun getDetailMobilData() {
        viewModel.getDetailMobilDataById(mobilId)
        viewModel.detailMobilData.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.progressBar.show()
                    }
                    is Result.Success -> {
                        binding.progressBar.hide()
                        val data = result.data
                        mobil = data
                        setupMobilData(data)
                    }
                    is Result.Error -> {
                        binding.progressBar.hide()
                        showToast(result.message)
                    }
                }
            }
        }
    }

    private fun setupMobilData(mobil: Mobil) {
        with (binding) {
            Glide.with(this@DetailCarActivity)
                .load(mobil.fotoUrl)
                .centerCrop()
                .into(ivMobil)

            tvNamaMobil.text = "Mobil ${mobil.merk} ${mobil.model}"
            tvMitraName.text = mobil.mitraName
            tvRating.text = mobil.averageRating.toString()
            tvAvatar.text = mobil.mitraName.toAvatarInitial()

            // Spesifikasi
            tvMerk.text = mobil.merk
            tvModel.text = mobil.model
            tvTahun.text = mobil.tahun
            tvWarna.text = mobil.warna
            tvPlat.text = mobil.platNomor
            tvHarga.text = mobil.hargaPerHari.toRupiah()
        }
    }

    private fun setupBtnListener() {
        with (binding) {
            btnPesan.setOnClickListener {
                val intent = Intent(this@DetailCarActivity, AddTransactionDataActivity::class.java)
                intent.putExtra(AddTransactionDataActivity.EXTRA_MOBIL, mobil)
                startActivity(intent)
            }

            ivBack.setOnClickListener {
                finish()
            }
        }
    }

    private fun receiveExtraMobilId() {
        mobilId = intent.getStringExtra(EXTRA_MOBIL_ID) ?: ""
    }

    companion object {
        const val EXTRA_MOBIL_ID = "extra_mobil_id"
    }
}