package com.jefri.carrent.ui.user.add_transaction.add_data

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.PaymentMethod
import com.jefri.carrent.data.model.User
import com.jefri.carrent.data.repository.UserRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch

class AddTransactionViewModel(
    private val userReposistory: UserRepository,
) : ViewModel() {

    private val _user = MutableLiveData<Result<User?>>()
    val user: LiveData<Result<User?>>
        get() = _user

    private val _paymentMethods = MutableLiveData<Result<List<PaymentMethod>>>()
    val paymentMethods: LiveData<Result<List<PaymentMethod>>> = _paymentMethods

    init {
        getUserData()
    }

    fun getUserData() {
        _user.value = Result.Loading

        viewModelScope.launch {
            try {
                _user.value = Result.Success(userReposistory.getUserDataFromFirestore())
            } catch (e: Exception) {
                _user.value = Result.Error(e.message.toString())
            }
        }
    }

    fun getPaymentMethods() {
        _paymentMethods.value = Result.Loading
        viewModelScope.launch {
            _paymentMethods.value = userReposistory.getPaymentMethods()
        }
    }
}