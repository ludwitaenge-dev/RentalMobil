package com.jefri.carrent.ui.user.add_transaction.overview

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.jefri.carrent.R
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.databinding.ActivityOverviewTransactionBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.user.MainActivity
import com.jefri.carrent.ui.user.add_transaction.payment.PaymentActivity
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.ext.toRupiah
import com.jefri.carrent.utils.helpers.DateHelper
import com.jefri.carrent.utils.result.Result

class OverviewTransactionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOverviewTransactionBinding
    private val viewModel by viewModels<OverviewTransactionViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private var nama: String? = null
    private var noTelp: String? = null
    private var rawOrder: Order? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        binding = ActivityOverviewTransactionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
    }

    private fun init() {
        setupBtnListener()
        receiveExtra()
        setupData()
        observeStateAddOrder()
    }

    private fun setupData() {
        with(binding) {
            tvName.text = nama
            tvNotel.text = noTelp
            tvAddress.text = rawOrder?.address
            tvDate.text = rawOrder?.date
            tvMerkMobil.text = rawOrder?.mobil?.merk

            val hargaPerHari = rawOrder?.mobil?.hargaPerHari
            val totalHari = DateHelper.getTotalDaysFromRange(rawOrder?.date)

            tvHarga.text = hargaPerHari?.toRupiah()
            tvTotalHari.text = DateHelper.getTotalDaysFromRange(rawOrder?.date).toString()
            tvTotal.text = (hargaPerHari?.times(totalHari))?.toRupiah()
            tvMetodePembayaran.text = rawOrder?.metodePembayaran
        }
    }

    private fun observeStateAddOrder() {
        viewModel.addOrderResult.observe(this) { result ->
            when (result) {
                is Result.Loading -> {
                    binding.btnNext.setLoading(true)
                }

                is Result.Success -> {
                    binding.btnNext.setLoading(false)
                    val intent = Intent(this, MainActivity::class.java).apply {
                        putExtra("openPayment", true)
                        putExtra(PaymentActivity.EXTRA_ORDER_ID, result.data)
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    finish()
                }

                is Result.Error -> {
                    binding.btnNext.setLoading(false)
                    showToast("Gagal membuat order: ${result.message}")
                }
            }
        }
    }

    private fun setupBtnListener() {
        with(binding) {
            btnNext.setOnClickListener {
                val order = generateOrder()
                viewModel.addOrder(
                    order,
                    nama = nama.toString(),
                    noTelp = noTelp.toString(),
                    alamat = order.address
                )
            }

            ivBack.setOnClickListener {
                finish()
            }
        }
    }

    private fun receiveExtra() {
        nama = intent.getStringExtra("nama").toString()
        noTelp = intent.getStringExtra("noTel").toString()

        rawOrder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("order", Order::class.java)
        } else {
            intent.getParcelableExtra<Order>("order")
        }
    }

    private fun generateOrder(): Order {
        val copyUser = rawOrder?.user?.copy()
        copyUser?.let {
            it.name = nama.toString()
            it.noTelp = noTelp.toString()
            it.alamat = rawOrder?.address.toString()
        }

        return Order(
            code = rawOrder?.code.toString(),
            address = rawOrder?.address.toString(),
            date = rawOrder?.date.toString(),
            mobil = rawOrder?.mobil,
            metodePembayaran = rawOrder?.metodePembayaran.toString(),
            nomorPembayaran = rawOrder?.nomorPembayaran.toString(),
            status = rawOrder?.status.toString(),
            user = copyUser,
        )
    }
}