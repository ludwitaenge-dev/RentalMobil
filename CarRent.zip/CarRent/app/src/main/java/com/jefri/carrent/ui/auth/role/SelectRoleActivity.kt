// Mendefinisikan package lokasi file SelectRoleActivity
package com.jefri.carrent.ui.auth.role

// Import Intent untuk berpindah antar Activity
import android.content.Intent
// Import Bundle untuk menyimpan state Activity
import android.os.Bundle
// Import enableEdgeToEdge untuk tampilan full layar hingga ke sistem bar
import androidx.activity.enableEdgeToEdge
// Import AppCompatActivity sebagai superclass Activity
import androidx.appcompat.app.AppCompatActivity
// Import ViewCompat untuk kompatibilitas pengaturan tampilan
import androidx.core.view.ViewCompat
// Import WindowInsetsCompat untuk mengatur padding sesuai system bars (status bar/navigation bar)
import androidx.core.view.WindowInsetsCompat
// Import ViewBinding untuk layout ActivitySelectRole
import com.jefri.carrent.databinding.ActivitySelectRoleBinding
// Import LoginActivity sebagai tujuan setelah memilih role
import com.jefri.carrent.ui.auth.login.LoginActivity

// Mendeklarasikan class SelectRoleActivity yang mewarisi AppCompatActivity
class SelectRoleActivity : AppCompatActivity() {

    // Deklarasi variabel binding untuk mengakses komponen layout
    private lateinit var binding: ActivitySelectRoleBinding

    // Fungsi pertama yang dipanggil saat Activity dibuat
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) // Memanggil onCreate milik superclass
        
        enableEdgeToEdge() // Mengaktifkan tampilan edge-to-edge (layout sampai ke tepi layar)
        
        // Menghubungkan binding dengan layout XML
        binding = ActivitySelectRoleBinding.inflate(layoutInflater)
        
        // Menampilkan layout ke layar
        setContentView(binding.root)

        // Mengatur agar layout menyesuaikan padding dengan system bars
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            
            // Mengambil ukuran inset dari system bars (status bar & navigation bar)
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            
            // Mengatur padding view agar tidak tertutup system bars
            v.setPadding(
                v.paddingLeft + systemBars.left,
                v.paddingTop + systemBars.top,
                v.paddingRight + systemBars.right,
                v.paddingBottom + systemBars.bottom
            )
            insets // Mengembalikan nilai insets
        }

        // Memanggil fungsi untuk mengatur aksi tombol
        setupBtnListener()
    }

    // Fungsi untuk mengatur aksi komponen pada layout
    private fun setupBtnListener() {
        
        // Menggunakan scope function with untuk mempermudah akses binding
        with (binding) {
            
            // Menonaktifkan tombol Next secara default
            btnNext.enable(false)

            // Listener ketika RadioButton dalam RadioGroup berubah
            radioGroupRole.setOnCheckedChangeListener { _, checkedId ->
                
                // Tombol aktif jika ada role yang dipilih
                val isEnabled = checkedId != -1
                
                // Mengaktifkan atau menonaktifkan tombol Next
                btnNext.enable(isEnabled)
            }

            // Listener ketika tombol Next diklik
            btnNext.setOnClickListener {
                
                // Menentukan role berdasarkan RadioButton yang dipilih
                val selectedRole = when (radioGroupRole.checkedRadioButtonId) {
                    rbAdmin.id -> "admin"
                    rbMitra.id -> "mitra"
                    rbUser.id -> "user"
                    else -> "user" // Default role jika tidak terdeteksi
                }

                // Membuat intent menuju LoginActivity
                val intentToLogin = Intent(this@SelectRoleActivity, LoginActivity::class.java)
                
                // Mengirim data role ke LoginActivity
                intentToLogin.putExtra("role", selectedRole)
                
                // Menjalankan LoginActivity
                startActivity(intentToLogin)
            }
        }
    }
}