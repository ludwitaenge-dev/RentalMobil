package com.jefri.carrent.utils.ext

import android.widget.TextView
import androidx.core.content.ContextCompat
import com.jefri.carrent.R

fun TextView.setStatusStyle(status: String?) {
    val ctx = this.context
    when (status?.lowercase()) {
        "belum_dibayar" -> {
            setBackgroundResource(R.drawable.bg_status_yellow)
            setTextColor(ContextCompat.getColor(ctx, R.color.status_yellow_dark))
        }

        "menunggu_konfirmasi_admin",
        "menunggu_konfirmasi_mitra" -> {
            setBackgroundResource(R.drawable.bg_status_blue)
            setTextColor(ContextCompat.getColor(ctx, R.color.status_blue_dark))
        }

        "diproses" -> {
            setBackgroundResource(R.drawable.bg_status_orange)
            setTextColor(ContextCompat.getColor(ctx, R.color.status_orange_dark))
        }

        "selesai" -> {
            setBackgroundResource(R.drawable.bg_status_green)
            setTextColor(ContextCompat.getColor(ctx, R.color.status_green_dark))
        }

        else -> {
            setBackgroundResource(R.drawable.bg_status_gray)
            setTextColor(ContextCompat.getColor(ctx, R.color.gray_dark))
        }
    }
}