package com.jefri.carrent.utils.ext

fun String.toReadableStatus(): String {
    return this.split("_")
        .joinToString(" ") { word ->
            word.replaceFirstChar {
                it.uppercase()
            }
        }
}

fun String.toAvatarInitial(): String {
    if (this.isBlank()) return "--"

    val parts = this.trim().split("\\s+".toRegex()).filter { it.isNotEmpty() }

    return when (parts.size) {
        1 -> {
            val first = parts[0].take(1).uppercase()
            val second = if (parts[0].length > 1) parts[0][1].toString().uppercase() else first
            "$first$second"
        }
        2 -> {
            "${parts[0].first().uppercase()}${parts[1].first().uppercase()}"
        }
        else -> {
            "${parts.first().first().uppercase()}${parts.last().first().uppercase()}"
        }
    }
}