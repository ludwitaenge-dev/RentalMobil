package com.jefri.carrent.custom_ui.bottom_sheet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.jefri.carrent.data.model.PaymentMethod
import com.jefri.carrent.databinding.BottomsheetPaymentMethodBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.admin.settings.PaymentMethodAdapter
import com.jefri.carrent.ui.user.add_transaction.add_data.AddTransactionViewModel
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.result.Result

class PaymentMethodBottomSheet(
    private val onSelected: (PaymentMethod) -> Unit
) : BottomSheetDialogFragment() {

    private var _binding: BottomsheetPaymentMethodBinding? = null
    private val binding get() = _binding!!

    private val viewModel by viewModels<AddTransactionViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    private lateinit var adapter: PaymentMethodAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomsheetPaymentMethodBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        observeViewModel()

        viewModel.getPaymentMethods()

        binding.btnReset.setOnClickListener {
            dismiss()
        }
    }

    private fun setupRecyclerView() {
        adapter = PaymentMethodAdapter { paymentMethod ->
            onSelected(paymentMethod)
            dismiss()
        }
        binding.rvMethods.adapter = adapter
    }

    private fun observeViewModel() {
        viewModel.paymentMethods.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {
                    binding.progressBar.show()
                }
                is Result.Success -> {
                    binding.progressBar.hide()
                    adapter.submitList(result.data)
                }
                is Result.Error -> {
                    binding.progressBar.hide()
                    showToast(result.message)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}