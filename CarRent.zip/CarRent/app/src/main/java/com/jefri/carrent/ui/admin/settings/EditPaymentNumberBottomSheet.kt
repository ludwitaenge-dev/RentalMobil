package com.jefri.carrent.ui.admin.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.jefri.carrent.data.model.PaymentMethod
import com.jefri.carrent.databinding.BottomsheetEditPaymentNumberBinding

class EditPaymentNumberBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomsheetEditPaymentNumberBinding? = null
    private val binding get() = _binding!!

    private var paymentMethod: PaymentMethod? = null
    private var onSave: ((String) -> Unit)? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomsheetEditPaymentNumberBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        paymentMethod = arguments?.getParcelable(EXTRA_PAYMENT_METHOD)

        binding.etNumber.setText(paymentMethod?.number)

        binding.btnSave.setOnClickListener {
            val newNumber = binding.etNumber.text.toString()
            if (newNumber.isNotEmpty()) {
                onSave?.invoke(newNumber)
                dismiss()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val TAG = "EditPaymentNumberBottomSheet"
        private const val EXTRA_PAYMENT_METHOD = "extra_payment_method"

        fun newInstance(
            paymentMethod: PaymentMethod,
            onSave: (String) -> Unit
        ): EditPaymentNumberBottomSheet {
            val fragment = EditPaymentNumberBottomSheet()
            fragment.onSave = onSave
            val args = Bundle()
            args.putParcelable(EXTRA_PAYMENT_METHOD, paymentMethod)
            fragment.arguments = args
            return fragment
        }
    }
}
