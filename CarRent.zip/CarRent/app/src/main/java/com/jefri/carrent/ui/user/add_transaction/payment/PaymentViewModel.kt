package com.jefri.carrent.ui.user.add_transaction.payment

import android.net.Uri
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.repository.UserRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch

class PaymentViewModel(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _orderData = MutableLiveData<Result<Order>>()
    val orderData: MutableLiveData<Result<Order>>
        get() = _orderData

    private val _stateUploadBukti = MutableLiveData<Result<String>>()
    val stateUploadBukti: MutableLiveData<Result<String>>
        get() = _stateUploadBukti

    fun getCurrentOrderData(id: String) {
        _orderData.value = Result.Loading
        viewModelScope.launch {
            val result = userRepository.getCurrentOrder(id)
            _orderData.value = result
        }
    }

    fun uploadBuktiPembayaran(
        id: String,
        imageUri: Uri
    ) {
        _stateUploadBukti.value = Result.Loading
        viewModelScope.launch {
            val result = userRepository.uploadBuktiPembayaran(id, imageUri)
            _stateUploadBukti.value = result
        }
    }

}