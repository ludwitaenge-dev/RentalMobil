package com.jefri.carrent.ui.user.add_transaction.select_muatan

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Muatan
import com.jefri.carrent.data.repository.UserRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch

class SelectMuatanViewModel(
    private val userRepository: UserRepository,
) : ViewModel() {

    private val _muatanData = MutableLiveData<Result<List<Muatan>>>()
    val muatanData: LiveData<Result<List<Muatan>>> get() = _muatanData

    init {
        getMuatanData()
    }

    private fun getMuatanData() {
        viewModelScope.launch {
            _muatanData.value = Result.Loading
//            val result = userRepository.getMuatanWithStatus()
//            _muatanData.value = result
        }
    }
}