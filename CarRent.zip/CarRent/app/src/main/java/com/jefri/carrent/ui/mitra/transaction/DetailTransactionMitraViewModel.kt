package com.jefri.carrent.ui.mitra.transaction

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Kendaraan
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.repository.MitraRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch

class DetailTransactionMitraViewModel(
    private val mitraRepository: MitraRepository
) : ViewModel() {

    private val _stateAcceptTransaction = MutableLiveData<Result<String>>()
    val stateAcceptTransaction: LiveData<Result<String>> = _stateAcceptTransaction

    private val _stateCancelTransaction = MutableLiveData<Result<String>>()
    val stateCancelTransaction: LiveData<Result<String>> = _stateCancelTransaction

    private val _orderData = MutableLiveData<Result<Order>>()
    val orderData: LiveData<Result<Order>> = _orderData

    private val _stateChatUser = MutableLiveData<Result<String>>()
    val stateChatUser: LiveData<Result<String>> = _stateChatUser

    fun getCurrentOrderData(id: String) {
        _orderData.value = Result.Loading
        viewModelScope.launch {
            val result = mitraRepository.getCurrentOrder(id)
            _orderData.value = result
        }
    }

    fun acceptOrder(
        orderId: String,
    ) {
        _stateAcceptTransaction.value = Result.Loading

        viewModelScope.launch {
            val result = mitraRepository.acceptOrder(orderId)
            _stateAcceptTransaction.value = result
        }
    }

    fun cancelOrder(
        orderId: String,
        reason: String,
    ) {
        _stateCancelTransaction.value = Result.Loading

        viewModelScope.launch {
            val result = mitraRepository.cancelOrder(orderId, reason, mitraRepository.getCurrentUser()?.uid)
            _stateCancelTransaction.value = result
        }
    }

    fun chatWithUser(
        userId: String?
    ) {
        _stateChatUser.value = Result.Loading
        viewModelScope.launch {
            val mitra = mitraRepository.getUserDataFromFirestore()
            val mitraId = mitra?.uid.toString()
            val mitraName = mitra?.name.toString()

            val user = mitraRepository.getUserDataByUID(userId.toString())
            val userName = user?.name.toString()

            val result =
                mitraRepository.chatWithUser(
                    userId = userId.toString(),
                    mitraId = mitraId,
                    userName = userName,
                    mitraName = mitraName
                )
            _stateChatUser.value = result

        }
    }
}
