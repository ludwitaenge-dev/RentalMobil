package com.jefri.carrent.ui.admin.user

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.User
import com.jefri.carrent.data.repository.AuthenticationRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch


class UserAdminViewModel(
    private val authRepo: AuthenticationRepository
) : ViewModel() {

    private val _users = MutableLiveData<Result<List<User>>>()
    val users: LiveData<Result<List<User>>> get() = _users

    init {
        loadUsers()
    }

    fun loadUsers() {
        viewModelScope.launch {
            _users.value = Result.Loading
            try {
                val data = authRepo.getUsers()
                _users.value = Result.Success(data)
            } catch (e: Exception) {
                _users.value = Result.Error(e.message ?: "Terjadi kesalahan")
            }
        }
    }

    fun updateUserStatus(uid: String, isActive: Boolean) {
        viewModelScope.launch {
            val currentResult = _users.value
            if (currentResult !is Result.Success) return@launch

            val currentList = currentResult.data.toMutableList()

            val index = currentList.indexOfFirst { it.uid == uid }
            if (index == -1) return@launch

            currentList[index] = currentList[index].copy(isUpdating = true)
            _users.value = Result.Success(currentList.toList())

            val success = authRepo.toggleUser(uid, isActive)

            currentList[index] = currentList[index].copy(
                isUpdating = false,
                isDeleted = !isActive
            )

            _users.value = Result.Success(currentList)
        }
    }
}
