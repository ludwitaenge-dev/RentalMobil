package com.jefri.carrent.ui.user.home

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.jefri.carrent.custom_ui.bottom_sheet.LogoutBottomSheet
import com.jefri.carrent.data.model.User
import com.jefri.carrent.databinding.FragmentHomeBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.admin.home.MitraHomeAdapter
import com.jefri.carrent.ui.user.car_mitra.CarMitraActivity
import com.jefri.carrent.ui.user.transaction.DetailTransactionActivity
import com.jefri.carrent.ui.user.transaction.TransactionAdapter
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.result.Result

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var user: User
    private val homeUserViewModel by viewModels<HomeViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    private lateinit var muatanAdapter: MitraHomeAdapter
    private lateinit var transactionAdapter: TransactionAdapter

    private lateinit var detailLauncher: ActivityResultLauncher<Intent>

    private fun isFirstLoad(): Boolean = binding.srRefresh.isRefreshing.not()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        detailLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                homeUserViewModel.refreshAll()
            }
        }

        init()
    }

    private fun init() {
        setupRecycleViewActiveTransaction()
        setupRecycleViewMuatan()
        setupGreeting()
        observeUserData()
        observeTransaction()
        observeMuatan()
        setupBtnListener()
        observeRefresh()
    }

    private fun observeTransaction() {
        homeUserViewModel.orderData.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> if (isFirstLoad()) binding.progressBar.show()

                is Result.Success -> {
                    binding.progressBar.hide()
                    val orderData = result.data
                    if (orderData.isEmpty()) {
                        binding.rvActiveTransaction.hide()
                        binding.tvNoActiveTransaction.show()
                    } else {
                        binding.rvActiveTransaction.show()
                        binding.tvNoActiveTransaction.hide()
                        transactionAdapter.submitList(orderData)
                    }

                }

                is Result.Error -> {
                    binding.progressBar.hide()
                    showToast(result.message)
                }
            }
        }
    }

    private fun observeMuatan() {
        homeUserViewModel.muatanData.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> if (isFirstLoad()) binding.progressBar.show()

                is Result.Success -> {
                    binding.progressBar.hide()
                    val muatanData = result.data
                    if (muatanData.isEmpty()) {
                        binding.rvMitra.hide()
                        binding.tvNoMuatan.show()
                    } else {
                        binding.rvMitra.show()
                        binding.tvNoMuatan.hide()
                        muatanAdapter.submitList(muatanData)
                    }
                }

                is Result.Error -> {
                    binding.progressBar.hide()
                    showToast(result.message)
                }
            }
        }
    }

    private fun observeUserData() {
        homeUserViewModel.user.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {}
                is Result.Success -> {
                    user = result.data!!
                    binding.tvUserName.text = user.name
                }
                is Result.Error -> {
                    showToast("Gagal ambil data user: ${result.message}")
                }
            }
        }
    }

    private fun setupRecycleViewActiveTransaction() {
        transactionAdapter = TransactionAdapter { order ->
            val intent = Intent(requireContext(), DetailTransactionActivity::class.java)
            intent.putExtra(DetailTransactionActivity.EXTRA_ORDER_ID, order.id)
            detailLauncher.launch(intent)
        }
        binding.rvActiveTransaction.adapter = transactionAdapter
    }

    private fun setupRecycleViewMuatan() {
        muatanAdapter = MitraHomeAdapter {
            val intentToCarMitra = Intent(requireContext(), CarMitraActivity::class.java)
            intentToCarMitra.putExtra(CarMitraActivity.EXTRA_MITRA_ID, it.uid)
            startActivity(intentToCarMitra)
        }
        binding.rvMitra.adapter = muatanAdapter
    }

    private fun observeRefresh() {
        homeUserViewModel.isRefreshing.observe(viewLifecycleOwner) { refreshing ->
            binding.srRefresh.isRefreshing = refreshing
        }
    }

    private fun setupBtnListener() {
        with (binding) {
            srRefresh.setOnRefreshListener {
                homeUserViewModel.refreshAll()
            }

            btnLogout.setOnClickListener {
                val logoutBottomSheet = LogoutBottomSheet()
                logoutBottomSheet.show(parentFragmentManager, logoutBottomSheet.tag)
            }
        }
    }

    private fun setupGreeting() {
        binding.tvGreeting.text = homeUserViewModel.getGreetingText()
    }

    fun refreshTransaction() {
        homeUserViewModel.refreshAll()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}