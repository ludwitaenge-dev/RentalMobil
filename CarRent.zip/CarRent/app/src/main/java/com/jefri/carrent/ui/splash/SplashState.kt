package com.jefri.carrent.ui.splash

sealed class SplashState {
    object Loading : SplashState()
    object NotLoggedIn : SplashState()
    data class LoggedIn(val role: String) : SplashState()
    data class Error(val message: String) : SplashState()
}