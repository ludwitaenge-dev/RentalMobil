package com.jefri.carrent.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class User(
    val uid: String = "",
    var name: String = "",
    val email: String = "",
    var noTelp: String? = null,
    var alamat: String = "",
    val role: String = "",
    val isActive: Boolean = false,
    val dokumen: String = "",
    val isDeleted: Boolean = false,
    var isUpdating: Boolean = false
) : Parcelable