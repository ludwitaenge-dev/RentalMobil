package com.jefri.carrent.custom_ui.input

import android.content.Context
import android.util.AttributeSet
import com.jefri.carrent.R
import com.jefri.carrent.utils.helpers.ValidationUtils

class NameInputView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : BaseInputView(context, attrs, defStyleAttr) {

    init {
        var hintText = "Nama Lengkap"

        context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.NameInputView,
            0,
            0
        ).apply {
            try {
                hintText = getString(R.styleable.NameInputView_hintText) ?: hintText
            } finally {
                recycle()
            }
        }

        setHint(hintText)
    }

    override fun validate(): Boolean {
        val name = getText()
        return if (!ValidationUtils.isNotEmpty(name)) {
            showError("Field tidak boleh kosong")
            false
        } else {
            showError(null)
            true
        }
    }
}
