package com.jefri.carrent.data.services.firebase

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.jefri.carrent.data.model.Notification
import kotlinx.coroutines.tasks.await
import com.jefri.carrent.utils.result.Result

class NotificationService(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) {
    suspend fun getNotifications(): Result<List<Notification>> {
        val uid = auth.currentUser?.uid ?: return Result.Error("User not authenticated")

        val snap = firestore.collection("users")
            .document(uid)
            .collection("notifications")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .get()
            .await()

        return Result.Success(snap.documents.mapNotNull { doc ->
            doc.toObject(Notification::class.java)?.copy(id = doc.id)
        })
    }
}