// Mendefinisikan package lokasi file ForgotPasswordViewModel
package com.jefri.carrent.ui.auth.forgotpassword

// Import LiveData untuk mengamati perubahan data secara lifecycle-aware
import androidx.lifecycle.LiveData
// Import MutableLiveData untuk mengubah nilai LiveData
import androidx.lifecycle.MutableLiveData
// Import ViewModel sebagai kelas dasar ViewModel
import androidx.lifecycle.ViewModel
// Import viewModelScope untuk menjalankan coroutine sesuai lifecycle ViewModel
import androidx.lifecycle.viewModelScope
// Import AuthenticationRepository sebagai penghubung ke sumber data (Firebase/API)
import com.jefri.carrent.data.repository.AuthenticationRepository
// Import sealed class Result untuk menangani state (Loading, Success, Error)
import com.jefri.carrent.utils.result.Result
// Import coroutine launch untuk menjalankan proses asynchronous
import kotlinx.coroutines.launch

// Mendeklarasikan class ForgotPasswordViewModel yang mewarisi ViewModel
class ForgotPasswordViewModel(

    // Dependency Injection repository untuk menangani proses autentikasi
    private val authenticationRepository: AuthenticationRepository

) : ViewModel() {

    // MutableLiveData untuk menyimpan dan mengubah state verifikasi (private)
    private val _verifikasiState = MutableLiveData<Result<String?>>()
    
    // LiveData publik yang bisa di-observe oleh Activity (read-only dari luar)
    val verifikasiState: LiveData<Result<String?>>
        get() = _verifikasiState

    // Fungsi verifikasi untuk mengirim permintaan reset password berdasarkan email
    fun verifikasi(
        email: String,   // Parameter email pengguna
    ) = viewModelScope.launch {   // Menjalankan coroutine dalam lifecycle ViewModel
        
        // Mengubah state menjadi Loading sebelum proses dimulai
        _verifikasiState.value = Result.Loading

        // Memanggil fungsi forgotPassword di repository
        // Biasanya akan mengirim email reset password melalui Firebase Authentication
        val result = authenticationRepository.forgotPassword(email)
        
        // Mengirim hasil (Success atau Error) ke LiveData
        _verifikasiState.value = result
    }
}