package com.jefri.carrent.custom_ui.input

import android.content.Context
import android.text.InputType
import android.util.AttributeSet
import com.google.android.material.textfield.TextInputLayout
import com.jefri.carrent.utils.helpers.ValidationUtils

class ConfirmationPasswordInputView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : BaseInputView(context, attrs, defStyleAttr) {

    private var originalPassword: String? = null
    private var isVisible = false

    init {
        setHint("Konfirmasi Password")
        binding.etInput.inputType =
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        til.endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
        til.setEndIconOnClickListener {
            isVisible = !isVisible
            togglePasswordVisibility()
        }
    }

    fun setOriginalPassword(password: String?) {
        originalPassword = password
    }

    override fun validate(): Boolean {
        val confirm = getText()

        if (!ValidationUtils.isNotEmpty(confirm)) {
            showError("Konfirmasi password tidak boleh kosong")
            return false
        }

        if (confirm != originalPassword) {
            showError("Password tidak sama")
            return false
        }

        showError(null)
        return true
    }

    private fun togglePasswordVisibility() {
        if (isVisible) {
            binding.etInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        } else {
            binding.etInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        binding.etInput.setSelection(binding.etInput.text?.length ?: 0)
    }
}
