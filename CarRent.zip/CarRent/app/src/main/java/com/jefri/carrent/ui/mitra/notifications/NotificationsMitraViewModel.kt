package com.jefri.carrent.ui.mitra.notifications

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Notification
import com.jefri.carrent.data.repository.MitraRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch

class NotificationsMitraViewModel(
    private val mitraRepository: MitraRepository
) : ViewModel() {

    private val _notificationData = MutableLiveData<Result<List<Notification>>>()
    val notificationData: LiveData<Result<List<Notification>>> get() = _notificationData

    init {
        getListNotification()
    }

    private fun getListNotification() {
        _notificationData.value = Result.Loading
        viewModelScope.launch {
            _notificationData.value = mitraRepository.getNotification()
        }
    }
}