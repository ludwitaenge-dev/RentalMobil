package com.jefri.carrent.data.model

data class Chat(
    val participants: Map<String, String?> = emptyMap(),
    val lastMessage: String = "",
    val timestamp: Long = System.currentTimeMillis()
)