package com.jefri.carrent.custom_ui.input

import android.content.Context
import android.text.InputType
import android.util.AttributeSet
import com.google.android.material.textfield.TextInputLayout
import com.jefri.carrent.utils.helpers.ValidationUtils

class PasswordInputView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : BaseInputView(context, attrs, defStyleAttr) {

    private var isVisible = false

    init {
        setHint("Password")
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        til.endIconMode = TextInputLayout.END_ICON_PASSWORD_TOGGLE
        til.setEndIconOnClickListener {
            isVisible = !isVisible
            togglePasswordVisibility()
        }
    }

    private fun togglePasswordVisibility() {
        if (isVisible) {
            binding.etInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        } else {
            binding.etInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        binding.etInput.setSelection(binding.etInput.text?.length ?: 0)
    }

    override fun validate(): Boolean {
        val password = getText()
        return if (password.isEmpty()) {
            showError("Password tidak boleh kosong")
            false
        } else if (!ValidationUtils.isValidPassword(password)) {
            showError("Password minimal 8 karakter")
            false
        } else {
            showError(null)
            true
        }
    }
}
