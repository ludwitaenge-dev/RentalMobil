package com.jefri.carrent.ui.mitra.mobil

import android.net.Uri
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.bumptech.glide.Glide
import com.jefri.carrent.R
import com.jefri.carrent.data.model.Mobil
import com.jefri.carrent.databinding.ActivityDetailMuatanMitraBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.result.Result

class DetailMobilMitraActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailMuatanMitraBinding
    private lateinit var action: String
    private var mobilId: String? = null

    private var selectedImageDokumenUri: Uri? = null
    private var selectedImageMobilUri: Uri? = null
    private val viewModel by viewModels<DetailMobilMitraViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private var urlMobil: String? = null
    private var urlDokumen: String? = null

    private val pickImageLauncherDokumen = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            selectedImageDokumenUri = it
            binding.ivPreviewDokumen.show()
            binding.ivUploadIconDokumen.hide()
            binding.btnClearDokumen.show()
            binding.ivPreviewDokumen.setImageURI(it)
        }
    }

    private val pickImageLauncherMobil = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            selectedImageMobilUri = it
            binding.ivPreviewMobil.show()
            binding.ivUploadIconMobil.hide()
            binding.btnClearMobil.show()
            binding.ivPreviewMobil.setImageURI(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        binding = ActivityDetailMuatanMitraBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
    }

    private fun init() {
        setupReceiveIntent()
        setupViewBaseOnAction()
        observeMuatanDetailData()
        observeStateAddMuatan()
        observeStateUpdateMuatan()
        setupBtnListener()
    }

    private fun setupViewBaseOnAction() {
        with(binding) {
            if (action == ACTION_ADD) {
                btnAdd.show()
            } else if (action == ACTION_EDIT) {
                viewModel.getMobilDetailData(mobilId.toString())
                btnUpdate.show()
            }
        }
    }

    private fun observeMuatanDetailData() {
        viewModel.mobilDetailData.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.progressBar.show()
                    }

                    is Result.Success -> {
                        binding.progressBar.hide()
                        val mobil = result.data
                        setupMobilData(mobil)
                    }

                    is Result.Error -> {
                        binding.progressBar.hide()
                        showToast(result.message)
                    }
                }
            }
        }
    }

    private fun observeStateAddMuatan() {
        viewModel.stateAddMobil.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.btnAdd.setLoading(true)
                    }

                    is Result.Success -> {
                        binding.btnAdd.setLoading(false)
                        showToast(result.data)
                        setResult(RESULT_OK)
                        finish()
                    }

                    is Result.Error -> {
                        binding.btnAdd.setLoading(false)
                        showToast(result.message)
                    }
                }
            }
        }
    }

    private fun observeStateUpdateMuatan() {
        viewModel.stateUpdateMobil.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.btnUpdate.setLoading(true)
                    }

                    is Result.Success -> {
                        binding.btnUpdate.setLoading(false)
                        showToast(result.data)
                        setResult(RESULT_OK)
                        finish()
                    }

                    is Result.Error -> {
                        binding.btnUpdate.setLoading(false)
                        showToast(result.message)
                    }
                }

            }
        }
    }


    private fun setupMobilData(mobil: Mobil) {
        with(binding) {
            etMerk.setText(mobil.merk)
            etModel.setText(mobil.model)
            etTahun.setText(mobil.tahun)
            etPlat.setText(mobil.platNomor)
            etWarna.setText(mobil.warna)
            etHarga.setText(mobil.hargaPerHari.toString())

            ivPreviewMobil.show()
            ivPreviewDokumen.show()
            ivUploadIconDokumen.hide()
            ivUploadIconMobil.hide()
            btnClearMobil.show()
            btnClearDokumen.show()

            urlMobil = mobil.fotoUrl
            urlDokumen = mobil.dokumentUrl

            Glide.with(this@DetailMobilMitraActivity)
                .load(urlMobil)
                .centerCrop()
                .into(ivPreviewMobil)

            Glide.with(this@DetailMobilMitraActivity)
                .load(urlDokumen)
                .centerCrop()
                .into(ivPreviewDokumen)
        }
    }

    private fun setupBtnListener() {
        with(binding) {
            btnAdd.setOnClickListener {
                val isValid =
                    etMerk.validate() and etModel.validate() and etTahun.validate() and etPlat.validate() and etWarna.validate() and etHarga.validate()

                if (selectedImageMobilUri == null) {
                    showToast("Pilih gambar mobil dulu")
                    return@setOnClickListener
                }

                if (selectedImageDokumenUri == null) {
                    showToast("Pilih gambar dokumen dulu")
                    return@setOnClickListener
                }

                if (!isValid) return@setOnClickListener

                // Add new mobil
                viewModel.addMobil(
                    merk = etMerk.getText(),
                    model = etModel.getText(),
                    tahun = etTahun.getText(),
                    platNomor = etPlat.getText(),
                    warna = etWarna.getText(),
                    hargaPerHari = etHarga.getText().toLong(),
                    imageUri = selectedImageMobilUri!!,
                    dokumentUri = selectedImageDokumenUri!!,
                )
            }

            btnUpdate.setOnClickListener {
                val isValid =
                    etMerk.validate() and
                            etModel.validate() and
                            etTahun.validate() and
                            etPlat.validate() and
                            etWarna.validate()
                etHarga.validate()

                if (!isValid) return@setOnClickListener

                // Update mobil
                viewModel.updateMobil(
                    mobilId = mobilId.toString(),
                    merk = etMerk.getText(),
                    model = etModel.getText(),
                    tahun = etTahun.getText(),
                    platNomor = etPlat.getText(),
                    warna = etWarna.getText(),
                    harga = etHarga.getText().toLong(),
                    imageUri = selectedImageMobilUri,
                    dokumentUri = selectedImageDokumenUri,
                )
            }

            llUploadPlaceholderDokumen.setOnClickListener {
                pickImageLauncherDokumen.launch("image/*")
            }

            llUploadPlaceholderMobil.setOnClickListener {
                pickImageLauncherMobil.launch("image/*")
            }

            btnClearDokumen.setOnClickListener {
                selectedImageDokumenUri = null
                btnClearDokumen.hide()
                ivPreviewDokumen.hide()
                ivUploadIconDokumen.show()
                ivPreviewDokumen.setImageURI(null)
            }

            btnClearMobil.setOnClickListener {
                selectedImageMobilUri = null
                btnClearMobil.hide()
                ivPreviewMobil.hide()
                ivUploadIconMobil.show()
                ivPreviewMobil.setImageURI(null)
            }

            ivBack.setOnClickListener {
                finish()
            }
        }
    }

    private fun setupReceiveIntent() {
        action = intent.getStringExtra(EXTRA_ACTION) ?: ""
        mobilId = intent.getStringExtra(EXTRA_MOBIL_ID)
    }

    companion object {
        const val EXTRA_MOBIL_ID = "extra_muatan_id"
        const val EXTRA_ACTION = "extra_action"
        const val ACTION_EDIT = "action_edit"
        const val ACTION_ADD = "action_add"
    }
}