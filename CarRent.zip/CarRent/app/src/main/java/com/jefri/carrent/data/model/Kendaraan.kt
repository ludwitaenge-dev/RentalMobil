package com.jefri.carrent.data.model

import android.os.Parcelable
import com.google.firebase.Timestamp
import kotlinx.parcelize.Parcelize

@Parcelize
data class Kendaraan(
    val id: String = "",
    val namaDriver: String = "",
    val nomorDriver: String = "",
    val platMobil: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) : Parcelable