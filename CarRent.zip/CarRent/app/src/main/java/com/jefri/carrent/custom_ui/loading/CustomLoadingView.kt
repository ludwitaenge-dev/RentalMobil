package com.jefri.carrent.custom_ui.loading

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.LayoutInflater
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.jefri.carrent.databinding.ViewLoadingOverlayBinding

class CustomLoadingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private val binding = ViewLoadingOverlayBinding.inflate(LayoutInflater.from(context), this, true)
    private var isShowing = false

    private val backCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            // do nothing
        }
    }

    fun show(message: String = "Loading...") {
        Log.d("CustomLoadingView", "Show dipanggil")
        if (!isShowing) {
            binding.tvMessage.text = message
            visibility = VISIBLE
            bringToFront()
            isShowing = true

            val activity = (context as? AppCompatActivity)
            activity?.onBackPressedDispatcher?.addCallback(activity, backCallback)
        }
    }

    fun hide() {
        if (isShowing) {
            visibility = GONE
            isShowing = false

            backCallback.remove()
        }
    }

    fun isVisible(): Boolean = isShowing
}