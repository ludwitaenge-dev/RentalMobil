package com.jefri.carrent.custom_ui.bottom_sheet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.jefri.carrent.R
import com.jefri.carrent.databinding.BottomsheetRatingBinding
import com.jefri.carrent.utils.ext.showToast

class RatingBottomSheet(
    private val onSubmit: (
        rating: Int,
        setLoading: (Boolean) -> Unit,
        dismiss: () -> Unit
    ) -> Unit
) : BottomSheetDialogFragment() {

    private var _binding: BottomsheetRatingBinding? = null
    private val binding get() = _binding!!

    private var selectedRating = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomsheetRatingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        with(binding) {
            val stars = listOf(ivStar1, ivStar2, ivStar3, ivStar4, ivStar5)
            stars.forEachIndexed { index, imageView ->
                imageView.setOnClickListener {
                    selectedRating = index + 1
                    updateStars(selectedRating, stars)
                }
            }

            btnSubmit.setOnClickListener {
                if (selectedRating == 0) {
                    showToast("Silakan pilih rating terlebih dahulu")
                    return@setOnClickListener
                }

                btnSubmit.setLoading(true)

                onSubmit(
                    selectedRating,
                    { isLoading -> btnSubmit.setLoading(isLoading) },
                    { dismiss() }
                )
            }

            btnCancel.setOnClickListener { dismiss() }
        }
    }

    private fun updateStars(selected: Int, stars: List<ImageView>) {
        stars.forEachIndexed { index, star ->
            if (index < selected)
                star.setImageResource(R.drawable.ic_star_filled)
            else
                star.setImageResource(R.drawable.ic_star_outline)
        }
    }

    fun setLoading(state: Boolean) {
        binding.btnSubmit.setLoading(state)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
