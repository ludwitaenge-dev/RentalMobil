package com.jefri.carrent.utils.helpers

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.jefri.carrent.R
import androidx.core.graphics.drawable.toDrawable

object AlertHelper {

    fun showAlert(
        context: Context,
        title: String = "Informasi",
        message: String,
        positiveText: String = "OK",
        negativeText: String? = null,
        onConfirm: (() -> Unit)? = null,
        onCancel: (() -> Unit)? = null
    ) {
        val builder = AlertDialog.Builder(context, R.style.ModernAlertDialog)
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.dialog_custom_alert, null)

        val tvTitle = view.findViewById<TextView>(R.id.tvTitle)
        val tvMessage = view.findViewById<TextView>(R.id.tvMessage)
        val btnPositive = view.findViewById<Button>(R.id.btnPositive)
        val btnNegative = view.findViewById<Button>(R.id.btnNegative)
        val divider = view.findViewById<View>(R.id.divider)

        tvTitle.text = title
        tvMessage.text = message
        btnPositive.text = positiveText

        if (negativeText != null) {
            btnNegative.visibility = View.VISIBLE
            divider.visibility = View.VISIBLE
            btnNegative.text = negativeText
        } else {
            btnNegative.visibility = View.GONE
            divider.visibility = View.GONE
        }

        val dialog = builder.setView(view).create()

        btnPositive.setOnClickListener {
            onConfirm?.invoke()
            dialog.dismiss()
        }

        btnNegative.setOnClickListener {
            onCancel?.invoke()
            dialog.dismiss()
        }

        dialog.window?.setBackgroundDrawable(Color.TRANSPARENT.toDrawable())
        dialog.show()
    }
}

