package com.jefri.carrent.data.repository

import android.net.Uri
import com.google.firebase.auth.FirebaseUser
import com.jefri.carrent.data.model.Kendaraan
import com.jefri.carrent.data.model.Mobil
import com.jefri.carrent.data.model.Muatan
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.model.User
import com.jefri.carrent.data.services.firebase.AuthService
import com.jefri.carrent.data.services.firebase.ChatService
import com.jefri.carrent.data.services.firebase.MobilService
import com.jefri.carrent.data.services.firebase.NotificationService
import com.jefri.carrent.data.services.firebase.OrderService
import com.jefri.carrent.utils.result.Result

class MitraRepository private constructor(
    private val firebaseAuthService: AuthService,
    private val chatService: ChatService,
    private val mobilService: MobilService,
    private val orderService: OrderService,
    private val notificationService: NotificationService
) {
    suspend fun getUserDataFromFirestore(): User? {
        return try {
            val uid = getCurrentUser()?.uid ?: return null
            return firebaseAuthService.getFirestoreUser(uid)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getUserDataByUID(uid: String): User? {
        return try {
            return firebaseAuthService.getFirestoreUser(uid)
        } catch (e: Exception) {
            null
        }
    }

    fun getCurrentUser(): FirebaseUser? {
        return firebaseAuthService.getCurrentUser()
    }

    suspend fun getCurrentOrder(orderId: String) = orderService.getCurrentOrder(orderId)

    suspend fun getOrdersData(
        status: List<String>? = null,
    ): Result<List<Order>> {
        return when (val result = orderService.getOrdersData(
            mitraUid = getCurrentUser()?.uid,
            status = status
        )) {
            is Result.Error -> result

            is Result.Success -> {
                val ordersWithAlamat = result.data.map { order ->
                    val mitraId = order.mobil?.mitraId

                    if (mitraId.isNullOrEmpty()) {
                        order
                    } else {
                        val mitra = firebaseAuthService.getFirestoreUser(mitraId)
                        order.copy(
                            mitraAlamat = mitra?.alamat
                        )
                    }
                }

                Result.Success(ordersWithAlamat)
            }
            else -> Result.Error("Gagal memuat data")
        }
    }

    suspend fun acceptOrder(
        orderId: String,
    ) = orderService.acceptOrder(
        orderId = orderId,
        role = "mitra",
    )

    suspend fun cancelOrder(
        orderId: String,
        reason: String,
        cancelBy: String?,
    ) = orderService.cancelOrder(
        orderId = orderId,
        reason = reason,
        cancelBy = cancelBy
    )

    fun getUserChats(userId: String) = chatService.getUserChatsFlow(userId)

    suspend fun chatWithUser(
        userId: String,
        mitraId: String,
        userName: String,
        mitraName: String,
    ) = chatService.createChatRoomIfNotExists(
        userId,
        adminId = mitraId,
        userName = userName,
        adminName = mitraName,
    )

    suspend fun updateInfoMitra(
        uid: String,
        image: Uri,
        alamat: String,
        notel: String,
    ) = firebaseAuthService.updateInfoMitra(
        uid = uid,
        imageUri = image,
        alamat = alamat,
        notel = notel,
    )

    suspend fun getMobilByMitraId(mitraId: String) = mobilService.getMobilByMitraId(mitraId)

    suspend fun getMobilById(mobilId: String) = mobilService.getMobilById(mobilId)

    suspend fun getMobilWithStatus(mitraId: String): Result<List<Mobil>> {
        return try {
            val mobilResult = mobilService.getMobilByMitraId(mitraId)
            val orderResult = orderService.getOrdersData()

            if (mobilResult is Result.Success && orderResult is Result.Success) {
                val mobilList = mobilResult.data
                val orderList = orderResult.data

                val activeMobilIds = orderList
                    .filter { it.status != "selesai" && it.status != "dibatalkan" }
                    .mapNotNull { it.mobil?.id }
                    .toSet()

                val combinedList = mobilList.map { mobil ->
                    mobil.copy(
                        isBooked = activeMobilIds.contains(mobil.id)
                    )
                }

                Result.Success(combinedList)
            } else {
                Result.Error("Gagal memuat data")
            }
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun addMobil(
        mobil: Mobil,
        imageUri: Uri,
        dokumentUri: Uri,
    ) = mobilService.addMobil(
        mobil = mobil,
        imageUri = imageUri,
        dokumentUri = dokumentUri
    )

    suspend fun updateMobil(
        mobilId: String,
        merk: String,
        model: String,
        tahun: String,
        plat: String,
        warna: String,
        harga: Long,
        imageUri: Uri?,
        dokumentUri: Uri?
    ) = mobilService.updateMobil(
        mobilId = mobilId,
        merk = merk,
        model = model,
        tahun = tahun,
        plat = plat,
        warna = warna,
        harga = harga,
        imageUri = imageUri,
        dokumentUri = dokumentUri
    )

    suspend fun getNotification() = notificationService.getNotifications()

    companion object {
        @Volatile
        private var INSTANCE: MitraRepository? = null

        fun getInstance(
            firebaseAuthService: AuthService,
            chatService: ChatService,
            mobilService: MobilService,
            orderService: OrderService,
            notificationService: NotificationService
        ): MitraRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: MitraRepository(
                    firebaseAuthService,
                    chatService,
                    mobilService,
                    orderService,
                    notificationService
                ).also {
                    INSTANCE = it
                }
            }
        }
    }
}