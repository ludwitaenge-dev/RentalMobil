package com.jefri.carrent.data.repository

import android.net.Uri
import com.google.firebase.auth.FirebaseUser
import com.jefri.carrent.data.model.Mobil
import com.jefri.carrent.data.model.Muatan
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.model.User
import com.jefri.carrent.data.services.firebase.AuthService
import com.jefri.carrent.data.services.firebase.ChatService
import com.jefri.carrent.data.services.firebase.MobilService
import com.jefri.carrent.data.services.firebase.NotificationService
import com.jefri.carrent.data.services.firebase.OrderService
import com.jefri.carrent.data.services.firebase.PaymentService
import com.jefri.carrent.utils.Constants
import com.jefri.carrent.utils.result.Result

class UserRepository private constructor(
    private val firebaseAuthService: AuthService,
    private val chatService: ChatService,
    private val mobilService: MobilService,
    private val orderService: OrderService,
    private val notificationService: NotificationService,
    private val paymentService: PaymentService
) {
    suspend fun getUserDataFromFirestore(): User? {
        return try {
            val uid = getCurrentUser()?.uid ?: return null
            return firebaseAuthService.getFirestoreUser(uid)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getUserDataByUID(uid: String): User? {
        return try {
            return firebaseAuthService.getFirestoreUser(uid)
        } catch (e: Exception) {
            null
        }
    }

    fun getCurrentUser(): FirebaseUser? {
        return firebaseAuthService.getCurrentUser()
    }

    suspend fun updateUserData(updates: Map<String, Any>): Result<String> {
        return try {
            val uid = getCurrentUser()?.uid.toString()
            firebaseAuthService.updateUserData(uid, updates)
            Result.Success("User data updated successfully")
        } catch (e: Exception) {
            e.printStackTrace()
            Result.Error(e.toString())
        }
    }

    fun getUserChats(userId: String) = chatService.getUserChatsFlow(userId)

    fun listenMessages(chatId: String) = chatService.listenMessagesFlow(chatId)

    suspend fun sendMessage(chatId: String, senderId: String, text: String) =
        chatService.sendMessage(chatId, senderId, text)

    suspend fun getChatDetail(chatId: String) = chatService.getChatDetail(chatId)

    suspend fun chatWithAdmin(
        userId: String,
    ) = chatService.createChatRoomIfNotExists(
        userId,
        adminId = Constants.ADMIN_UID
    )

    suspend fun getNotification() = notificationService.getNotifications()

    suspend fun chatWithMitra(
        userId: String,
        mitraId: String,
        userName: String,
        mitraName: String,
    ) = chatService.createChatRoomIfNotExists(
        userId,
        adminId = mitraId,
        userName = userName,
        adminName = mitraName,
    )

//    suspend fun createChatIfNeeded(userId: String, adminId: String) =
//        chatService.createChatRoomIfNotExists(userId, adminId)

    suspend fun getMobilData() = mobilService.getMobilData()

    suspend fun getMobilWithStatus(): Result<List<Mobil>> {
        return try {
            val mobilResult = mobilService.getMobilData()
            val orderResult = orderService.getOrdersData()

            if (mobilResult is Result.Success && orderResult is Result.Success) {
                val mobilList = mobilResult.data
                val orderList = orderResult.data

                val activeMobilIds = orderList
                    .filter { it.status != "selesai" && it.status != "dibatalkan" }
                    .mapNotNull { it.mobil?.id }
                    .toSet()

                val combinedList = mobilList.map { mobil ->
                    mobil.copy(
                        isBooked = activeMobilIds.contains(mobil.id)
                    )
                }

                Result.Success(combinedList)
            } else {
                Result.Error("Gagal memuat data")
            }
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun getOrdersActiveData(): Result<List<Order>> {
        return when (val result = orderService.getOrdersActiveData(
            uid = getCurrentUser()?.uid
        )) {
            is Result.Error -> result

            is Result.Success -> {
                val ordersWithAlamat = result.data.map { order ->
                    val mitraId = order.mobil?.mitraId

                    if (mitraId.isNullOrEmpty()) {
                        order
                    } else {
                        val mitra = firebaseAuthService.getFirestoreUser(mitraId)
                        order.copy(
                            mitraAlamat = mitra?.alamat
                        )
                    }
                }

                Result.Success(ordersWithAlamat)
            }

            else -> Result.Error("Gagal memuat data")
        }
    }

    suspend fun getCurrentOrder(orderId: String) = orderService.getCurrentOrder(orderId)

    suspend fun addOrder(order: Order) = orderService.addOrder(order)

    suspend fun getOrdersData(
        status: List<String>? = null,
    ) = orderService.getOrdersData(
        uid = getCurrentUser()?.uid.toString(),
        status = status,
    )

    suspend fun uploadBuktiPembayaran(
        orderId: String,
        image: Uri,
    ) = orderService.uploadBuktiPembayaran(
        orderId = orderId,
        imageUri = image,
    )

    suspend fun acceptOrder(
        orderId: String,
        rating: Int,
    ) = orderService.acceptOrder(
        orderId = orderId,
        role = "user",
        rating = rating,
    )

    suspend fun getMitraActiveData() = firebaseAuthService.getMitraActiveData()

    suspend fun getPaymentMethods() = paymentService.getPaymentMethods()

    companion object {
        @Volatile
        private var INSTANCE: UserRepository? = null

        fun getInstance(
            firebaseAuthService: AuthService,
            chatService: ChatService,
            mobilService: MobilService,
            orderService: OrderService,
            notificationService: NotificationService,
            paymentService: PaymentService
        ): UserRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: UserRepository(
                    firebaseAuthService,
                    chatService,
                    mobilService,
                    orderService,
                    notificationService,
                    paymentService
                ).also {
                    INSTANCE = it
                }
            }
        }
    }
}