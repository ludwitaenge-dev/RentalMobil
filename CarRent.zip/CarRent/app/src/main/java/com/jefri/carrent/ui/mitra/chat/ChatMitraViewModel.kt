// Mendefinisikan package lokasi file ChatMitraFragment
package com.jefri.carrent.ui.mitra.chat

// Import Intent untuk berpindah ke Activity lain
import android.content.Intent
// Import Bundle untuk menyimpan state Fragment
import android.os.Bundle
// Import LayoutInflater untuk mengubah XML menjadi View
import android.view.LayoutInflater
// Import View sebagai komponen tampilan
import android.view.View
// Import ViewGroup sebagai parent layout
import android.view.ViewGroup
// Import Fragment sebagai superclass
import androidx.fragment.app.Fragment
// Import viewModels delegate untuk menghubungkan ViewModel dengan Fragment
import androidx.fragment.app.viewModels
// Import lifecycleScope untuk menjalankan coroutine sesuai lifecycle
import androidx.lifecycle.lifecycleScope
// Import ViewBinding untuk layout FragmentChatMitra
import com.jefri.carrent.databinding.FragmentChatMitraBinding
// Import ViewModelFactory untuk membuat instance ViewModel
import com.jefri.carrent.ui.ViewModelFactory
// Import ChatAdapter untuk RecyclerView
import com.jefri.carrent.ui.user.chat.ChatAdapter
// Import DetailChatActivity sebagai halaman detail chat
import com.jefri.carrent.ui.user.chat.DetailChatActivity
// Import extension hide() untuk menyembunyikan view
import com.jefri.carrent.utils.ext.hide
// Import extension show() untuk menampilkan view
import com.jefri.carrent.utils.ext.show
// Import extension showToast() untuk menampilkan pesan singkat
import com.jefri.carrent.utils.ext.showToast
// Import sealed class Result untuk menangani state (Loading, Success, Error)
import com.jefri.carrent.utils.result.Result
// Import collectLatest untuk mengumpulkan Flow terbaru
import kotlinx.coroutines.flow.collectLatest
// Import coroutine launch
import kotlinx.coroutines.launch
// Import kotlin getValue untuk delegate
import kotlin.getValue

// Mendeklarasikan class ChatMitraFragment
class ChatMitraFragment : Fragment() {

    // Variabel binding nullable (menghindari memory leak pada Fragment)
    private var _binding: FragmentChatMitraBinding? = null
    
    // Getter non-null untuk mempermudah akses binding
    private val binding get() = _binding!!

    // Deklarasi adapter RecyclerView
    private lateinit var adapter: ChatAdapter

    // Inisialisasi ViewModel menggunakan ViewModelFactory
    private val chatMitraViewModel by viewModels<ChatMitraViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    // Fungsi untuk membuat tampilan Fragment
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Menghubungkan binding dengan layout XML
        _binding = FragmentChatMitraBinding.inflate(inflater, container, false)
        return binding.root // Mengembalikan root view
    }

    // Dipanggil setelah view berhasil dibuat
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView() // Mengatur RecyclerView
        observeChat(chatMitraViewModel.getUserId() ?: "") // Mengamati daftar chat
    }

    // Fungsi untuk mengamati data chat berdasarkan userId
    private fun observeChat(userId: String) {
        viewLifecycleOwner.lifecycleScope.launch {
            
            // Memanggil fungsi untuk memuat chat
            chatMitraViewModel.loadUserChats(userId)
            
            // Mengumpulkan data Flow chatList dari ViewModel
            chatMitraViewModel.chatList.collectLatest { result ->
                
                // Menentukan aksi berdasarkan state Result
                when (result) {
                    
                    // Jika status Loading
                    is Result.Loading -> {
                        binding.progressBar.show()
                    }
                    
                    // Jika status Success
                    is Result.Success -> {
                        binding.progressBar.hide()
                        adapter.submitList(result.data) // Kirim data ke adapter
                    }
                    
                    // Jika status Error
                    is Result.Error -> {
                        binding.progressBar.hide()
                        showToast("Error: ${result.message}")
                    }
                }
            }
        }
    }

    // Fungsi untuk mengatur RecyclerView
    private fun setupRecyclerView() {
        
        // Inisialisasi adapter dengan userId dan klik listener
        adapter = ChatAdapter(chatMitraViewModel.getUserId().toString()) { chatId, chat ->
            
            // Intent menuju DetailChatActivity
            val intentToDetailChat = Intent(requireContext(), DetailChatActivity::class.java)
            
            // Mengirim chatId ke DetailChatActivity
            intentToDetailChat.putExtra(DetailChatActivity.EXTRA_CHAT_ID, chatId)
            
            // Menjalankan Activity detail chat
            startActivity(intentToDetailChat)
        }
        
        // Menghubungkan adapter dengan RecyclerView
        binding.rvChatList.adapter = adapter
    }

    // Dipanggil saat view Fragment dihancurkan
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // Menghindari memory leak
    }
}