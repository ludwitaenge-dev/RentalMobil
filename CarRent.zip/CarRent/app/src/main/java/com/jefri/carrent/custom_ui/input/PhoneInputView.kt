package com.jefri.carrent.custom_ui.input

import android.content.Context
import android.text.InputType
import android.util.AttributeSet
import com.jefri.carrent.utils.helpers.ValidationUtils

class PhoneInputView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : BaseInputView(context, attrs, defStyleAttr) {

    init {
        setHint("Nomor Telepon")
        binding.etInput.inputType = InputType.TYPE_CLASS_PHONE
    }

    override fun validate(): Boolean {
        val phone = getText()
        return if (!ValidationUtils.isNotEmpty(phone)) {
            showError("Nomor telepon tidak boleh kosong")
            false
        } else if (!ValidationUtils.isValidPhone(phone)) {
            showError("Nomor telepon tidak valid (minimal 10 digit angka)")
            false
        } else {
            showError(null)
            true
        }
    }
}
