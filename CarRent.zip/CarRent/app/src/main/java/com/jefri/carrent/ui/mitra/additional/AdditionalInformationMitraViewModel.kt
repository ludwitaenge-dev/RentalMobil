// Mendefinisikan package lokasi file AdditionalInformationMitraViewModel
package com.jefri.carrent.ui.mitra.additional

// Import Uri untuk merepresentasikan file gambar
import android.net.Uri
// Import MutableLiveData untuk menyimpan dan mengubah data yang dapat di-observe
import androidx.lifecycle.MutableLiveData
// Import ViewModel sebagai bagian dari arsitektur MVVM
import androidx.lifecycle.ViewModel
// Import viewModelScope untuk menjalankan coroutine sesuai lifecycle ViewModel
import androidx.lifecycle.viewModelScope
// Import MitraRepository sebagai penghubung ke sumber data (Firebase/API)
import com.jefri.carrent.data.repository.MitraRepository
// Import sealed class Result untuk menangani state (Loading, Success, Error)
import com.jefri.carrent.utils.result.Result
// Import coroutine launch untuk proses asynchronous
import kotlinx.coroutines.launch

// Mendeklarasikan class AdditionalInformationMitraViewModel
class AdditionalInformationMitraViewModel(

    // Dependency Injection repository untuk menangani data mitra
    private val mitraRepository: MitraRepository

) : ViewModel() {

    // MutableLiveData untuk menyimpan state update informasi mitra
    private val _stateUpdateInfoMitra = MutableLiveData<Result<String>>()
    
    // LiveData yang bisa di-observe oleh Activity
    // (Catatan: sebaiknya bertipe LiveData agar lebih aman/read-only)
    val stateUpdateInfoMitra: MutableLiveData<Result<String>>
        get() = _stateUpdateInfoMitra

    // Fungsi untuk memperbarui informasi mitra
    fun updateInfoMitra(
        imageUri: Uri,   // URI gambar yang dipilih
        alamat: String,  // Alamat mitra
        notel: String    // Nomor telepon mitra
    ) {
        // Mengubah state menjadi Loading sebelum proses dimulai
        _stateUpdateInfoMitra.value = Result.Loading
        
        // Menjalankan proses asynchronous dalam coroutine
        viewModelScope.launch {
            
            // Memanggil fungsi updateInfoMitra di repository
            // Mengirimkan:
            // - UID user saat ini
            // - URI gambar
            // - Alamat
            // - Nomor telepon
            val result = mitraRepository.updateInfoMitra(
                mitraRepository.getCurrentUser()?.uid.toString(), // Ambil UID user login
                imageUri,
                alamat,
                notel
            )
            
            // Mengirim hasil (Success atau Error) ke LiveData
            _stateUpdateInfoMitra.value = result
        }
    }
}