package com.jefri.carrent.ui.user.transaction

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.databinding.ItemTransactionBinding
import com.jefri.carrent.utils.ext.setStatusStyle
import com.jefri.carrent.utils.ext.toReadableStatus

class TransactionAdapter(
    private val onItemClick: (Order) -> Unit
) : ListAdapter<Order, TransactionAdapter.TransactionViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionViewHolder {
        val binding = ItemTransactionBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return TransactionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class TransactionViewHolder(private val binding: ItemTransactionBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(order: Order) {
            with(binding) {
                tvUser.text = order.user?.name

                tvOrderCode.text = order.code
                tvMuatan.text = order.mobil?.merk ?: "-"
                tvDate.text = order.date
                tvMitra.text = "${order.mobil?.mitraName}"

                tvAlamatUser.text = order.user?.alamat
                tvAlamatMitra.text = order.mitraAlamat ?: "-"

                tvStatus.text = order.status.toReadableStatus()
                tvStatus.setStatusStyle(order.status)

                root.setOnClickListener {
                    onItemClick(order)
                }
            }
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Order>() {
            override fun areItemsTheSame(oldItem: Order, newItem: Order): Boolean =
                oldItem.code == newItem.code

            override fun areContentsTheSame(oldItem: Order, newItem: Order): Boolean =
                oldItem == newItem
        }
    }
}
