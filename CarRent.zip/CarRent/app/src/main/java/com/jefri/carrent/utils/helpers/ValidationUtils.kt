package com.jefri.carrent.utils.helpers

import android.util.Patterns

object ValidationUtils {

    fun isValidPhone(number: String?): Boolean {
        if (number.isNullOrBlank()) return false
        return number.matches(Regex("^[0-9]{10,15}$"))
    }

    fun isValidEmail(email: String?): Boolean {
        if (email.isNullOrBlank()) return false
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun isValidPassword(password: String?): Boolean {
        if (password.isNullOrBlank()) return false
        return password.length >= 8
    }

    fun isNotEmpty(input: String?): Boolean {
        return !input.isNullOrBlank()
    }

    fun validateField(value: String?, fieldName: String): String? {
        return if (value.isNullOrBlank()) "$fieldName tidak boleh kosong" else null
    }
}