// Mendefinisikan package lokasi file LoginViewModel
package com.jefri.carrent.ui.auth.login

// Import LiveData untuk mengamati perubahan data secara lifecycle-aware
import androidx.lifecycle.LiveData
// Import MutableLiveData untuk mengubah nilai LiveData
import androidx.lifecycle.MutableLiveData
// Import ViewModel sebagai kelas dasar ViewModel
import androidx.lifecycle.ViewModel
// Import viewModelScope untuk menjalankan coroutine sesuai lifecycle ViewModel
import androidx.lifecycle.viewModelScope
// Import AuthenticationRepository sebagai penghubung ke sumber data login
import com.jefri.carrent.data.repository.AuthenticationRepository
// Import coroutine launch untuk menjalankan proses asynchronous
import kotlinx.coroutines.launch
// Import sealed class Result untuk menangani state (Loading, Success, Error)
import com.jefri.carrent.utils.result.Result

// Mendeklarasikan class LoginViewModel yang mewarisi ViewModel
class LoginViewModel(

    // Mendeklarasikan dependency AuthenticationRepository melalui constructor (Dependency Injection)
    private val authenticationRepository: AuthenticationRepository

) : ViewModel() {

    // MutableLiveData untuk menyimpan dan mengubah state login (hanya bisa diubah di dalam ViewModel)
    private val _loginState = MutableLiveData<Result<String?>>()
    
    // LiveData publik untuk di-observe oleh Activity/Fragment (tidak bisa diubah dari luar)
    val loginState: LiveData<Result<String?>>
        get() = _loginState

    // Fungsi login yang menerima email, password, dan role
    fun login(
        email: String,      // Parameter email pengguna
        password: String,   // Parameter password pengguna
        role: String,       // Parameter role (admin/user/mitra)
    ) = viewModelScope.launch {   // Menjalankan coroutine dalam scope ViewModel
        
        // Mengubah state menjadi Loading sebelum proses login dijalankan
        _loginState.value = Result.Loading

        // Memanggil fungsi login dari repository (biasanya mengakses Firebase/API/database)
        val result = authenticationRepository.login(email, password, role)
        
        // Mengirim hasil login (Success atau Error) ke LiveData
        _loginState.value = result
    }

}