package com.jefri.carrent.data.repository

import com.google.firebase.auth.FirebaseUser
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.model.User
import com.jefri.carrent.data.services.firebase.AuthService
import com.jefri.carrent.data.services.firebase.ChatService
import com.jefri.carrent.data.services.firebase.NotificationService
import com.jefri.carrent.data.services.firebase.OrderService
import com.jefri.carrent.data.services.firebase.PaymentService
import com.jefri.carrent.utils.result.Result

class AdminRepository private constructor(
    private val firebaseAuthService: AuthService,
    private val chatService: ChatService,
    private val orderService: OrderService,
    private val notificationService: NotificationService,
    private val paymentService: PaymentService
) {
    suspend fun getUserDataFromFirestore(uid: String? = null): User? {
        return try {
            val uid = uid ?: getCurrentUser()?.uid ?: return null
            return firebaseAuthService.getFirestoreUser(uid)
        } catch (e: Exception) {
            null
        }
    }

    fun getCurrentUser(): FirebaseUser? {
        return firebaseAuthService.getCurrentUser()
    }

    suspend fun getCurrentOrder(orderId: String) = orderService.getCurrentOrder(orderId)

    suspend fun getMitraInactiveData() = firebaseAuthService.getMitraInactiveData()

    suspend fun acceptMitra(uid: String) = firebaseAuthService.acceptMitra(uid)

    suspend fun getOrdersData(
        uid: String? = null,
        status: List<String>? = null,
    ): Result<List<Order>> {
        return when (val result = orderService.getOrdersData(
            uid = uid,
            status = status
        )) {
            is Result.Error -> result

            is Result.Success -> {
                val ordersWithAlamat = result.data.map { order ->
                    val mitraId = order.mobil?.mitraId

                    if (mitraId.isNullOrEmpty()) {
                        order
                    } else {
                        val mitra = firebaseAuthService.getFirestoreUser(mitraId)
                        order.copy(
                            mitraAlamat = mitra?.alamat
                        )
                    }
                }

                Result.Success(ordersWithAlamat)
            }
            else -> Result.Error("Gagal memuat data")
        }
    }

    suspend fun acceptOrder(
        orderId: String,
    ) = orderService.acceptOrder(
        orderId = orderId,
        role = "admin"
    )

    suspend fun cancelOrder(
        orderId: String,
        reason: String,
        cancelBy: String?,
    ) = orderService.cancelOrder(
        orderId = orderId,
        reason = reason,
        cancelBy = cancelBy
    )

    fun getUserChats(userId: String) = chatService.getUserChatsFlow(userId)

    suspend fun getNotification() = notificationService.getNotifications()

    // Payment Methods
    suspend fun getPaymentMethods() = paymentService.getPaymentMethods()
    suspend fun updatePaymentNumber(id: String, number: String) = paymentService.updatePaymentNumber(id, number)

    companion object {
        @Volatile
        private var INSTANCE: AdminRepository? = null

        fun getInstance(
            firebaseAuthService: AuthService,
            chatService: ChatService,
            orderService: OrderService,
            notificationService: NotificationService,
            paymentService: PaymentService
        ): AdminRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AdminRepository(
                    firebaseAuthService,
                    chatService,
                    orderService,
                    notificationService,
                    paymentService
                ).also {
                    INSTANCE = it
                }
            }
        }
    }
}