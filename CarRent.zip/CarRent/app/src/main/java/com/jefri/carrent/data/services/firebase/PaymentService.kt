package com.jefri.carrent.data.services.firebase

import com.google.firebase.firestore.FirebaseFirestore
import com.jefri.carrent.data.model.PaymentMethod
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.tasks.await

class PaymentService(
    private val firestore: FirebaseFirestore
) {
    suspend fun getPaymentMethods(): Result<List<PaymentMethod>> {
        return try {
            val snapshot = firestore.collection("payment_methods").get().await()
            val paymentMethods = snapshot.documents.mapNotNull { doc ->
                doc.toObject(PaymentMethod::class.java)?.copy(id = doc.id)
            }
            Result.Success(paymentMethods)
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun updatePaymentNumber(id: String, number: String): Result<String> {
        return try {
            firestore.collection("payment_methods")
                .document(id)
                .update("number", number)
                .await()
            Result.Success("Berhasil memperbarui nomor pembayaran")
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }
}