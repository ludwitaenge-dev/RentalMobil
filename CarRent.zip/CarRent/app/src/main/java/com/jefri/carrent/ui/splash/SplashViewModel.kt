package com.jefri.carrent.ui.splash

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.repository.AuthenticationRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashViewModel(
    private val authenticationRepository: AuthenticationRepository
) : ViewModel() {

    private val _splashState = MutableLiveData<SplashState>()
    val splashState: LiveData<SplashState> get() = _splashState

    init {
        checkLogin()
    }

    fun checkLogin() = viewModelScope.launch {
        _splashState.value = SplashState.Loading
        delay(2000)
        if (authenticationRepository.isLoggedIn()) {
            val user = authenticationRepository.getUserDataFromFirestore()
            if (user != null) {
                _splashState.value = SplashState.LoggedIn(user.role)
            } else {
                _splashState.value = SplashState.Error("User data not found")
            }
        } else {
            _splashState.value = SplashState.NotLoggedIn
        }
    }
}