package com.jefri.carrent.ui.admin.user

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.jefri.carrent.databinding.FragmentUserListBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.result.Result

class MitraListFragment : Fragment() {

    private var _binding: FragmentUserListBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: UserAdapter

    private val viewModel by viewModels<UserAdminViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUserListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecycler()
        observeData()
    }

    private fun setupRecycler() {
        adapter = UserAdapter { user, isChecked ->
            viewModel.updateUserStatus(user.uid, isChecked)
        }

        binding.rvData.adapter = adapter
    }

    private fun observeData() {
        viewModel.users.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> binding.progressBar.show()
                is Result.Success -> {
                    binding.progressBar.hide()
                    val mitra = result.data.filter { it.role == "mitra" }

                    binding.tvNoData.visibility =
                        if (mitra.isEmpty()) View.VISIBLE else View.GONE

                    adapter.submitList(mitra)
                }

                is Result.Error -> binding.progressBar.hide()
            }
        }
    }
}