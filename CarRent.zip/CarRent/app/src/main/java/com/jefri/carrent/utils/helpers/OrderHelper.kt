package com.jefri.carrent.utils.helpers

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object OrderHelper {
    fun generateOrderCode(): String {
        val datePart = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        val randomPart = (1000..9999).random()
        return "ORD-$datePart-$randomPart"
    }

}