package com.jefri.carrent.ui.admin.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.User
import com.jefri.carrent.data.repository.AdminRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch

class DetailMitraAdminViewModel(
    private val adminRepository: AdminRepository
) : ViewModel() {

    private val _mitraData = MutableLiveData<User>()
    val mitraData: MutableLiveData<User>
        get() = _mitraData

    private val _stateAcceptMitra = MutableLiveData<Result<String>>()
    val stateAcceptMitra: LiveData<Result<String>> = _stateAcceptMitra

    fun getMitraData(uid: String) =
        viewModelScope.launch {
            _mitraData.value = adminRepository.getUserDataFromFirestore(uid)
        }

    fun acceptMitra(
        uid: String
    ) {
        _stateAcceptMitra.value = Result.Loading

        viewModelScope.launch {
            val result = adminRepository.acceptMitra(uid)
            _stateAcceptMitra.value = result
        }
    }
}