package com.jefri.carrent.utils.helpers

object StatusMapping {
    fun getShortStatus(status: String?): String? {
        return when (status) {
            "Belum Dibayar" -> "belum_dibayar"
            "Menunggu Konfirmasi Admin" -> "menunggu_konfirmasi_admin"
            "Menunggu Konfirmasi Mitra" -> "menunggu_konfirmasi_mitra"
            "Diproses" -> "diproses"
            "Selesai" -> "selesai"
            "Dibatalkan" -> "dibatalkan"
            else -> null
        }
    }
}
