package com.jefri.carrent.ui.admin.home

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.bumptech.glide.Glide
import com.jefri.carrent.R
import com.jefri.carrent.data.model.User
import com.jefri.carrent.databinding.ActivityDetailMitraAdminBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.result.Result
import kotlin.getValue

class DetailMitraAdminActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailMitraAdminBinding
    private var userUid: String? = null

    private val viewModel by viewModels<DetailMitraAdminViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        binding = ActivityDetailMitraAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
    }

    private fun init() {
        receiveIntentFromMain()
        setupBtnListener()
        observeMitraData()
        observeAcceptMitra()
    }

    private fun observeMitraData() {
        viewModel.getMitraData(uid = userUid.toString())
        viewModel.mitraData.observe(this) { mitra ->
            setupMitraData(mitra)
        }
    }

    private fun observeAcceptMitra() {
        viewModel.stateAcceptMitra.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.btnAccMitra.setLoading(true)
                    }
                    is Result.Success -> {
                        binding.btnAccMitra.setLoading(false)
                        showToast("Berhasil acc mitra")
                        setResult(RESULT_OK)
                        finish()
                    }
                    is Result.Error -> {
                        binding.btnAccMitra.setLoading(false)
                        showToast(result.toString())
                    }
                }
            }
        }
    }

    private fun setupBtnListener() {
        with (binding) {
            btnAccMitra.setOnClickListener {
                viewModel.acceptMitra(uid = userUid.toString())
            }

            ivBack.setOnClickListener {
                finish()
            }
        }
    }

    private fun setupMitraData(mitra: User) {
        with(binding) {
            etName.setText(mitra.name)
            etNotel.setText(mitra.noTelp.toString())
            etAlamat.setText(mitra.alamat)
            etEmail.setText(mitra.email)

            Glide.with(this@DetailMitraAdminActivity)
                .load(mitra.dokumen)
                .centerCrop()
                .into(ivPreview)
        }
    }

    private fun receiveIntentFromMain() {
        userUid = intent.getStringExtra(EXTRA_USER_UID)
    }

    companion object {
        const val EXTRA_USER_UID = "extra_user_uid"
    }
}