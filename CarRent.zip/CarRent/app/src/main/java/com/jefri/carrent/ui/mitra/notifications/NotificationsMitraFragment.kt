package com.jefri.carrent.ui.mitra.notifications

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.jefri.carrent.databinding.FragmentNotificationsMitraBinding
import com.jefri.carrent.ui.NotificationAdapter
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.result.Result
import kotlin.getValue

class NotificationsMitraFragment : Fragment() {

    private var _binding: FragmentNotificationsMitraBinding? = null
    private val binding get() = _binding!!

    private lateinit var notificationAdapter: NotificationAdapter

    private val notificationViewModel by viewModels<NotificationsMitraViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNotificationsMitraBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        init()
    }

    private fun init() {
        setupRecyclerView()
        observeNotificationData()
    }

    private fun observeNotificationData() {
        notificationViewModel.notificationData.observe(viewLifecycleOwner) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.progressBar.show()
                    }

                    is Result.Success -> {
                        binding.progressBar.hide()
                        notificationAdapter.submitList(result.data)
                    }

                    is Result.Error -> {
                        binding.progressBar.hide()
                        showToast("Error: ${result.message}")
                    }
                }
            }
        }
    }

    private fun setupRecyclerView() {
        notificationAdapter = NotificationAdapter()
        binding.rvNotificationList.adapter = notificationAdapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}