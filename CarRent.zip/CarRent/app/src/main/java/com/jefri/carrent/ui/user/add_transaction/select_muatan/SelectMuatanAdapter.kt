package com.jefri.carrent.ui.user.add_transaction.select_muatan

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.jefri.carrent.R
import com.jefri.carrent.data.model.Muatan
import com.jefri.carrent.databinding.ItemMuatanBinding
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.toRupiah

class SelectMuatanAdapter(
    private val onItemSelected: (Muatan) -> Unit
) : ListAdapter<Muatan, SelectMuatanAdapter.MuatanViewHolder>(DIFF_CALLBACK) {

    private var selectedPosition = RecyclerView.NO_POSITION

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MuatanViewHolder {
        val binding = ItemMuatanBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MuatanViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MuatanViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item, position == selectedPosition)
    }

    inner class MuatanViewHolder(private val binding: ItemMuatanBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Muatan, isSelected: Boolean) = with(binding) {
            Glide.with(binding.ivMuatanImage.context)
                .load(item.imageUrl)
                .placeholder(R.drawable.bg_image_placeholder)
                .centerCrop()
                .into(binding.ivMuatanImage)

            tvRating.text = item.averageRating.toString()
            tvRatingCount.text =
                binding.root.context.getString(R.string.total_rating_count, item.totalRatingCount)
            tvCapacity.text = item.kapasitas
            tvMitra.text = item.mitraName
            tvHarga.text = item.harga.toRupiah()

            root.strokeColor = if (isSelected)
                ContextCompat.getColor(root.context, R.color.blue)
            else
                ContextCompat.getColor(root.context, android.R.color.transparent)

            if (item.isBooked) {
                tvStatusLabel.show()
                tvStatusLabel.text = "Sedang Dipesan"
            } else {
                tvStatusLabel.hide()
                root.setOnClickListener {
                    val previous = selectedPosition
                    selectedPosition = bindingAdapterPosition
                    notifyItemChanged(previous)
                    notifyItemChanged(selectedPosition)
                    onItemSelected(item)
                }
            }
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Muatan>() {
            override fun areItemsTheSame(oldItem: Muatan, newItem: Muatan) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Muatan, newItem: Muatan) = oldItem == newItem
        }
    }
}