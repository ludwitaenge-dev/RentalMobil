package com.jefri.carrent.utils.result

sealed class Result<out R> private constructor() {
    data class Success<out T>(val data: T) : Result<T>()
    data class Error(
        val message: String,
        val errorCode: String? = null
    ) : Result<Nothing>()
    data object Loading : Result<Nothing>()
}