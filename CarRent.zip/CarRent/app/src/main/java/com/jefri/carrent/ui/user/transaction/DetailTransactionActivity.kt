package com.jefri.carrent.ui.user.transaction

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.bumptech.glide.Glide
import com.jefri.carrent.R
import com.jefri.carrent.custom_ui.bottom_sheet.RatingBottomSheet
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.databinding.ActivityDetailTransactionBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.user.chat.DetailChatActivity
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.setStatusStyle
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.ext.toReadableStatus
import com.jefri.carrent.utils.ext.toRupiah
import com.jefri.carrent.utils.helpers.DateHelper
import com.jefri.carrent.utils.result.Result

class DetailTransactionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailTransactionBinding
    private var orderId: String? = null

    private var selectedImageUri: Uri? = null
    private val viewModel by viewModels<DetailTransactionViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private var order: Order? = null

    private var bottomSheet: RatingBottomSheet? = null

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            selectedImageUri = it
            binding.ivPreview.show()
            binding.ivUploadIcon.hide()
            binding.btnClear.show()
            binding.ivPreview.setImageURI(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        binding = ActivityDetailTransactionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
    }

    private fun init() {
        receiveIntentFromMain()
        observeOrderData()
        setupBtnListener()
        observeUploadResult()
        observeAccState()
        observeChatWithAdmin()
        observeChatWithMitra()
    }

    private fun observeOrderData() {
        viewModel.getCurrentOrderData(orderId.toString())
        viewModel.orderData.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.progressBar.show()
                        binding.btnHubungiMitra.enable(false)
                    }

                    is Result.Success -> {
                        binding.progressBar.hide()
                        binding.btnHubungiMitra.enable(true)
                        val data = result.data
                        order = data
                        setupOrderData(data)
                    }

                    is Result.Error -> {
                        binding.progressBar.hide()
                        binding.btnHubungiMitra.enable(true)
                        showToast(result.toString())
                        finish()
                    }
                }
            }
        }
    }

    private fun observeUploadResult() {
        viewModel.stateUploadBukti.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.btnUpload.setLoading(true)
                    }

                    is Result.Success -> {
                        binding.btnUpload.setLoading(false)
                        showToast("Sukses Upload")
                        setResult(RESULT_OK)
                        finish()
                    }

                    is Result.Error -> {
                        binding.btnUpload.setLoading(false)
                        showToast(result.toString())
                    }
                }
            }
        }
    }

    private fun observeAccState() {
        viewModel.stateTerimaOrder.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        bottomSheet?.setLoading(true)
                    }
                    is Result.Success -> {
                        bottomSheet?.setLoading(false)
                        bottomSheet?.dismiss()
                        showToast("Berhasil menyelesaikan transaksi")
                        setResult(RESULT_OK)
                        finish()
                    }
                    is Result.Error -> {
                        bottomSheet?.setLoading(false)
                        showToast(result.toString())
                    }
                }
            }
        }
    }

    private fun observeChatWithAdmin() {
        viewModel.stateChatAdmin.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.btnHubungiAdmin.setLoading(true)
                    }

                    is Result.Success -> {
                        binding.btnHubungiAdmin.setLoading(false)
                        val chatId = result.data
                        val intentToDetailChat = Intent(this, DetailChatActivity::class.java)
                        intentToDetailChat.putExtra(DetailChatActivity.EXTRA_CHAT_ID, chatId)
                        startActivity(intentToDetailChat)
                    }

                    is Result.Error -> {
                        binding.btnHubungiAdmin.setLoading(false)
                        showToast(result.toString())
                    }
                }
            }
        }
    }

    private fun observeChatWithMitra() {
        viewModel.stateChatMitra.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.btnHubungiMitra.setLoading(true)
                    }

                    is Result.Success -> {
                        binding.btnHubungiMitra.setLoading(false)
                        val chatId = result.data
                        val intentToDetailChat = Intent(this, DetailChatActivity::class.java)
                        intentToDetailChat.putExtra(DetailChatActivity.EXTRA_CHAT_ID, chatId)
                        startActivity(intentToDetailChat)
                    }

                    is Result.Error -> {
                        binding.btnHubungiMitra.setLoading(false)
                        showToast(result.toString())
                    }
                }
            }
        }
    }

    private fun setupBtnListener() {
        with(binding) {
            llUploadPlaceholder.setOnClickListener {
                Log.d("TAG", "Upload click ")
                pickImageLauncher.launch("image/*")
            }

            btnUpload.setOnClickListener {
                if (selectedImageUri == null) {
                    showToast("Pilih gambar dulu")
                    return@setOnClickListener
                }

                viewModel.uploadBuktiPembayaran(
                    orderId.toString(),
                    selectedImageUri!!
                )
            }

            btnSelesai.setOnClickListener {
                bottomSheet = RatingBottomSheet { rating, setLoading, _ ->
                    setLoading(true)
                    viewModel.acceptOrder(orderId = orderId.toString(), rating = rating)
                }
                bottomSheet?.show(supportFragmentManager, "RatingBottomSheet")
            }

            btnHubungiAdmin.setOnClickListener {
                viewModel.chatWithAdmin()
            }

            btnHubungiMitra.setOnClickListener {
                viewModel.chatWithMitra(
                    mitraId = order?.mobil?.mitraId
                )
            }

            btnClear.setOnClickListener {
                selectedImageUri = null
                btnClear.hide()
                ivPreview.hide()
                ivUploadIcon.show()
                ivPreview.setImageURI(null)
            }

            ivBack.setOnClickListener {
                finish()
            }
        }
    }

    private fun setupOrderData(order: Order) {
        with(binding) {
            tvOrderCode.text = order.code
            tvStatus.text = order.status.toReadableStatus()
            tvStatus.setStatusStyle(order.status)

            tvName.text = order.user?.name
            tvNotel.text = order.user?.noTelp
            tvAddress.text = order.user?.alamat
            tvDate.text = order.date

            tvMobil.text = order.mobil?.merk

            val hargaPerHari = order.mobil?.hargaPerHari
            val totalHari = DateHelper.getTotalDaysFromRange(order.date)

            tvHarga.text = hargaPerHari?.toRupiah()
            tvTotalHari.text = DateHelper.getTotalDaysFromRange(order.date).toString()
            tvTotal.text = (hargaPerHari?.times(totalHari))?.toRupiah()
            tvMetodePembayaran.text = order.metodePembayaran
            tvNomorPembayaran.text = order.nomorPembayaran

            if (order.buktiTransfer.isNullOrEmpty()) {
                ivPreview.hide()
                llUploadPlaceholder.show()
                btnClear.hide()
                Log.d("TAG", "Bukti null ")
            } else {
                ivPreview.show()
                llUploadPlaceholder.hide()
                Log.d("TAG", "Bukkti Ada ")
            }

            Glide.with(ivPreview.context)
                .load(order.buktiTransfer)
                .placeholder(R.drawable.ic_upload)
                .centerCrop()
                .into(ivPreview)

            btnUpload.hide()
            btnSelesai.hide()
            llDibatalkanOleh.hide()
            llDibatalkanKarena.hide()
            llDibatalkanTanggal.hide()

            when (order.status) {
                "belum_dibayar" -> {
                    btnUpload.show()
                }

                "menunggu_konfirmasi_admin" -> {
                    btnHubungiAdmin.show()
                }
                "menunggu_konfirmasi_mitra" -> {
                    btnHubungiMitra.show()
                }
                "diproses" -> {
                    btnSelesai.show()
                }

                "selesai" -> {}
                "dibatalkan" -> {
                    tvDibatalkan.text = order.cancelBy
                    tvDibatalkanKarena.text = order.cancelReason
                    tvDibatalkanTanggal.text = DateHelper.formatFirebaseTimestamp(order.updatedAt)

                    llDibatalkanOleh.show()
                    llDibatalkanKarena.show()
                    llDibatalkanTanggal.show()
                }
                else -> ""
            }
        }
    }

    private fun receiveIntentFromMain() {
        orderId = intent.getStringExtra(EXTRA_ORDER_ID)
    }

    companion object {
        const val EXTRA_ORDER_ID = "extra_order_id"
    }

}