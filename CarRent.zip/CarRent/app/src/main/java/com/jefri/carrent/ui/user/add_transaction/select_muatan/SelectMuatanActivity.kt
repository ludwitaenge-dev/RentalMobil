package com.jefri.carrent.ui.user.add_transaction.select_muatan

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.jefri.carrent.R
import com.jefri.carrent.data.model.Muatan
import com.jefri.carrent.databinding.ActivitySelectMuatanBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.user.add_transaction.add_data.AddTransactionDataActivity
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.result.Result

class SelectMuatanActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySelectMuatanBinding
    private lateinit var adapter: SelectMuatanAdapter
    private var selectedMuatan: Muatan? = null

    private val viewModel by viewModels<SelectMuatanViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        binding = ActivitySelectMuatanBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
    }

    private fun init() {
        setupRecyclerView()
        observeData()
        setupBtnListener()
    }

    private fun setupRecyclerView() {
        adapter = SelectMuatanAdapter { muatan ->
            selectedMuatan = muatan
            binding.btnNext.isEnabled = true
        }
        binding.rvMuatan.adapter = adapter
    }

    private fun observeData() {
        viewModel.muatanData.observe(this) { result ->
            when (result) {
                is Result.Loading -> binding.progressBar.visibility = View.VISIBLE
                is Result.Success -> {
                    binding.progressBar.visibility = View.GONE
                    adapter.submitList(result.data)
                }
                is Result.Error -> {
                    binding.progressBar.visibility = View.GONE
                    showToast(result.message)
                }
            }
        }
    }

    private fun setupBtnListener() {
        with (binding) {
            btnNext.setOnClickListener {
                selectedMuatan?.let {
                    val intent =
                        Intent(this@SelectMuatanActivity, AddTransactionDataActivity::class.java)
                    intent.putExtra("muatan", selectedMuatan)
                    startActivity(intent)
                } ?: showToast("Mohon pilih muatan terlebih dahulu")
            }

            ivBack.setOnClickListener {
                finish()
            }
        }
    }
}