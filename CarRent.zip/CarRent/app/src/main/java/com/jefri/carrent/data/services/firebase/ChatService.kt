package com.jefri.carrent.data.services.firebase

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.jefri.carrent.data.model.Chat
import com.jefri.carrent.data.model.Message
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

@Suppress("UNCHECKED_CAST")
class ChatService(
    firebaseDatabase: FirebaseDatabase
) {
    private val db = firebaseDatabase.reference.child("chats")

    suspend fun createChatRoomIfNotExists(
        userId: String,
        adminId: String,
        userName: String? = null,
        adminName: String? = null
    ): Result<String> {
        val chatId = if (userId < adminId) "${userId}_${adminId}" else "${adminId}_${userId}"
        val chatRef = db.child(chatId)

        return try {
            val snapshot = chatRef.get().await()
            if (!snapshot.exists()) {
                val participants = mapOf(
                    userId to userName,
                    adminId to adminName
                )

                val chat = Chat(
                    participants = participants,
                    lastMessage = "",
                    timestamp = System.currentTimeMillis()
                )
                chatRef.setValue(chat).await()
            }
            Result.Success(chatId)
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun sendMessage(chatId: String, senderId: String, text: String): Result<String> {
        val chatRef = db.child(chatId)
        val newMessageRef = chatRef.child("messages").push()
        val message = Message(senderId, text, System.currentTimeMillis())

        return try {
            val updates = hashMapOf<String, Any>(
                "messages/${newMessageRef.key}" to message,
                "lastMessage" to text,
                "timestamp" to System.currentTimeMillis()
            )
            chatRef.updateChildren(updates).await()
            Result.Success(newMessageRef.key)
        } catch (e: Exception) {
            Result.Error(e.toString())
        } as Result<String>
    }

    fun getUserChatsFlow(userId: String) = callbackFlow<Result<List<Pair<String, Chat>>>> {
        val query = db
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val chats = snapshot.children.mapNotNull {
                    val chat = it.getValue(Chat::class.java)
                    val participants = it.child("participants").children.map { p -> p.key }
                    if (participants.contains(userId) && chat != null) {
                        Pair(it.key!!, chat)
                    } else null
                }.sortedByDescending { it.second.timestamp }

                trySend(Result.Success(chats))
            }

            override fun onCancelled(error: DatabaseError) {
                trySend(Result.Error(error.message))
            }
        }

        query.addValueEventListener(listener)
        awaitClose { query.removeEventListener(listener) }
    }

    fun listenMessagesFlow(chatId: String) = callbackFlow<Result<List<Message>>> {
        val messagesRef = db.child(chatId).child("messages")

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val messages = snapshot.children.mapNotNull { it.getValue(Message::class.java) }
                trySend(Result.Success(messages))
            }

            override fun onCancelled(error: DatabaseError) {
                trySend(Result.Error(error.message))
            }
        }

        messagesRef.addValueEventListener(listener)
        awaitClose { messagesRef.removeEventListener(listener) }
    }

    suspend fun getChatDetail(chatId: String): Chat? {
        return try {
            val snapshot = db.child(chatId).get().await()
            snapshot.getValue(Chat::class.java)
        } catch (_: Exception) {
            null
        }
    }
}