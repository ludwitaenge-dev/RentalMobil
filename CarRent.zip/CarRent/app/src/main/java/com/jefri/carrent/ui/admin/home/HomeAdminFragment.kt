package com.jefri.carrent.ui.admin.home

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.viewModels
import com.jefri.carrent.custom_ui.bottom_sheet.LogoutBottomSheet
import com.jefri.carrent.data.model.User
import com.jefri.carrent.databinding.FragmentHomeAdminBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.admin.settings.SettingsActivity
import com.jefri.carrent.ui.admin.transaction.DetailTransactionAdminActivity
import com.jefri.carrent.ui.user.transaction.TransactionAdapter
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.result.Result
import kotlin.getValue

class HomeAdminFragment : Fragment() {
    private var _binding: FragmentHomeAdminBinding? = null
    private val binding get() = _binding!!

    private lateinit var user: User
    private val homeAdminViewModel by viewModels<HomeAdminViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    private lateinit var transactionAdapter: TransactionAdapter
    private lateinit var mitraHomeAdapter: MitraHomeAdapter

    private lateinit var detailTransactionLauncher: ActivityResultLauncher<Intent>
    private lateinit var detailMitraLauncher: ActivityResultLauncher<Intent>

    private fun isFirstLoad(): Boolean = binding.srRefresh.isRefreshing.not()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeAdminBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        detailTransactionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                homeAdminViewModel.refreshAll()
            }
        }

        detailMitraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                homeAdminViewModel.refreshAll()
            }
        }

        init()
    }

    private fun init() {
        setupRecycleViewActiveTransaction()
        setupRecycleViewMitra()
        setupGreeting()
        observeUserData()
        observeTransaction()
        observeMitra()
        setupBtnListener()
        observeRefresh()
    }

    private fun observeTransaction() {
        homeAdminViewModel.orderData.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {
                    if (isFirstLoad()) binding.progressBar.show()
                }

                is Result.Success -> {
                    binding.progressBar.hide()
                    val orderData = result.data
                    if (orderData.isEmpty()) {
                        binding.rvActiveTransaction.hide()
                        binding.tvNoActiveTransaction.show()
                    } else {
                        binding.rvActiveTransaction.show()
                        binding.tvNoActiveTransaction.hide()
                        transactionAdapter.submitList(orderData)
                    }

                }

                is Result.Error -> {
                    binding.progressBar.hide()
                    showToast(result.message)
                }
            }
        }
    }

    private fun observeMitra() {
        homeAdminViewModel.mitraData.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {
                    if (isFirstLoad()) binding.progressBar.show()
                }

                is Result.Success -> {
                    binding.progressBar.hide()
                    val mitraData = result.data
                    if (mitraData.isEmpty()) {
                        binding.rvMitra.hide()
                        binding.tvNoVerifikasiMitra.show()
                    } else {
                        binding.rvMitra.show()
                        binding.tvNoVerifikasiMitra.hide()
                        mitraHomeAdapter.submitList(mitraData)
                    }

                }

                is Result.Error -> {
                    binding.progressBar.hide()
                    showToast(result.message)
                }
            }
        }
    }

    private fun observeUserData() {
        homeAdminViewModel.user.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {}
                is Result.Success -> {
                    user = result.data!!
                    binding.tvUserName.text = user.name
                }
                is Result.Error -> {
                    showToast("Gagal ambil data user: ${result.message}")
                }
            }
        }
    }

    private fun setupRecycleViewActiveTransaction() {
        transactionAdapter = TransactionAdapter { order ->
            val intent = Intent(requireContext(), DetailTransactionAdminActivity::class.java)
            intent.putExtra(DetailTransactionAdminActivity.EXTRA_ORDER_ID, order.id)
            detailTransactionLauncher.launch(intent)
        }
        binding.rvActiveTransaction.adapter = transactionAdapter
    }

    private fun setupRecycleViewMitra() {
        mitraHomeAdapter = MitraHomeAdapter { user ->
            val intent = Intent(requireContext(), DetailMitraAdminActivity::class.java)
            intent.putExtra(DetailMitraAdminActivity.EXTRA_USER_UID, user.uid)
            detailMitraLauncher.launch(intent)
        }
        binding.rvMitra.adapter = mitraHomeAdapter
    }

    private fun observeRefresh() {
        homeAdminViewModel.isRefreshing.observe(viewLifecycleOwner) { refreshing ->
            binding.srRefresh.isRefreshing = refreshing
        }
    }

    private fun setupBtnListener() {
        with (binding) {
            srRefresh.setOnRefreshListener {
                homeAdminViewModel.refreshAll()
            }

            btnLogout.setOnClickListener {
                val logoutBottomSheet = LogoutBottomSheet()
                logoutBottomSheet.show(parentFragmentManager, logoutBottomSheet.tag)
            }

            btnSettings.setOnClickListener {
                startActivity(Intent(requireContext(), SettingsActivity::class.java))
            }
        }
    }

    private fun setupGreeting() {
        binding.tvGreeting.text = homeAdminViewModel.getGreetingText()
    }

    fun refreshTransaction() {
        homeAdminViewModel.refreshAll()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}