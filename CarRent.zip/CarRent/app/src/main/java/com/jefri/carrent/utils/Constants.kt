package com.jefri.carrent.utils

object Constants {
    const val ADMIN_UID = "Ru53BTITVFXp1hraFTHcOVjNOy83"
}