package com.jefri.carrent.ui.admin.chat

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.jefri.carrent.databinding.FragmentChatAdminBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.user.chat.ChatAdapter
import com.jefri.carrent.ui.user.chat.DetailChatActivity
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.getValue

class ChatAdminFragment : Fragment() {

    private var _binding: FragmentChatAdminBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: ChatAdapter

    private val chatAdminViewModel by viewModels<ChatAdminViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentChatAdminBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        observeChat(chatAdminViewModel.getUserId() ?: "")
    }

    private fun observeChat(userId: String) {
        viewLifecycleOwner.lifecycleScope.launch {
            chatAdminViewModel.loadUserChats(userId)
            chatAdminViewModel.chatList.collectLatest { result ->
                when (result) {
                    is Result.Loading -> {
                        binding.progressBar.show()
                    }
                    is Result.Success -> {
                        binding.progressBar.hide()
                        adapter.submitList(result.data)
                    }
                    is Result.Error -> {
                        binding.progressBar.hide()
                        showToast("Error: ${result.message}")
                    }
                }

            }
        }
    }

    private fun setupRecyclerView() {
        adapter = ChatAdapter(chatAdminViewModel.getUserId().toString()) { chatId, chat ->
            // Go to detail activity chat
            val intentToDetailChat = Intent(requireContext(), DetailChatActivity::class.java)
            intentToDetailChat.putExtra(DetailChatActivity.EXTRA_CHAT_ID, chatId)
            startActivity(intentToDetailChat)
        }
        binding.rvChatList.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}