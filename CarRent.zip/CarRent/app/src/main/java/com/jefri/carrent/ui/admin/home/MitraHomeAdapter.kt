package com.jefri.carrent.ui.admin.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.jefri.carrent.data.model.User
import com.jefri.carrent.databinding.ItemMitraBinding

class MitraHomeAdapter(
    private val onItemClick: ((User) -> Unit)? = null
) : ListAdapter<User, MitraHomeAdapter.MitraViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MitraViewHolder {
        val binding = ItemMitraBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MitraViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MitraViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    inner class MitraViewHolder(private val binding: ItemMitraBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: User) {
            with(binding) {
                tvMitraName.text = item.name
                tvAddress.text = item.alamat
                tvPhone.text = item.noTelp

                root.setOnClickListener { onItemClick?.invoke(item) }
            }
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<User>() {
            override fun areItemsTheSame(oldItem: User, newItem: User): Boolean =
                oldItem.uid == newItem.uid

            override fun areContentsTheSame(oldItem: User, newItem: User): Boolean =
                oldItem == newItem
        }
    }
}
