// Mendefinisikan package lokasi file AdditionalInformationMitraActivity
package com.jefri.carrent.ui.mitra.additional

// Import Uri untuk merepresentasikan lokasi file gambar
import android.net.Uri
// Import Bundle untuk menyimpan state Activity
import android.os.Bundle
// Import enableEdgeToEdge untuk tampilan full layar
import androidx.activity.enableEdgeToEdge
// Import Activity Result API untuk mengambil hasil dari aktivitas lain (galeri)
import androidx.activity.result.contract.ActivityResultContracts
// Import viewModels delegate untuk menghubungkan ViewModel dengan Activity
import androidx.activity.viewModels
// Import AppCompatActivity sebagai superclass Activity
import androidx.appcompat.app.AppCompatActivity
// Import ContextCompat untuk mengakses warna resource
import androidx.core.content.ContextCompat
// Import ViewCompat untuk kompatibilitas pengaturan window inset
import androidx.core.view.ViewCompat
// Import WindowInsetsCompat untuk menangani system bars
import androidx.core.view.WindowInsetsCompat
// Import WindowInsetsControllerCompat untuk mengatur warna icon status bar
import androidx.core.view.WindowInsetsControllerCompat
// Import resource R (warna, dll)
import com.jefri.carrent.R
// Import ViewBinding untuk layout ActivityAdditionalInformationMitra
import com.jefri.carrent.databinding.ActivityAdditionalInformationMitraBinding
// Import ViewModelFactory untuk membuat instance ViewModel
import com.jefri.carrent.ui.ViewModelFactory
// Import extension hide() untuk menyembunyikan view
import com.jefri.carrent.utils.ext.hide
// Import extension show() untuk menampilkan view
import com.jefri.carrent.utils.ext.show
// Import extension showToast() untuk menampilkan toast
import com.jefri.carrent.utils.ext.showToast
// Import sealed class Result untuk menangani state (Loading, Success, Error)
import com.jefri.carrent.utils.result.Result

// Mendeklarasikan class AdditionalInformationMitraActivity
class AdditionalInformationMitraActivity : AppCompatActivity() {

    // Variabel binding untuk mengakses komponen layout
    private lateinit var binding: ActivityAdditionalInformationMitraBinding

    // Variabel untuk menyimpan URI gambar yang dipilih
    private var selectedImageUri: Uri? = null

    // Inisialisasi ViewModel menggunakan ViewModelFactory
    private val viewModel by viewModels<AdditionalInformationMitraViewModel> {
        ViewModelFactory.getInstance(this)
    }

    // Launcher untuk membuka galeri dan memilih gambar
    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent() // Kontrak untuk memilih file
    ) { uri: Uri? -> // Callback ketika gambar dipilih
        
        // Jika uri tidak null
        uri?.let {
            selectedImageUri = it // Simpan URI gambar
            
            // Tampilkan preview gambar dan tombol clear
            binding.ivPreview.show()
            binding.ivUploadIcon.hide()
            binding.btnClear.show()
            
            // Set gambar ke ImageView
            binding.ivPreview.setImageURI(it)
        }
    }

    // Fungsi pertama yang dipanggil saat Activity dibuat
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        enableEdgeToEdge() // Mengaktifkan tampilan edge-to-edge
        
        // Mengatur warna status bar
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        
        // Mengatur ikon status bar menjadi warna terang
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        
        // Menghubungkan binding dengan layout XML
        binding = ActivityAdditionalInformationMitraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Mengatur padding agar tidak tertutup system bars
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init() // Panggil fungsi inisialisasi
    }

    // Fungsi untuk inisialisasi awal
    private fun init() {
        setupBtnListener()              // Mengatur aksi tombol
        observeStateUpdateInfoMitra()   // Mengamati perubahan state update data
    }

    // Fungsi untuk mengamati LiveData stateUpdateInfoMitra
    private fun observeStateUpdateInfoMitra() {
        viewModel.stateUpdateInfoMitra.observe(this) { result ->
            if (result != null) {
                when (result) {
                    
                    // Jika status Loading
                    is Result.Loading -> {
                        binding.btnUpdateInformation.setLoading(true)
                    }
                    
                    // Jika status Success
                    is Result.Success -> {
                        binding.btnUpdateInformation.setLoading(false)
                        showToast("Berhasil Update Data") // Tampilkan pesan sukses
                        setResult(RESULT_OK) // Kirim hasil OK ke Activity sebelumnya
                        finish() // Tutup Activity
                    }
                    
                    // Jika status Error
                    is Result.Error -> {
                        binding.btnUpdateInformation.setLoading(false)
                        showToast(result.message) // Tampilkan pesan error
                    }
                }
            }
        }
    }

    // Fungsi untuk mengatur aksi tombol
    private fun setupBtnListener() {
        with (binding) {
            
            // Listener tombol Update Information
            btnUpdateInformation.setOnClickListener {
                
                // Validasi input alamat dan nomor telepon
                val isValid = etAlamat.validate() and etNotel.validate()

                // Jika gambar belum dipilih
                if (selectedImageUri == null) {
                    showToast("Pilih gambar dulu")
                    return@setOnClickListener
                }

                // Jika form tidak valid, hentikan proses
                if (!isValid) return@setOnClickListener

                // Panggil ViewModel untuk update data mitra
                viewModel.updateInfoMitra(
                    selectedImageUri!!, // URI gambar (dipastikan tidak null)
                    etAlamat.getText(), // Ambil alamat
                    etNotel.getText(),  // Ambil nomor telepon
                )
            }

            // Listener ketika area upload diklik
            llUploadPlaceholder.setOnClickListener {
                pickImageLauncher.launch("image/*") // Buka galeri hanya untuk gambar
            }

            // Listener tombol clear untuk menghapus gambar
            btnClear.setOnClickListener {
                selectedImageUri = null // Hapus URI
                btnClear.hide() // Sembunyikan tombol clear
                ivPreview.hide() // Sembunyikan preview
                ivUploadIcon.show() // Tampilkan ikon upload
                ivPreview.setImageURI(null) // Kosongkan gambar
            }
        }
    }
}