package com.jefri.carrent.ui.user.transaction

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.repository.UserRepository
import kotlinx.coroutines.launch
import com.jefri.carrent.utils.result.Result

class DetailTransactionViewModel(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _orderData = MutableLiveData<Result<Order>>()
    val orderData: LiveData<Result<Order>> = _orderData

    private val _stateUploadBukti = MutableLiveData<Result<String>>()
    val stateUploadBukti: MutableLiveData<Result<String>>
        get() = _stateUploadBukti

    private val _stateTerimaOrder = MutableLiveData<Result<String>>()
    val stateTerimaOrder: MutableLiveData<Result<String>>
        get() = _stateTerimaOrder

    private val _stateChatAdmin = MutableLiveData<Result<String>>()
    val stateChatAdmin: MutableLiveData<Result<String>>
        get() = _stateChatAdmin

    private val _stateChatMitra = MutableLiveData<Result<String>>()
    val stateChatMitra: MutableLiveData<Result<String>>
        get() = _stateChatMitra

    fun getCurrentOrderData(id: String) {
        _orderData.value = Result.Loading
        viewModelScope.launch {
            val result = userRepository.getCurrentOrder(id)
            _orderData.value = result
        }
    }

    fun uploadBuktiPembayaran(
        id: String,
        imageUri: Uri
    ) {
        _stateUploadBukti.value = Result.Loading
        viewModelScope.launch {
            val result = userRepository.uploadBuktiPembayaran(id, imageUri)
            _stateUploadBukti.value = result
        }
    }

    fun acceptOrder(
        orderId: String,
        rating: Int
    ) {
        _stateTerimaOrder.value = Result.Loading
        viewModelScope.launch {
            val result = userRepository.acceptOrder(orderId, rating)
            _stateTerimaOrder.value = result
        }
    }

    fun chatWithAdmin() {
        _stateChatAdmin.value = Result.Loading
        viewModelScope.launch {
            val userId = userRepository.getCurrentUser()?.uid
            val result = userRepository.chatWithAdmin(userId.toString())
            _stateChatAdmin.value = result
        }
    }

    fun chatWithMitra(
        mitraId: String?,
    ) {
        _stateChatMitra.value = Result.Loading
        viewModelScope.launch {
            val user = userRepository.getUserDataFromFirestore()
            val userId = user?.uid.toString()
            val userName = user?.name.toString()

            val mitra = userRepository.getUserDataByUID(mitraId.toString())
            val mitraName = mitra?.name.toString()

            val result =
                userRepository.chatWithMitra(
                    userId = userId,
                    mitraId = mitraId.toString(),
                    userName = userName,
                    mitraName = mitraName
                )
            _stateChatMitra.value = result
        }
    }
}