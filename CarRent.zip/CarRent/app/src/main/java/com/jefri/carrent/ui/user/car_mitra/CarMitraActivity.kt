package com.jefri.carrent.ui.user.car_mitra

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.jefri.carrent.R
import com.jefri.carrent.databinding.ActivityCarMitraBinding
import com.jefri.carrent.ui.MobilAdapter
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.result.Result

class CarMitraActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCarMitraBinding

    private val viewModel by viewModels<CarMitraViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private lateinit var adapter: MobilAdapter
    private lateinit var mitraId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        binding = ActivityCarMitraBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
    }

    private fun init() {
        setupReceiveExtraMitra()
        setupListCarMitra()
        observeCarData()
        setupBtnListener()
    }

    private fun observeCarData() {
        viewModel.getMobilData(mitraId)
        viewModel.listMobilData.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.progressBar.show()
                    }
                    is Result.Success -> {
                        binding.progressBar.hide()
                        adapter.submitList(result.data)
                    }
                    is Result.Error -> {
                        binding.progressBar.hide()
                        showToast(result.message)
                    }
                }
            }
        }
    }

    private fun setupListCarMitra() {
        adapter = MobilAdapter { mobil ->
            // Intent to detail mobil
            val intentToDetailMobil = Intent(this, DetailCarActivity::class.java)
            intentToDetailMobil.putExtra(DetailCarActivity.EXTRA_MOBIL_ID, mobil.id)
            startActivity(intentToDetailMobil)
        }
        binding.rvCarMitra.adapter = adapter
    }

    private fun setupReceiveExtraMitra() {
        mitraId = intent.getStringExtra(EXTRA_MITRA_ID) ?: ""
    }

    private fun setupBtnListener() {
        with (binding) {
            ivBack.setOnClickListener {
                finish()
            }
        }
    }

    companion object {
        const val EXTRA_MITRA_ID = "extra_mitra_id"
    }
}