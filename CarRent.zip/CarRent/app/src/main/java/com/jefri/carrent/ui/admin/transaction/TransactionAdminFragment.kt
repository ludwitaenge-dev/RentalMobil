package com.jefri.carrent.ui.admin.transaction

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updateLayoutParams
import androidx.fragment.app.viewModels
import com.jefri.carrent.custom_ui.bottom_sheet.StatusFilterBottomSheet
import com.jefri.carrent.databinding.FragmentTransactionBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.user.transaction.TransactionAdapter
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.result.Result
import kotlin.getValue

class TransactionAdminFragment : Fragment() {

    private var _binding: FragmentTransactionBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: TransactionAdapter

    private val transactionAdminViewModel by viewModels<TransactionAdminViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentTransactionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        ViewCompat.setOnApplyWindowInsetsListener(binding.tvNoTransaction) { view, insets ->
            val bottomInset = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            view.updateLayoutParams<ViewGroup.MarginLayoutParams> {
                bottomMargin = bottomInset
            }
            insets
        }

        init()
    }

    private fun init() {
        setupListOrder()
        observeOrderData()
        setupBtnListener()
    }

    private fun observeOrderData() {
        transactionAdminViewModel.orderData.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {
                    binding.progressBar.show()
                }
                is Result.Success -> {
                    binding.progressBar.hide()
                    val data = result.data
                    if (data.isEmpty()) {
                        binding.tvNoTransaction.show()
                        binding.rvTransaction.hide()
                    } else {
                        binding.tvNoTransaction.hide()
                        binding.rvTransaction.show()
                        adapter.submitList(data)
                    }
                }
                is Result.Error -> {
                    binding.progressBar.hide()
                }
            }
        }
    }

    private fun setupListOrder() {
        adapter = TransactionAdapter { order ->
            val intent = Intent(requireContext(), DetailTransactionAdminActivity::class.java)
            intent.putExtra(DetailTransactionAdminActivity.EXTRA_ORDER_ID, order.id)
            startActivity(intent)
        }
        binding.rvTransaction.adapter = adapter
    }

    private fun setupBtnListener() {
        with (binding) {
            btnStatusFilter.setOnClickListener {
                val bottomSheet = StatusFilterBottomSheet { status ->
                    binding.btnStatusFilter.text = status ?: "Status"
                    transactionAdminViewModel.setStatus(status)
                }
                bottomSheet.show(childFragmentManager, "StatusFilterBottomSheet")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}