package com.jefri.carrent.ui.user.notifications

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Notification
import com.jefri.carrent.data.repository.UserRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch

class NotificationsViewModel(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _notificationData = MutableLiveData<Result<List<Notification>>>()
    val notificationData: LiveData<Result<List<Notification>>> get() = _notificationData

    init {
        getListNotification()
    }

    private fun getListNotification() {
        _notificationData.value = Result.Loading
        viewModelScope.launch {
            _notificationData.value = userRepository.getNotification()
        }
    }
}