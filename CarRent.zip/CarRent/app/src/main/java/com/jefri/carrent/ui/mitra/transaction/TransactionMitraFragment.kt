package com.jefri.carrent.ui.mitra.transaction

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updateLayoutParams
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.jefri.carrent.custom_ui.bottom_sheet.StatusFilterBottomSheet
import com.jefri.carrent.data.model.User
import com.jefri.carrent.databinding.FragmentTransactionMitraBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.mitra.UserMitraViewModel
import com.jefri.carrent.ui.mitra.additional.AdditionalInformationMitraActivity
import com.jefri.carrent.ui.user.transaction.TransactionAdapter
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.result.Result

class TransactionMitraFragment : Fragment() {

    private var _binding: FragmentTransactionMitraBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: TransactionAdapter

    private lateinit var user: User
    private val viewModel by viewModels<TransactionMitraViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    private val userMitraViewModel by activityViewModels<UserMitraViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    private lateinit var informationLauncher: ActivityResultLauncher<Intent>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentTransactionMitraBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        ViewCompat.setOnApplyWindowInsetsListener(binding.tvNoTransaction) { view, insets ->
            val bottomInset = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            view.updateLayoutParams<ViewGroup.MarginLayoutParams> {
                bottomMargin = bottomInset
            }
            insets
        }

        informationLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                userMitraViewModel.getUserData()
            }
        }

        init()
    }

    private fun init() {
        observeUserData()
        setupListOrder()
        observeOrderData()
        setupBtnListener()
    }

    private fun observeUserData() {
        userMitraViewModel.user.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {}
                is Result.Success -> {
                    user = result.data!!

                    if (user.isActive) {
                        binding.filterContainer.show()
                        binding.rvTransaction.show()
                        binding.llInactiveMitra.hide()
                    } else {
                        if (user.alamat.isNotEmpty() and user.dokumen.isNotEmpty()) {
                            binding.tvInactiveMitra.text = "Anda telah melengkapi data mitra. Silahkan menunggu konfirmasi dari Admin atau bisa hubungi lewat chat"
                            binding.btnToAddInformation.hide()
                        }
                        binding.filterContainer.hide()
                        binding.rvTransaction.hide()
                        binding.llInactiveMitra.show()
                    }
                }
                is Result.Error -> {
                    showToast("Gagal ambil data user: ${result.message}")
                }
            }
        }
    }

    private fun observeOrderData() {
        viewModel.orderData.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {
                    binding.progressBar.show()
                }
                is Result.Success -> {
                    binding.progressBar.hide()
                    val data = result.data
                    if (data.isEmpty()) {
                        binding.tvNoTransaction.show()
                        binding.rvTransaction.hide()
                    } else {
                        binding.tvNoTransaction.hide()
                        binding.rvTransaction.show()
                        adapter.submitList(data)
                    }
                }
                is Result.Error -> {
                    binding.progressBar.hide()
                }
            }
        }
    }

    private fun setupListOrder() {
        adapter = TransactionAdapter { order ->
            val intent = Intent(requireContext(), DetailTransactionMitraActivity::class.java)
            intent.putExtra(DetailTransactionMitraActivity.EXTRA_ORDER_ID, order.id)
            startActivity(intent)
        }
        binding.rvTransaction.adapter = adapter
    }

    private fun setupBtnListener() {
        with (binding) {
            btnToAddInformation.setOnClickListener {
                val intent = Intent(requireContext(), AdditionalInformationMitraActivity::class.java)
                informationLauncher.launch(intent)
            }

            btnStatusFilter.setOnClickListener {
                val bottomSheet = StatusFilterBottomSheet { status ->
                    binding.btnStatusFilter.text = status ?: "Status"
                    viewModel.setStatus(status)
                }
                bottomSheet.show(childFragmentManager, "StatusFilterBottomSheet")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}