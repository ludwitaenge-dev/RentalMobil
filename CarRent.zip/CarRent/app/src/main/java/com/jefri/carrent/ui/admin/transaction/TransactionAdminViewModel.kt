package com.jefri.carrent.ui.admin.transaction

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asFlow
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.repository.AdminRepository
import com.jefri.carrent.utils.helpers.StatusMapping
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch

class TransactionAdminViewModel(
    private val adminRepository: AdminRepository
) : ViewModel() {
    private val _orderData = MutableLiveData<Result<List<Order>>>()
    val orderData: LiveData<Result<List<Order>>> get() = _orderData

    private val _status = MutableLiveData<String?>()
    val status: LiveData<String?> get() = _status

    init {
        _status.value = null
        observeStatusChange()
    }

    private fun getOrderData(
        status: String? = null
    ) {
        viewModelScope.launch {
            _orderData.value = Result.Loading
            val result = if (status.isNullOrEmpty()) {
                adminRepository.getOrdersData()
            } else {
                adminRepository.getOrdersData(status = listOf(status))
            }
            _orderData.value = result
        }
    }

    private fun observeStatusChange() {
        viewModelScope.launch {
            _status.asFlow().collect { currentStatus ->
                getOrderData(StatusMapping.getShortStatus(currentStatus))
            }
        }
    }

    fun setStatus(newStatus: String?) {
        if (_status.value != newStatus) {
            _status.value = newStatus
        }
    }
}