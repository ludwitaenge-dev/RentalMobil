package com.jefri.carrent.data.model

import android.os.Parcelable
import com.google.firebase.Timestamp
import kotlinx.parcelize.Parcelize

@Parcelize
data class Muatan(
    val id: String = "",
    val kapasitas: String = "",
    val harga: Long = 0,
    val mitraId: String = "",
    val mitraName: String = "",
    val imageUrl: String = "",
    val averageRating: Double = 0.0,
    val totalRatingCount: Long = 0,
    val createdAt: Timestamp = Timestamp.now(),
    val updatedAt: Timestamp = Timestamp.now(),
    val isBooked: Boolean = false
) : Parcelable