package com.jefri.carrent.data.model

import android.os.Parcelable
import com.google.firebase.Timestamp
import kotlinx.parcelize.Parcelize

@Parcelize
data class Mobil(
    val id: String = "",
    val merk: String = "",
    val model: String = "",
    val tahun: String = "",
    val platNomor: String = "",
    val warna: String = "",
    val hargaPerHari: Long = 0,
    val fotoUrl: String = "",
    val dokumentUrl: String = "",
    val mitraId: String = "",
    val mitraName: String = "",
    val averageRating: Double = 0.0,
    val totalRatingCount: Long = 0,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null,
    val isBooked: Boolean = false
) : Parcelable