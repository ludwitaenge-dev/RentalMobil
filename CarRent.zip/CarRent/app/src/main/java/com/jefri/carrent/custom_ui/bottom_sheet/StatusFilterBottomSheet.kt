package com.jefri.carrent.custom_ui.bottom_sheet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.jefri.carrent.databinding.BottomsheetFilterStatusBinding

class StatusFilterBottomSheet(
    private val onStatusSelected: (String?) -> Unit
) : BottomSheetDialogFragment() {

    private var selectedStatus: String? = null
    private var _binding: BottomsheetFilterStatusBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomsheetFilterStatusBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.rgStatus.setOnCheckedChangeListener { _, checkedId ->
            selectedStatus = when (checkedId) {
                binding.rbBelumDibayar.id -> "Belum Dibayar"
                binding.rbMenungguAdmin.id -> "Menunggu Konfirmasi Admin"
                binding.rbMenungguMitra.id -> "Menunggu Konfirmasi Mitra"
                binding.rbProses.id -> "Diproses"
                binding.rbSelesai.id -> "Selesai"
                binding.rbDibatalkan.id -> "Dibatalkan"
                else -> null
            }
        }

        binding.btnReset.setOnClickListener {
            binding.rgStatus.clearCheck()
            selectedStatus = null
            onStatusSelected(null)
            dismiss()
        }

        binding.btnApply.setOnClickListener {
            onStatusSelected(selectedStatus)
            dismiss()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}