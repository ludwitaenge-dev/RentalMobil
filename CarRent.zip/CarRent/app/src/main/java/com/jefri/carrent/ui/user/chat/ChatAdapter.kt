package com.jefri.carrent.ui.user.chat

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.jefri.carrent.data.model.Chat
import com.jefri.carrent.databinding.ItemChatBinding

class ChatAdapter(
    private val currentUserId: String,
    private val onItemClick: (chatId: String, chat: Chat) -> Unit
) : ListAdapter<Pair<String, Chat>, ChatAdapter.MyViewHolder>(CHAT_DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemChatBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val (chatId, chat) = getItem(position)
        holder.bind(chatId, chat)
    }

    inner class MyViewHolder(
        private val binding: ItemChatBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(chatId: String, chat: Chat) {
            val otherUserName = chat.participants
                .filterKeys { it != currentUserId }
                .values.firstOrNull() ?: "Unknown"
            binding.tvName.text = otherUserName

            binding.tvLastMessage.text = chat.lastMessage.ifEmpty { "Belum ada pesan" }

            itemView.setOnClickListener {
                onItemClick(chatId, chat)
            }
        }
    }

    companion object {
        private val CHAT_DIFF_CALLBACK = object : DiffUtil.ItemCallback<Pair<String, Chat>>() {
            override fun areItemsTheSame(
                oldItem: Pair<String, Chat>,
                newItem: Pair<String, Chat>
            ): Boolean {
                return oldItem.first == newItem.first
            }

            override fun areContentsTheSame(
                oldItem: Pair<String, Chat>,
                newItem: Pair<String, Chat>
            ): Boolean {
                return oldItem.second == newItem.second
            }
        }
    }
}
