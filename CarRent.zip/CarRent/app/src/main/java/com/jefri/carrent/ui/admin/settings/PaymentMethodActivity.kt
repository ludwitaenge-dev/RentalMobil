package com.jefri.carrent.ui.admin.settings

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.jefri.carrent.R
import com.jefri.carrent.databinding.ActivityPaymentMethodBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import kotlin.getValue
import com.jefri.carrent.utils.result.Result

class PaymentMethodActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPaymentMethodBinding
    private val viewModel by viewModels<PaymentMethodViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private lateinit var adapter: PaymentMethodAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        binding = ActivityPaymentMethodBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
    }

    private fun init() {
        setupRecyclerView()
        observeViewModel()
        setupAction()

        viewModel.getPaymentMethods()
    }

    private fun setupRecyclerView() {
        adapter = PaymentMethodAdapter { paymentMethod ->
            val bottomSheet = EditPaymentNumberBottomSheet.newInstance(paymentMethod) { newNumber ->
                viewModel.updatePaymentNumber(paymentMethod.id, newNumber)
            }
            bottomSheet.show(supportFragmentManager, EditPaymentNumberBottomSheet.TAG)
        }
        binding.rvPaymentMethod.adapter = adapter
    }

    private fun observeViewModel() {
        viewModel.paymentMethods.observe(this) { result ->
            when (result) {
                is Result.Loading -> binding.progressBar.show()
                is Result.Success -> {
                    binding.progressBar.hide()
                    adapter.submitList(result.data)
                }
                is Result.Error -> {
                    binding.progressBar.hide()
                    showToast(result.message)
                }
            }
        }

        viewModel.updateResult.observe(this) { result ->
            when (result) {
                is Result.Loading -> binding.progressBar.show()
                is Result.Success -> {
                    binding.progressBar.hide()
                    showToast(result.data)
                }
                is Result.Error -> {
                    binding.progressBar.hide()
                    showToast(result.message)
                }
            }
        }
    }

    private fun setupAction() {
        binding.ivBack.setOnClickListener {
            finish()
        }
    }
}
