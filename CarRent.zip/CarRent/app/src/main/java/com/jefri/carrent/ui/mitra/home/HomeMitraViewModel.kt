package com.jefri.carrent.ui.mitra.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Mobil
import com.jefri.carrent.data.model.Muatan
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.model.User
import com.jefri.carrent.data.repository.MitraRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch
import java.util.Calendar

class HomeMitraViewModel(
    private val mitraRepository: MitraRepository
) : ViewModel() {

    private val _orderData = MutableLiveData<Result<List<Order>>>()
    val orderData: LiveData<Result<List<Order>>> get() = _orderData

    private val _mobilData = MutableLiveData<Result<List<Mobil>>>()
    val mobilData: LiveData<Result<List<Mobil>>> get() = _mobilData

    private val _user = MutableLiveData<Result<User?>>()
    val user: LiveData<Result<User?>>
        get() = _user

    private val listStatus = listOf("menunggu_konfirmasi_mitra", "diproses")

    init {
        getUserData()
        getOrderWaitingConfirmationData()
        getMobilData()
    }

    fun getOrderWaitingConfirmationData() {
        viewModelScope.launch {
            _orderData.value = Result.Loading
            val result = mitraRepository.getOrdersData(
                status = listStatus
            )
            _orderData.value = result
        }
    }

    fun getMobilData() {
        viewModelScope.launch {
            _mobilData.value = Result.Loading
            val result = mitraRepository.getMobilWithStatus(mitraRepository.getCurrentUser()?.uid.toString())
            _mobilData.value = result
        }
    }

    fun getUserData() {
        _user.value = Result.Loading

        viewModelScope.launch {
            try {
                _user.value = Result.Success(mitraRepository.getUserDataFromFirestore())
            } catch (e: Exception) {
                _user.value = Result.Error(e.message.toString())
            }
        }
    }

    fun getGreetingText(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 4..10 -> "Selamat Pagi,"
            in 11..14 -> "Selamat Siang,"
            in 15..17 -> "Selamat Sore,"
            else -> "Selamat Malam,"
        }
    }
}