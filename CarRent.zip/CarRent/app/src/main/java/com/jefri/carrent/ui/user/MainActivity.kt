package com.jefri.carrent.ui.user

import android.Manifest
import android.app.ComponentCaller
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.google.firebase.messaging.FirebaseMessaging
import com.jefri.carrent.data.services.firebase.FirebaseTokenHelper
import com.jefri.carrent.databinding.ActivityMainBinding
import com.jefri.carrent.ui.user.add_transaction.payment.PaymentActivity
import com.jefri.carrent.ui.user.add_transaction.select_muatan.SelectMuatanActivity
import com.jefri.carrent.ui.user.home.HomeFragment
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private lateinit var paymentLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0)
            insets
        }

        val navHostFragment = supportFragmentManager.findFragmentById(binding.navHostFragmentActivityMain.id) as NavHostFragment
        val navController = navHostFragment.navController

        paymentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val homeFragment = navHostFragment
                    .childFragmentManager.fragments.find { it is HomeFragment } as? HomeFragment
                homeFragment?.refreshTransaction()
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                100
            )
        }

        handleIntent(intent)

        binding.navView.setupWithNavController(navController)
        init()

        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            lifecycleScope.launch {
                FirebaseTokenHelper.saveTokenToFirestore(token)
            }
        }
    }

    override fun onNewIntent(intent: Intent, caller: ComponentCaller) {
        super.onNewIntent(intent, caller)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun init() {
        setupBtnListener()
    }

    private fun setupBtnListener() {
        with (binding) {
//            binding.fabAddTransaction.setOnClickListener {
//                val intent = Intent(this@MainActivity, SelectMuatanActivity::class.java)
//                startActivity(intent)
//            }
        }
    }

    private fun handleIntent(intent: Intent?) {
        intent ?: return

        if (intent.getBooleanExtra("openPayment", false)) {
            val orderId = intent.getStringExtra(PaymentActivity.EXTRA_ORDER_ID)
            val paymentIntent = Intent(this, PaymentActivity::class.java).apply {
                putExtra(PaymentActivity.EXTRA_ORDER_ID, orderId)
            }
            paymentLauncher.launch(paymentIntent)
        }
    }
}