package com.jefri.carrent.ui.user.chat

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.jefri.carrent.R
import com.jefri.carrent.databinding.ActivityDetailChatBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.hideKeyboard
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DetailChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailChatBinding
    private lateinit var adapter: MessageAdapter

    private lateinit var chatId: String
    private lateinit var userId: String

    private val viewModel: DetailChatViewModel by viewModels<DetailChatViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        binding = ActivityDetailChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userId = viewModel.getUserId() ?: ""
        init()
    }

    private fun init() {
        setupReceiveExtra()
        setupRecyclerView()
        listenMessages()
        setupBtnListener()
        loadChatDetail()
    }

    private fun setupRecyclerView() {
        adapter = MessageAdapter(userId)
        binding.rvMessages.adapter = adapter
    }

    private fun listenMessages() {
        lifecycleScope.launch {
            viewModel.listenMessages(chatId)
            viewModel.messages.collectLatest { result ->
                when (result) {
                    is Result.Loading -> binding.progressBar.show()
                    is Result.Success -> {
                        binding.progressBar.hide()
                        adapter.submitList(result.data)
                        Log.d("DetailChatActivity", "listenMessages: ${result.data}")
                        binding.rvMessages.scrollToPosition(result.data.size - 1)
                    }
                    is Result.Error -> {
                        binding.progressBar.hide()
                        showToast("Error: ${result.message}")
                    }
                }
            }
        }
    }

    private fun loadChatDetail() {
        lifecycleScope.launchWhenStarted {
            viewModel.loadChatDetail(chatId)
            viewModel.chatDetail.collectLatest { result ->
                when(result) {
                    is Result.Success -> {
                        val chat = result.data
                        val currentUserId = viewModel.getUserId()
                        val otherName = chat.participants
                            ?.filterKeys { it != currentUserId }
                            ?.values
                            ?.firstOrNull() ?: "Unknown"
                        binding.tvNameChat.text = otherName
                    }
                    is Result.Error -> {
                        binding.tvNameChat.text = "Unknown"
                    }
                    else -> {}
                }
            }
        }
    }

    private fun setupBtnListener() {
        with (binding) {
            btnSend.setOnClickListener {
                val message = etMessage.text.toString()
                if (message.isNotEmpty()) {
                    viewModel.sendMessage(chatId, userId, message)
                    etMessage.text.clear()
                    btnSend.hideKeyboard()
                }
            }

            ivBack.setOnClickListener {
                finish()
            }
        }
    }

    private fun setupReceiveExtra() {
        chatId = intent.getStringExtra(EXTRA_CHAT_ID) ?: ""
    }

//    private fun setupTitleChat() {
//        binding.tvNameChat.text =
//    }

    companion object {
        const val EXTRA_CHAT_ID = "extra_chat_id"
    }
}