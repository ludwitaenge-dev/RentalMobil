package com.jefri.carrent.data.services.firebase

import android.net.Uri
import android.util.Log
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.jefri.carrent.data.model.User
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.tasks.await
import java.util.UUID

class AuthService(
    private val firebaseAuth: FirebaseAuth,
    private val firestore: FirebaseFirestore,
    private val storage: FirebaseStorage
) {
    fun getCurrentUser(): FirebaseUser? {
        return firebaseAuth.currentUser
    }

    fun isUserSignedIn(): Boolean {
        return firebaseAuth.currentUser != null
    }

    suspend fun getFirestoreUser(uid: String): User? {
        return try {
            val snapshot = firestore.collection("users").document(uid).get().await()
            Log.d("AuthService", "getFirestoreUser: $snapshot")
            val user = snapshot.toObject(User::class.java)?.copy(
                isActive = snapshot.getBoolean("isActive") ?: false
            )
            user
        } catch (e: Exception) {
            null
        }
    }

    suspend fun signInWithEmailPassword(email: String, password: String): Result<FirebaseUser> {
        return try {
            val authResult = firebaseAuth
                .signInWithEmailAndPassword(email, password)
                .await()

            val user = authResult.user ?: return Result.Error("User tidak ditemukan", "INVALID_USER")

            val snapshot = firestore.collection("users").document(user.uid).get().await()
            val isDeleted = snapshot.getBoolean("is_deleted") ?: false

            if (isDeleted) {
                firebaseAuth.signOut()
                return Result.Error("Akun Anda telah dinonaktifkan oleh admin", "ACCOUNT_DISABLED")
            }

            Result.Success(user)
        } catch (_: FirebaseAuthInvalidUserException) {
            Result.Error("Akun tidak ditemukan", "INVALID_USER")
        } catch (_: FirebaseAuthInvalidCredentialsException) {
            Result.Error("Email atau password salah", "INVALID_CREDENTIALS")
        } catch (_: FirebaseTooManyRequestsException) {
            Result.Error("Terlalu banyak percobaan login. Coba lagi nanti.", "TOO_MANY_REQUESTS")
        } catch (_: FirebaseNetworkException) {
            Result.Error("Tidak ada koneksi internet", "NETWORK_ERROR")
        } catch (e: Exception) {
            Result.Error(e.message ?: "Terjadi kesalahan tak terduga", "UNKNOWN_ERROR")
        }
    }

    suspend fun createUserWithEmailPassword(email: String, password: String): Result<FirebaseUser> {
        return try {
            val authResult = firebaseAuth.createUserWithEmailAndPassword(email, password).await()
            Result.Success(authResult.user!!)
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun sendPasswordResetEmail(email: String): Result<String> {
        return try {
            firebaseAuth.sendPasswordResetEmail(email).await()
            Result.Success("Email reset password telah dikirim ke $email")
        } catch (e: FirebaseAuthInvalidUserException) {
            Result.Error("Akun dengan email tersebut tidak ditemukan", "INVALID_USER")
        } catch (e: FirebaseNetworkException) {
            Result.Error("Tidak ada koneksi internet", "NETWORK_ERROR")
        } catch (e: Exception) {
            Result.Error(e.message ?: "Gagal mengirim email reset password", "UNKNOWN_ERROR")
        }
    }

    fun signOut() {
        firebaseAuth.signOut()
    }

    suspend fun createUserInFirestore(firebaseUser: FirebaseUser, user: User): Result<String?> {
        return try {
            val userData = hashMapOf(
                "uid" to firebaseUser.uid,
                "email" to firebaseUser.email,
                "name" to user.name,
                "role" to user.role,
                "noTelp" to user.noTelp,
                "alamat" to user.alamat,
                "isActive" to user.isActive,
                "is_deleted" to false,
            )
            firestore.collection("users").document(firebaseUser.uid).set(userData).await()
            Result.Success("Success")
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun updateUserData(uid: String, updates: Map<String, Any>): Result<String> {
        return try {
            firestore.collection("users")
                .document(uid)
                .update(updates)
                .await()
            Result.Success("User data updated successfully")
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun updateInfoMitra(
        uid: String,
        imageUri: Uri,
        alamat: String,
        notel: String
    ): Result<String> {
        return try {
            val fileName = "dokumen_mitra/${uid}_${UUID.randomUUID()}.jpg"
            val ref = storage.reference.child(fileName)

            ref.putFile(imageUri).await()

            val imageUrl = ref.downloadUrl.await().toString()

            val updates = mapOf(
                "dokumen" to imageUrl,
                "alamat" to alamat,
                "noTelp" to notel
            )

            firestore.collection("users")
                .document(uid)
                .update(updates)
                .await()
            Result.Success("User data updated successfully")
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun getMitraInactiveData(): Result<List<User>> {
        return try {
            val querySnapshot = firestore.collection("users")
                .whereEqualTo("isActive", false)
                .whereEqualTo("role", "mitra")
                .get()
                .await()

            val users = querySnapshot.documents.mapNotNull { document ->
                document.toObject(User::class.java)
            }
            Result.Success(users)
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun getMitraActiveData(): Result<List<User>> {
        return try {
            val querySnapshot = firestore.collection("users")
                .whereEqualTo("isActive", true)
                .whereEqualTo("is_deleted", false)
                .whereEqualTo("role", "mitra")
                .get()
                .await()

            val users = querySnapshot.documents.mapNotNull { document ->
                document.toObject(User::class.java)
            }
            Result.Success(users)
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun acceptMitra(uid: String): Result<String> {
        return try {
            val updates = mapOf(
                "isActive" to true
            )

            firestore.collection("users")
                .document(uid)
                .update(updates)
                .await()

            Result.Success("User data updated successfully")
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun getAllNonAdminUsers(): List<User> {
        return try {
            val snapshot = firestore.collection("users")
                .whereNotEqualTo("role", "admin")
                .get()
                .await()

            snapshot.documents.mapNotNull { doc ->
                val data = doc.toObject(User::class.java)?.copy(
                    uid = doc.id,
                    isDeleted = doc.getBoolean("is_deleted") ?: false
                )
                data
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun updateUserStatus(uid: String, isDeleted: Boolean): Boolean {
        return try {
            firestore.collection("users")
                .document(uid)
                .update(
                    mapOf(
                        "is_deleted" to isDeleted,
                    )
                )
                .await()

            true
        } catch (e: Exception) {
            false
        }
    }
}