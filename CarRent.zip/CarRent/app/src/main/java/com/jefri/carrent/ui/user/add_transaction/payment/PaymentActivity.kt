package com.jefri.carrent.ui.user.add_transaction.payment

import android.net.Uri
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.jefri.carrent.R
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.databinding.ActivityPaymentBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.ext.toRupiah
import com.jefri.carrent.utils.helpers.DateHelper
import com.jefri.carrent.utils.result.Result

class PaymentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPaymentBinding
    private var orderId: String? = null

    private var selectedImageUri: Uri? = null
    private val viewModel by viewModels<PaymentViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            selectedImageUri = it
            binding.ivPreview.show()
            binding.ivUploadIcon.hide()
            binding.btnClear.show()
            binding.ivPreview.setImageURI(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        binding = ActivityPaymentBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
    }

    private fun init() {
        receiveIntentFromMain()
        observeOrderData()
        setupBtnListener()
        observeUploadResult()
    }

    private fun observeOrderData() {
        viewModel.getCurrentOrderData(orderId.toString())
        viewModel.orderData.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.progressBar.show()
                    }
                    is Result.Success -> {
                        binding.progressBar.hide()
                        val data = result.data
                        setupOrderData(data)
                    }
                    is Result.Error -> {
                        binding.progressBar.hide()
                        showToast(result.toString())
                    }
                }
            }
        }
    }

    private fun observeUploadResult() {
        viewModel.stateUploadBukti.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.btnUpload.setLoading(true)
                    }
                    is Result.Success -> {
                        binding.btnUpload.setLoading(false)
                        showToast("Sukses Upload")
                        setResult(RESULT_OK)
                        finish()
                    }
                    is Result.Error -> {
                        binding.btnUpload.setLoading(false)
                        showToast(result.toString())
                    }
                }
            }
        }
    }

    private fun setupOrderData(order: Order) {
        with (binding) {
            tvPaymentMethod.text = order.metodePembayaran
            tvPaymentNumber.text = order.nomorPembayaran

            val hargaPerHari = order.mobil?.hargaPerHari
            val totalHari = DateHelper.getTotalDaysFromRange(order.date)
            tvPaymentAmount.text = (hargaPerHari?.times(totalHari))?.toRupiah()
        }
    }

    private fun setupBtnListener() {
        with (binding) {
            llUploadPlaceholder.setOnClickListener {
                pickImageLauncher.launch("image/*")
            }

            btnUpload.setOnClickListener {
                if (selectedImageUri == null) {
                    showToast("Pilih gambar dulu")
                    return@setOnClickListener
                }

                viewModel.uploadBuktiPembayaran(
                    orderId.toString(),
                    selectedImageUri!!
                )
            }

            btnClear.setOnClickListener {
                selectedImageUri = null
                btnClear.hide()
                ivPreview.hide()
                ivUploadIcon.show()
                ivPreview.setImageURI(null)
            }
        }
    }

    private fun receiveIntentFromMain() {
        orderId = intent.getStringExtra(EXTRA_ORDER_ID)
    }

    companion object {
        const val EXTRA_ORDER_ID = "orderId"
    }
}