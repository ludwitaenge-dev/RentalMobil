// Mendefinisikan package lokasi file RegisterActivity
package com.jefri.carrent.ui.auth.register

// Import Bundle untuk menyimpan state Activity
import android.os.Bundle
// Import viewModels delegate untuk menghubungkan ViewModel dengan Activity
import androidx.activity.viewModels
// Import AppCompatActivity sebagai superclass Activity
import androidx.appcompat.app.AppCompatActivity
// Import ViewBinding untuk menghubungkan layout XML dengan Activity
import com.jefri.carrent.databinding.ActivityRegisterBinding
// Import ViewModelFactory untuk membuat instance ViewModel
import com.jefri.carrent.ui.ViewModelFactory
// Import AlertHelper untuk menampilkan dialog notifikasi
import com.jefri.carrent.utils.helpers.AlertHelper
// Import sealed class Result untuk menangani state (Loading, Success, Error)
import com.jefri.carrent.utils.result.Result

// Mendeklarasikan class RegisterActivity yang mewarisi AppCompatActivity
class RegisterActivity : AppCompatActivity() {

    // Deklarasi variabel binding untuk mengakses komponen layout
    private lateinit var binding: ActivityRegisterBinding
    
    // Variabel untuk menyimpan role pengguna (admin/user/mitra)
    private lateinit var role: String

    // Inisialisasi RegisterViewModel menggunakan ViewModelFactory
    private val registerViewModel by viewModels<RegisterViewModel> {
        ViewModelFactory.getInstance(this)
    }

    // Fungsi pertama yang dipanggil saat Activity dibuat
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) // Memanggil onCreate milik superclass
        
        // Menghubungkan binding dengan layout XML
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        
        // Menampilkan layout ke layar
        setContentView(binding.root)

        // Memanggil fungsi inisialisasi
        init()
    }

    // Fungsi untuk inisialisasi awal komponen
    private fun init() {
        getExtraFromRole()      // Mengambil data role dari intent
        setupBtnListener()      // Mengatur aksi tombol
        observeStateRegister()  // Mengamati perubahan state register
    }

    // Fungsi untuk mengambil data role dari Activity sebelumnya
    private fun getExtraFromRole() {
        // Mengambil string "role" dari intent
        role = intent.getStringExtra("role").toString()
    }

    // Fungsi untuk mengamati LiveData registerState dari ViewModel
    private fun observeStateRegister() {
        
        // Observe LiveData registerState
        registerViewModel.registerState.observe(this@RegisterActivity) { result ->
            
            // Mengecek apakah result tidak null
            if (result != null) {
                
                // Menentukan aksi berdasarkan tipe Result
                when (result) {
                    
                    // Jika status Loading
                    is Result.Loading -> {
                        // Menampilkan loading pada tombol register
                        binding.btnRegister.setLoading(true)
                    }

                    // Jika status Success
                    is Result.Success -> {
                        // Menghilangkan loading
                        binding.btnRegister.setLoading(false)
                        
                        // Menutup RegisterActivity dan kembali ke Login
                        finish()
                    }

                    // Jika status Error
                    is Result.Error -> {
                        // Menghilangkan loading
                        binding.btnRegister.setLoading(false)
                        
                        // Menampilkan pesan error menggunakan AlertHelper
                        AlertHelper.showAlert(this@RegisterActivity, message = result.message)
                    }
                }
            }
        }
    }

    // Fungsi untuk mengatur aksi tombol
    private fun setupBtnListener() {
        
        // Menggunakan scope function with untuk mempermudah akses binding
        with(binding) {
            
            // Listener ketika tombol Register diklik
            btnRegister.setOnClickListener {
                
                // Menyamakan password konfirmasi dengan password asli untuk validasi
                etConfirmationPassword.setOriginalPassword(etPassword.getText())
                
                // Validasi semua input (nama, email, password, konfirmasi password)
                val valid =
                    etName.validate() and 
                    etEmail.validate() and 
                    etPassword.validate() and 
                    etConfirmationPassword.validate()

                // Jika ada yang tidak valid, hentikan proses
                if (!valid) return@setOnClickListener

                // Mengambil nilai dari setiap input
                val name = etName.getText()
                val email = etEmail.getText()
                val password = etPassword.getText()

                // Memanggil fungsi register pada ViewModel
                registerViewModel.register(name, email, password, role)
            }

            // Listener ketika tombol Login diklik
            btnLogin.setOnClickListener {
                // Menutup RegisterActivity dan kembali ke LoginActivity
                finish()
            }
        }
    }
}