package com.jefri.carrent.utils.helpers

import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

object DateHelper {
    fun now(): String {
        val current = LocalDateTime.now()
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        return current.format(formatter)
    }

    fun formatFirebaseTimestamp(timestamp: Timestamp?): String {
        if (timestamp == null) return "-"
        val date = timestamp.toDate()
        val locale = Locale("id", "ID")
        val formatter = SimpleDateFormat("dd MMM yyyy HH:mm", locale)
        return formatter.format(date)
    }

    fun getTotalDaysFromRange(dateRange: String?): Int {
        if (dateRange.isNullOrBlank() || !dateRange.contains("-")) return 0

        return try {
            val sdf = SimpleDateFormat("dd MMM yyyy", Locale("id", "ID"))
            val parts = dateRange.split("-").map { it.trim() }

            val startDate = sdf.parse(parts[0])
            val endDate = sdf.parse(parts[1])

            if (startDate != null && endDate != null) {
                val diffMillis = endDate.time - startDate.time
                val days = (diffMillis / (1000 * 60 * 60 * 24)) + 1 // +1 biar inklusif
                days.toInt()
            } else 0
        } catch (e: Exception) {
            0
        }
    }

}