package com.jefri.carrent.ui.mitra.home

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.jefri.carrent.custom_ui.bottom_sheet.LogoutBottomSheet
import com.jefri.carrent.data.model.User
import com.jefri.carrent.databinding.FragmentHomeMitraBinding
import com.jefri.carrent.ui.MobilAdapter
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.mitra.UserMitraViewModel
import com.jefri.carrent.ui.mitra.additional.AdditionalInformationMitraActivity
import com.jefri.carrent.ui.mitra.mobil.DetailMobilMitraActivity
import com.jefri.carrent.ui.mitra.transaction.DetailTransactionMitraActivity
import com.jefri.carrent.ui.user.home.MuatanHomeAdapter
import com.jefri.carrent.ui.user.transaction.TransactionAdapter
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.result.Result

class HomeMitraFragment : Fragment() {

    private var _binding: FragmentHomeMitraBinding? = null
    private val binding get() = _binding!!

    private lateinit var user: User
    private val homeMitraViewModel by viewModels<HomeMitraViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    private val userMitraViewModel by activityViewModels<UserMitraViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    private lateinit var transactionAdapter: TransactionAdapter
    private lateinit var mobilAdapter: MobilAdapter

    private lateinit var detailLauncher: ActivityResultLauncher<Intent>
    private lateinit var informationLauncher: ActivityResultLauncher<Intent>
    private lateinit var mobilLauncher: ActivityResultLauncher<Intent>


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeMitraBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        detailLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                homeMitraViewModel.getOrderWaitingConfirmationData()
            }
        }

        informationLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                userMitraViewModel.getUserData()
            }
        }

        mobilLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                homeMitraViewModel.getMobilData()
            }
        }

        init()
    }

    private fun init() {
        setupRecycleViewActiveTransaction()
        setupRecycleViewMuatan()
        setupGreeting()
        observeUserData()
        observeTransaction()
        observeMuatanMitra()
        setupBtnListener()
    }

    private fun observeTransaction() {
        homeMitraViewModel.orderData.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {
                    binding.progressBar.show()
                }

                is Result.Success -> {
                    binding.progressBar.hide()
                    val orderData = result.data
                    if (orderData.isEmpty()) {
                        binding.rvActiveTransaction.hide()
                        binding.tvNoActiveTransaction.show()
                    } else {
                        binding.rvActiveTransaction.show()
                        binding.tvNoActiveTransaction.hide()
                        transactionAdapter.submitList(orderData)
                    }

                }

                is Result.Error -> {
                    binding.progressBar.hide()
                    showToast(result.message)
                }
            }
        }
    }

    private fun observeMuatanMitra() {
        homeMitraViewModel.mobilData.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {
                    binding.progressBar.show()
                }

                is Result.Success -> {
                    binding.progressBar.hide()
                    val mobilResultData = result.data
                    if (mobilResultData.isEmpty()) {
                        binding.rvMuatan.hide()
                        binding.tvNoMuatan.show()
                        binding.btnAddMuatan.show()
                    } else {
                        binding.rvMuatan.show()
                        binding.tvNoMuatan.hide()
                        binding.btnAddMuatan.hide()
                        mobilAdapter.submitList(mobilResultData)
                    }

                }

                is Result.Error -> {
                    binding.progressBar.hide()
                    showToast(result.message)
                }
            }
        }
    }

    private fun observeUserData() {
        userMitraViewModel.user.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Loading -> {}
                is Result.Success -> {
                    user = result.data!!
                    binding.tvUserName.text = user.name

                    if (user.isActive) {
                        binding.llActiveMitra.show()
                        binding.llInactiveMitra.hide()
                    } else {
                        if (user.alamat.isNotEmpty() and user.dokumen.isNotEmpty()) {
                            binding.tvInactiveMitra.text = "Anda telah melengkapi data mitra. Silahkan menunggu konfirmasi dari Admin atau bisa hubungi lewat chat"
                            binding.btnToAddInformation.hide()
                        }
                        binding.llActiveMitra.hide()
                        binding.llInactiveMitra.show()
                    }
                }
                is Result.Error -> {
                    showToast("Gagal ambil data user: ${result.message}")
                }
            }
        }
    }

    private fun setupRecycleViewActiveTransaction() {
        transactionAdapter = TransactionAdapter { order ->
            val intent = Intent(requireContext(), DetailTransactionMitraActivity::class.java)
            intent.putExtra(DetailTransactionMitraActivity.EXTRA_ORDER_ID, order.id)
            detailLauncher.launch(intent)
        }
        binding.rvActiveTransaction.adapter = transactionAdapter
    }

    private fun setupRecycleViewMuatan() {
        mobilAdapter = MobilAdapter { mobil ->
            val intentToDetailMobil = Intent(requireContext(), DetailMobilMitraActivity::class.java)
            intentToDetailMobil.putExtra(DetailMobilMitraActivity.EXTRA_MOBIL_ID, mobil.id)
            intentToDetailMobil.putExtra(DetailMobilMitraActivity.EXTRA_ACTION, DetailMobilMitraActivity.ACTION_EDIT)
            mobilLauncher.launch(intentToDetailMobil)
        }
        binding.rvMuatan.adapter = mobilAdapter
    }

    private fun setupBtnListener() {
        with (binding) {
            btnLogout.setOnClickListener {
                val logoutBottomSheet = LogoutBottomSheet()
                logoutBottomSheet.show(parentFragmentManager, logoutBottomSheet.tag)
            }

            btnToAddInformation.setOnClickListener {
                val intent = Intent(requireContext(), AdditionalInformationMitraActivity::class.java)
                informationLauncher.launch(intent)
            }

            btnAddMuatan.setOnClickListener {
                val intent = Intent(requireContext(), DetailMobilMitraActivity::class.java)
                intent.putExtra(DetailMobilMitraActivity.EXTRA_ACTION, DetailMobilMitraActivity.ACTION_ADD)
                mobilLauncher.launch(intent)
            }

            btnAddMobil.setOnClickListener {
                val intent = Intent(requireContext(), DetailMobilMitraActivity::class.java)
                intent.putExtra(DetailMobilMitraActivity.EXTRA_ACTION, DetailMobilMitraActivity.ACTION_ADD)
                mobilLauncher.launch(intent)
            }
        }
    }

    private fun setupGreeting() {
        binding.tvGreeting.text = homeMitraViewModel.getGreetingText()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}