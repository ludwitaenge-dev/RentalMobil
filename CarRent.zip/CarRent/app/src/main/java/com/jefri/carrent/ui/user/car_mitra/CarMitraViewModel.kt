package com.jefri.carrent.ui.user.car_mitra

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Mobil
import com.jefri.carrent.data.repository.MitraRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch

class CarMitraViewModel(
    private val mitraRepository: MitraRepository
) : ViewModel() {

    private val _listMobilData = MutableLiveData<Result<List<Mobil>>>()
    val listMobilData: LiveData<Result<List<Mobil>>> get() = _listMobilData

    private val _detailMobilData = MutableLiveData<Result<Mobil>>()
    val detailMobilData: LiveData<Result<Mobil>> get() = _detailMobilData

    fun getMobilData(
        mitraId: String
    ) {
        viewModelScope.launch {
            _listMobilData.value = Result.Loading
            val result = mitraRepository.getMobilWithStatus(mitraId)
            _listMobilData.value = result
        }
    }

    fun getDetailMobilDataById(
        mobilId: String,
    ) {
        viewModelScope.launch {
            _detailMobilData.value = Result.Loading
            val result = mitraRepository.getMobilById(mobilId)
            _detailMobilData.value = result
        }
    }

}