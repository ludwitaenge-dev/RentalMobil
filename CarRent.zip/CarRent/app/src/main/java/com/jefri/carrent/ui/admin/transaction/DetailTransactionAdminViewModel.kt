package com.jefri.carrent.ui.admin.transaction

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.repository.AdminRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch

class DetailTransactionAdminViewModel(
    private val adminRepository: AdminRepository
) : ViewModel() {

    private val _stateAcceptTransaction = MutableLiveData<Result<String>>()
    val stateAcceptTransaction: LiveData<Result<String>> = _stateAcceptTransaction

    private val _stateCancelTransaction = MutableLiveData<Result<String>>()
    val stateCancelTransaction: LiveData<Result<String>> = _stateCancelTransaction

    private val _orderData = MutableLiveData<Result<Order>>()
    val orderData: LiveData<Result<Order>> = _orderData

    fun getCurrentOrderData(id: String) {
        _orderData.value = Result.Loading
        viewModelScope.launch {
            val result = adminRepository.getCurrentOrder(id)
            _orderData.value = result
        }
    }

    fun acceptOrder(
        orderId: String
    ) {
        _stateAcceptTransaction.value = Result.Loading

        viewModelScope.launch {
            val result = adminRepository.acceptOrder(orderId)
            _stateAcceptTransaction.value = result
        }
    }

    fun cancelOrder(
        orderId: String,
        reason: String,
    ) {
        _stateCancelTransaction.value = Result.Loading

        viewModelScope.launch {
            val result = adminRepository.cancelOrder(orderId, reason, adminRepository.getCurrentUser()?.uid)
            _stateCancelTransaction.value = result
        }
    }
}