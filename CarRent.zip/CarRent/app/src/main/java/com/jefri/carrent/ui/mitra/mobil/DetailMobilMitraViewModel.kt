package com.jefri.carrent.ui.mitra.mobil

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Mobil
import com.jefri.carrent.data.model.Muatan
import com.jefri.carrent.data.repository.MitraRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch

class DetailMobilMitraViewModel(
    private val mitraRepository: MitraRepository
) : ViewModel() {

    private val _mobilDetailData = MutableLiveData<Result<Mobil>>()
    val mobilDetailData: LiveData<Result<Mobil>> get() = _mobilDetailData

    private val _stateAddMobil = MutableLiveData<Result<String>>()
    val stateAddMobil: LiveData<Result<String>> get() = _stateAddMobil

    private val _stateUpdateMobil = MutableLiveData<Result<String>>()
    val stateUpdateMobil: LiveData<Result<String>> get() = _stateUpdateMobil

    fun getMobilDetailData(mobilId: String) {
        viewModelScope.launch {
            _mobilDetailData.value = Result.Loading
            val result = mitraRepository.getMobilById(mobilId)
            _mobilDetailData.value = result
        }
    }

    fun addMobil(
        merk: String,
        model: String,
        tahun: String,
        platNomor: String,
        warna: String,
        hargaPerHari: Long,
        imageUri: Uri,
        dokumentUri: Uri
    ) {
        viewModelScope.launch {
            _stateAddMobil.value = Result.Loading
            val mitraInfo = mitraRepository.getUserDataFromFirestore()
            val mobil = Mobil(
                merk = merk,
                model = model,
                tahun = tahun,
                platNomor = platNomor,
                warna = warna,
                hargaPerHari = hargaPerHari,
                mitraId = mitraInfo?.uid.toString(),
                mitraName = mitraInfo?.name.toString(),
            )
            val result = mitraRepository.addMobil(mobil, imageUri, dokumentUri)
            _stateAddMobil.value = result
        }
    }

    fun updateMobil(
        mobilId: String,
        merk: String,
        model: String,
        tahun: String,
        platNomor: String,
        warna: String,
        harga: Long,
        imageUri: Uri?,
        dokumentUri: Uri?
    ) {
        viewModelScope.launch {
            _stateUpdateMobil.value = Result.Loading
            val result = mitraRepository.updateMobil(
                mobilId,
                merk,
                model,
                tahun,
                platNomor,
                warna,
                harga,
                imageUri,
                dokumentUri
            )
            _stateUpdateMobil.value = result
        }
    }
}