package com.jefri.carrent.data.services.firebase

import android.net.Uri
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.jefri.carrent.data.model.Mobil
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.tasks.await
import java.util.UUID

class MobilService(
    private val firestore: FirebaseFirestore,
    private val storage: FirebaseStorage
) {
    suspend fun getMobilData(): Result<List<Mobil>> {
        return try {
            val mitraSnapshot = firestore.collection("users")
                .whereEqualTo("role", "mitra")
                .get()
                .await()

            val activeMitraIds = mitraSnapshot.documents
                .filter { doc ->
                    doc.getBoolean("is_deleted") ?: false == false
                }
                .mapNotNull { it.getString("uid") }
                .toSet()

            val mobilSnapshot = firestore.collection("mobil")
                .get()
                .await()

            val mobilList = mobilSnapshot.documents
                .mapNotNull { it.toObject(Mobil::class.java) }
                .filter { it.mitraId in activeMitraIds }

            Result.Success(mobilList)
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun getMobilByMitraId(mitraId: String): Result<List<Mobil>> {
        return try {
            val snapshot = firestore.collection("mobil")
                .whereEqualTo("mitraId", mitraId)
                .get()
                .await()

            val mobilList = snapshot.documents.mapNotNull { it.toObject(Mobil::class.java) }
            Result.Success(mobilList)
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun getMobilById(mobilId: String): Result<Mobil> {
        return try {
            val document = firestore.collection("mobil")
                .document(mobilId)
                .get()
                .await()

            val mobil = document.toObject(Mobil::class.java)
            if (mobil != null) {
                Result.Success(mobil)
            } else {
                Result.Error("Data mobil tidak ditemukan")
            }
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun addMobil(
        mobil: Mobil,
        imageUri: Uri,
        dokumentUri: Uri
    ): Result<String> {
        return try {
            val fileName = "mobil/${mobil.mitraId}_${UUID.randomUUID()}.jpg"
            val ref = storage.reference.child(fileName)

            ref.putFile(imageUri).await()
            val imageUrl = ref.downloadUrl.await().toString()

            val fileNameDokument = "dokument_mobil/${mobil.mitraId}_${UUID.randomUUID()}.jpg"
            val refDokument = storage.reference.child(fileNameDokument)

            refDokument.putFile(dokumentUri).await()
            val dokumentUrl = refDokument.downloadUrl.await().toString()

            val docRef = firestore.collection("mobil").document()

            val mobilWithImage = mobil.copy(
                id = docRef.id,
                fotoUrl = imageUrl,
                dokumentUrl = dokumentUrl
            )

            docRef.set(mobilWithImage).await()

            Result.Success(docRef.id)
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun updateMobil(
        mobilId: String,
        merk: String,
        model: String,
        tahun: String,
        plat: String,
        warna: String,
        harga: Long,
        imageUri: Uri? = null,
        dokumentUri: Uri? = null
    ): Result<String> {
        return try {
            val mobilRef = firestore.collection("mobil").document(mobilId)
            val dataToUpdate = mapOf(
                "merk" to merk,
                "model" to model,
                "tahun" to tahun,
                "platNomor" to plat,
                "warna" to warna,
                "hargaPerHari" to harga,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val updateData = dataToUpdate.toMutableMap()

            if (imageUri != null) {
                val fileName = "mobil/${mobilId}_${UUID.randomUUID()}.jpg"
                val ref = storage.reference.child(fileName)

                ref.putFile(imageUri).await()
                val imageUrl = ref.downloadUrl.await().toString()

                updateData["imageUrl"] = imageUrl
            }

            if (dokumentUri != null) {
                val fileNameDokument = "dokument_mobil/${mobilId}_${UUID.randomUUID()}.jpg"
                val refDokument = storage.reference.child(fileNameDokument)

                refDokument.putFile(dokumentUri).await()
                val dokumentUrl = refDokument.downloadUrl.await().toString()

                updateData["dokumentUrl"] = dokumentUrl
            }

            mobilRef.update(updateData).await()

            Result.Success("Data mobil berhasil diperbarui")
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }
}