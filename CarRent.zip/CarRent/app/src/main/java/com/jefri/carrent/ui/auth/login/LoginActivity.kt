// Mendefinisikan package lokasi file LoginActivity
package com.jefri.carrent.ui.auth.login

// Import class Intent untuk perpindahan antar Activity
import android.content.Intent
// Import Bundle untuk menyimpan state Activity
import android.os.Bundle
// Import viewModels delegate untuk menghubungkan ViewModel dengan Activity
import androidx.activity.viewModels
// Import AppCompatActivity sebagai superclass Activity
import androidx.appcompat.app.AppCompatActivity
// Import MainActivity untuk user
import com.jefri.carrent.ui.user.MainActivity
// Import ViewBinding untuk layout ActivityLogin
import com.jefri.carrent.databinding.ActivityLoginBinding
// Import MainActivity untuk admin
import com.jefri.carrent.ui.admin.MainActivityAdmin
// Import MainActivity untuk mitra
import com.jefri.carrent.ui.mitra.MainActivityMitra
// Import ViewModelFactory untuk inisialisasi ViewModel
import com.jefri.carrent.ui.ViewModelFactory
// Import Activity untuk lupa password
import com.jefri.carrent.ui.auth.forgotpassword.ForgotPasswordActivity
// Import Activity untuk register
import com.jefri.carrent.ui.auth.register.RegisterActivity
// Import extension function hide() untuk menyembunyikan view
import com.jefri.carrent.utils.ext.hide
// Import helper untuk menampilkan alert dialog
import com.jefri.carrent.utils.helpers.AlertHelper
// Import sealed class Result untuk menangani state (Loading, Success, Error)
import com.jefri.carrent.utils.result.Result

// Mendeklarasikan class LoginActivity yang mewarisi AppCompatActivity
class LoginActivity : AppCompatActivity() {

    // Deklarasi variabel binding untuk mengakses view dari layout
    private lateinit var binding: ActivityLoginBinding
    
    // Deklarasi variabel role untuk menyimpan jenis user (admin/user/mitra)
    private lateinit var role: String

    // Inisialisasi LoginViewModel menggunakan ViewModelFactory
    private val loginViewModel by viewModels<LoginViewModel> {
        ViewModelFactory.getInstance(this)
    }

    // Fungsi yang pertama kali dipanggil saat Activity dibuat
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) // Memanggil onCreate milik superclass
        
        // Menghubungkan binding dengan layout XML
        binding = ActivityLoginBinding.inflate(layoutInflater)
        
        // Menampilkan layout ke layar
        setContentView(binding.root)

        // Memanggil fungsi inisialisasi
        init()
    }

    // Fungsi untuk menginisialisasi komponen
    private fun init() {
        getExtraFromRole()      // Mengambil data role dari intent
        setupBtnListener()      // Mengatur aksi klik tombol
        observeStateLogin()     // Mengamati perubahan state login
    }

    // Fungsi untuk mengambil data role dari Activity sebelumnya
    private fun getExtraFromRole() {
        // Mengambil data string "role" dari intent
        role = intent.getStringExtra("role").toString()

        // Jika role adalah admin maka tombol register disembunyikan
        if (role == "admin") binding.llToRegister.hide()
    }

    // Fungsi untuk mengamati perubahan LiveData loginState dari ViewModel
    private fun observeStateLogin() {
        // Observe LiveData loginState
        loginViewModel.loginState.observe(this@LoginActivity) { result ->
            
            // Mengecek apakah result tidak null
            if (result != null) {
                
                // Menentukan aksi berdasarkan tipe Result
                when (result) {
                    
                    // Jika status Loading
                    is Result.Loading -> {
                        // Menampilkan loading pada tombol login
                        binding.btnLogin.setLoading(true)
                    }
                    
                    // Jika status Success
                    is Result.Success -> {
                        // Menghilangkan loading
                        binding.btnLogin.setLoading(false)

                        // Menentukan Activity tujuan berdasarkan role
                        val activity = when (role) {
                            "user" -> MainActivity::class.java
                            "mitra" -> MainActivityMitra::class.java
                            "admin" -> MainActivityAdmin::class.java
                            else -> MainActivity::class.java
                        }

                        // Membuat intent menuju Activity yang sesuai
                        val intent = Intent(this@LoginActivity, activity)
                        
                        // Menghapus semua Activity sebelumnya dan membuat Activity baru
                        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                        
                        // Menjalankan Activity tujuan
                        startActivity(intent)
                        
                        // Menutup LoginActivity
                        finish()
                    }
                    
                    // Jika status Error
                    is Result.Error -> {
                        // Menghilangkan loading
                        binding.btnLogin.setLoading(false)
                        
                        // Menampilkan pesan error menggunakan AlertHelper
                        AlertHelper.showAlert(this@LoginActivity, message = result.message)
                    }
                }
            }
        }
    }

    // Fungsi untuk mengatur aksi tombol
    private fun setupBtnListener() {
        // Menggunakan scope function with untuk mempermudah akses binding
        with (binding) {
            
            // Listener ketika tombol Login diklik
            btnLogin.setOnClickListener {
                
                // Validasi input email dan password
                val valid = etEmail.validate() and etPassword.validate()

                // Jika tidak valid maka hentikan proses
                if (!valid) return@setOnClickListener

                // Mengambil nilai email dari input
                val email = etEmail.getText()
                
                // Mengambil nilai password dari input
                val password = etPassword.getText()

                // Memanggil fungsi login di ViewModel
                loginViewModel.login(email, password, role)
            }

            // Listener ketika tombol Register diklik
            btnRegister.setOnClickListener {
                
                // Intent menuju RegisterActivity
                val intentToRegister = Intent(this@LoginActivity, RegisterActivity::class.java)
                
                // Mengirim data role ke RegisterActivity
                intentToRegister.putExtra("role", role)
                
                // Menjalankan RegisterActivity
                startActivity(intentToRegister)
            }

            // Listener ketika teks Forgot Password diklik
            tvForgotPassword.setOnClickListener {
                
                // Intent menuju ForgotPasswordActivity
                val intentToForgotPassword = Intent(this@LoginActivity, ForgotPasswordActivity::class.java)
                
                // Menjalankan ForgotPasswordActivity
                startActivity(intentToForgotPassword)
            }
        }
    }
}