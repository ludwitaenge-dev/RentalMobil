package com.jefri.carrent.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.jefri.carrent.data.repository.AdminRepository
import com.jefri.carrent.data.repository.AuthenticationRepository
import com.jefri.carrent.data.repository.MitraRepository
import com.jefri.carrent.data.repository.UserRepository
import com.jefri.carrent.di.Injection
import com.jefri.carrent.ui.admin.chat.ChatAdminViewModel
import com.jefri.carrent.ui.admin.home.DetailMitraAdminViewModel
import com.jefri.carrent.ui.admin.home.HomeAdminViewModel
import com.jefri.carrent.ui.admin.notifications.NotificationsAdminViewModel
import com.jefri.carrent.ui.admin.settings.PaymentMethodViewModel
import com.jefri.carrent.ui.admin.transaction.DetailTransactionAdminViewModel
import com.jefri.carrent.ui.admin.transaction.TransactionAdminViewModel
import com.jefri.carrent.ui.auth.forgotpassword.ForgotPasswordViewModel
import com.jefri.carrent.ui.auth.login.LoginViewModel
import com.jefri.carrent.ui.auth.register.RegisterViewModel
import com.jefri.carrent.ui.mitra.UserMitraViewModel
import com.jefri.carrent.ui.mitra.additional.AdditionalInformationMitraViewModel
import com.jefri.carrent.ui.mitra.chat.ChatMitraViewModel
import com.jefri.carrent.ui.mitra.home.HomeMitraViewModel
import com.jefri.carrent.ui.mitra.mobil.DetailMobilMitraViewModel
import com.jefri.carrent.ui.mitra.notifications.NotificationsMitraViewModel
import com.jefri.carrent.ui.mitra.transaction.DetailTransactionMitraViewModel
import com.jefri.carrent.ui.mitra.transaction.TransactionMitraViewModel
import com.jefri.carrent.ui.splash.SplashViewModel
import com.jefri.carrent.ui.user.add_transaction.add_data.AddTransactionViewModel
import com.jefri.carrent.ui.user.add_transaction.overview.OverviewTransactionViewModel
import com.jefri.carrent.ui.user.add_transaction.payment.PaymentViewModel
import com.jefri.carrent.ui.user.add_transaction.select_muatan.SelectMuatanViewModel
import com.jefri.carrent.ui.user.car_mitra.CarMitraViewModel
import com.jefri.carrent.ui.user.chat.ChatViewModel
import com.jefri.carrent.ui.user.chat.DetailChatViewModel
import com.jefri.carrent.ui.user.home.HomeViewModel
import com.jefri.carrent.ui.user.notifications.NotificationsViewModel
import com.jefri.carrent.ui.user.transaction.DetailTransactionViewModel
import com.jefri.carrent.ui.user.transaction.TransactionViewModel
import com.jefri.carrent.ui.admin.user.UserAdminViewModel

class ViewModelFactory private constructor(
    private val authenticationRepository: AuthenticationRepository,
    private val userRepository: UserRepository,
    private val adminRepository: AdminRepository,
    private val mitraRepository: MitraRepository
) : ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when (modelClass) {
            // ----- SPLASH ----- //
            SplashViewModel::class.java -> {
                SplashViewModel(authenticationRepository) as T
            }

            // ----- AUTH ----- //
            LoginViewModel::class.java -> {
                LoginViewModel(authenticationRepository) as T
            }

            RegisterViewModel::class.java -> {
                RegisterViewModel(authenticationRepository) as T
            }

            ForgotPasswordViewModel::class.java -> {
                ForgotPasswordViewModel(authenticationRepository) as T
            }

            // ----- USER ----- //

            HomeViewModel::class.java -> {
                HomeViewModel(userRepository) as T
            }

            AddTransactionViewModel::class.java -> {
                AddTransactionViewModel(userRepository) as T
            }

            ChatViewModel::class.java -> {
                ChatViewModel(userRepository) as T
            }

            DetailChatViewModel::class.java -> {
                DetailChatViewModel(userRepository) as T
            }

            CarMitraViewModel::class.java -> {
                CarMitraViewModel(mitraRepository) as T
            }

            SelectMuatanViewModel::class.java -> {
                SelectMuatanViewModel(userRepository) as T
            }

            TransactionViewModel::class.java -> {
                TransactionViewModel(userRepository) as T
            }

            OverviewTransactionViewModel::class.java -> {
                OverviewTransactionViewModel(userRepository) as T
            }

            PaymentViewModel::class.java -> {
                PaymentViewModel(userRepository) as T
            }

            DetailTransactionViewModel::class.java -> {
                DetailTransactionViewModel(userRepository) as T
            }

            NotificationsViewModel::class.java -> {
                NotificationsViewModel(userRepository) as T
            }

            // ----- MITRA ----- //
            HomeMitraViewModel::class.java -> {
                HomeMitraViewModel(mitraRepository) as T
            }

            AdditionalInformationMitraViewModel::class.java -> {
                AdditionalInformationMitraViewModel(mitraRepository) as T
            }

            TransactionMitraViewModel::class.java -> {
                TransactionMitraViewModel(mitraRepository) as T
            }

            UserMitraViewModel::class.java -> {
                UserMitraViewModel(mitraRepository) as T
            }

            ChatMitraViewModel::class.java -> {
                ChatMitraViewModel(mitraRepository) as T
            }

            DetailMobilMitraViewModel::class.java -> {
                DetailMobilMitraViewModel(mitraRepository) as T
            }

            DetailTransactionMitraViewModel::class.java -> {
                DetailTransactionMitraViewModel(mitraRepository) as T
            }

            NotificationsMitraViewModel::class.java -> {
                NotificationsMitraViewModel(mitraRepository) as T
            }

            // ----- ADMIN ----- //
            HomeAdminViewModel::class.java -> {
                HomeAdminViewModel(adminRepository) as T
            }

            TransactionAdminViewModel::class.java -> {
                TransactionAdminViewModel(adminRepository) as T
            }

            DetailTransactionAdminViewModel::class.java -> {
                DetailTransactionAdminViewModel(adminRepository) as T
            }

            ChatAdminViewModel::class.java -> {
                ChatAdminViewModel(adminRepository) as T
            }

            DetailMitraAdminViewModel::class.java -> {
                DetailMitraAdminViewModel(adminRepository) as T
            }

            NotificationsAdminViewModel::class.java -> {
                NotificationsAdminViewModel(adminRepository) as T
            }

            UserAdminViewModel::class.java -> {
                UserAdminViewModel(authenticationRepository) as T
            }

            PaymentMethodViewModel::class.java -> {
                PaymentMethodViewModel(adminRepository) as T
            }

            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: ViewModelFactory? = null

        fun getInstance(context: Context): ViewModelFactory {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ViewModelFactory(
                    Injection.provideAuthRepository(context),
                    Injection.provideUserRepository(),
                    Injection.provideAdminRepository(),
                    Injection.provideMitraRepository()
                ).also {
                    INSTANCE = it
                }
            }
        }
    }
}