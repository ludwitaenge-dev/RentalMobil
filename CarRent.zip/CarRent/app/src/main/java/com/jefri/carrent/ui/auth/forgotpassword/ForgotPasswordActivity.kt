// Mendefinisikan package lokasi file ForgotPasswordActivity
package com.jefri.carrent.ui.auth.forgotpassword

// Import Bundle untuk menyimpan state Activity
import android.os.Bundle
// Import viewModels delegate untuk menghubungkan ViewModel dengan Activity
import androidx.activity.viewModels
// Import AppCompatActivity sebagai superclass Activity
import androidx.appcompat.app.AppCompatActivity
// Import ViewBinding untuk menghubungkan layout XML dengan Activity
import com.jefri.carrent.databinding.ActivityForgotPasswordBinding
// Import ViewModelFactory untuk membuat instance ViewModel
import com.jefri.carrent.ui.ViewModelFactory
// Import AlertHelper untuk menampilkan dialog notifikasi
import com.jefri.carrent.utils.helpers.AlertHelper
// Import sealed class Result untuk menangani state (Loading, Success, Error)
import com.jefri.carrent.utils.result.Result

// Mendeklarasikan class ForgotPasswordActivity yang mewarisi AppCompatActivity
class ForgotPasswordActivity : AppCompatActivity() {

    // Deklarasi variabel binding untuk mengakses komponen layout
    private lateinit var binding: ActivityForgotPasswordBinding

    // Inisialisasi ForgotPasswordViewModel menggunakan ViewModelFactory
    private val viewModel by viewModels<ForgotPasswordViewModel> {
        ViewModelFactory.getInstance(this)
    }

    // Fungsi pertama yang dipanggil saat Activity dibuat
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) // Memanggil onCreate milik superclass
        
        // Menghubungkan binding dengan layout XML
        binding = ActivityForgotPasswordBinding.inflate(layoutInflater)
        
        // Menampilkan layout ke layar
        setContentView(binding.root)

        // Memanggil fungsi inisialisasi
        init()
    }

    // Fungsi untuk menginisialisasi komponen
    private fun init() {
        setupBtnListener()            // Mengatur aksi tombol
        observeStateLupaPassword()    // Mengamati perubahan state verifikasi
    }

    // Fungsi untuk mengamati LiveData verifikasiState dari ViewModel
    private fun observeStateLupaPassword() {
        
        // Observe LiveData verifikasiState
        viewModel.verifikasiState.observe(this) { result ->
            
            // Mengecek apakah result tidak null
            if (result != null) {
                
                // Menentukan aksi berdasarkan tipe Result
                when (result) {
                    
                    // Jika status Loading
                    is Result.Loading -> {
                        // Menampilkan loading pada tombol verifikasi
                        binding.btnVerifikasi.setLoading(true)
                    }

                    // Jika status Success
                    is Result.Success -> {
                        // Menghilangkan loading
                        binding.btnVerifikasi.setLoading(false)
                        
                        // Menampilkan alert dialog dengan pesan sukses
                        AlertHelper.showAlert(
                            this@ForgotPasswordActivity,
                            message = result.data.toString(), // Pesan dari hasil verifikasi
                            onConfirm = {
                                finish() // Menutup Activity setelah konfirmasi
                            }
                        )
                    }

                    // Jika status Error
                    is Result.Error -> {
                        // Menghilangkan loading
                        binding.btnVerifikasi.setLoading(false)
                        
                        // Menampilkan alert dialog dengan pesan error
                        AlertHelper.showAlert(
                            this@ForgotPasswordActivity,
                            message = result.message,
                        )
                    }
                }
            }
        }
    }

    // Fungsi untuk mengatur aksi tombol
    private fun setupBtnListener() {
        
        // Menggunakan scope function with untuk mempermudah akses binding
        with(binding) {
            
            // Listener ketika tombol Verifikasi diklik
            btnVerifikasi.setOnClickListener {
                
                // Validasi input email
                val isValid = etEmail.validate()
                
                // Jika tidak valid, hentikan proses
                if (!isValid) return@setOnClickListener

                // Mengambil nilai email dari input
                val email = etEmail.getText()
                
                // Memanggil fungsi verifikasi pada ViewModel
                viewModel.verifikasi(email)
            }
        }
    }
}