package com.jefri.carrent.custom_ui.bottom_sheet

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.auth.FirebaseAuth
import com.jefri.carrent.data.services.datastore.UserPreferences
import com.jefri.carrent.data.services.datastore.dataStore
import com.jefri.carrent.databinding.BottomsheetLogoutBinding
import com.jefri.carrent.ui.auth.role.SelectRoleActivity
import kotlinx.coroutines.launch

class LogoutBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomsheetLogoutBinding? = null
    private val binding get() = _binding!!

    private lateinit var userPreferences: UserPreferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomsheetLogoutBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userPreferences = UserPreferences.getInstance(requireContext().dataStore)

        binding.btnCancel.setOnClickListener {
            dismiss()
        }

        binding.btnLogout.setOnClickListener {
            performLogout()
        }
    }

    private fun performLogout() {
        FirebaseAuth.getInstance().signOut()

        viewLifecycleOwner.lifecycleScope.launch {
            userPreferences.clearUid()
        }

        val intent = Intent(requireContext(), SelectRoleActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        dismiss()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}