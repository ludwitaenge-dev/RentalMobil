package com.jefri.carrent.ui.user.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Chat
import com.jefri.carrent.data.model.Message
import com.jefri.carrent.data.repository.UserRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DetailChatViewModel(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _messages = MutableStateFlow<Result<List<Message>>>(Result.Loading)
    val messages: StateFlow<Result<List<Message>>> = _messages

    private val _chatDetail = MutableStateFlow<Result<Chat>>(Result.Loading)
    val chatDetail: StateFlow<Result<Chat>> = _chatDetail

    fun listenMessages(chatId: String) {
        viewModelScope.launch {
            userRepository.listenMessages(chatId).collectLatest { result ->
                _messages.value = result
            }
        }
    }

    fun sendMessage(chatId: String, senderId: String, text: String) {
        viewModelScope.launch {
            userRepository.sendMessage(chatId, senderId, text)
        }
    }

    fun loadChatDetail(chatId: String) {
        viewModelScope.launch {
            try {
                val chat = userRepository.getChatDetail(chatId)
                if (chat != null) {
                    _chatDetail.value = Result.Success(chat)
                } else {
                    _chatDetail.value = Result.Error("Chat not found")
                }
            } catch (e: Exception) {
                _chatDetail.value = Result.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun getUserId() = userRepository.getCurrentUser()?.uid
}
