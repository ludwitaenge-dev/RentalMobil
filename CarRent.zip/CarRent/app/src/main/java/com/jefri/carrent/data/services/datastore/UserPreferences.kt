package com.jefri.carrent.data.services.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "uid")

class UserPreferences private constructor(
    private val dataStore: DataStore<Preferences>
) {
    fun getUid() = dataStore.data.map { preferences ->
        preferences[TOKEN_KEY]
    }

    suspend fun saveUid(uid: String) {
        dataStore.edit { preferences ->
            preferences[TOKEN_KEY] = uid
        }
    }

    suspend fun clearUid() = dataStore.edit {
        it.clear()
    }

    companion object {
        @Volatile
        private var INSTANCE: UserPreferences? = null

        private val TOKEN_KEY = stringPreferencesKey("uid")

        fun getInstance(dataStore: DataStore<Preferences>): UserPreferences {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: UserPreferences(
                    dataStore
                ).also {
                    INSTANCE = it
                }
            }
        }
    }

}