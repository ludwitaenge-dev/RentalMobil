package com.jefri.carrent.data.model

data class Notification(
    val id: String = "",
    val title: String = "",
    val body: String = "",
    val data: Map<String, String>? = null,
    val isRead: Boolean = false,
    val createdAt: com.google.firebase.Timestamp? = null
)
