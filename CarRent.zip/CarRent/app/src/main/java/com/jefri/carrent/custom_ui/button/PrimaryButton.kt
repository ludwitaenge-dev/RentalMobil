package com.jefri.carrent.custom_ui.button

import android.content.Context
import android.content.res.ColorStateList
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import androidx.core.content.withStyledAttributes
import com.jefri.carrent.R
import com.jefri.carrent.databinding.ViewPrimaryButtonBinding
import com.jefri.carrent.utils.ext.hideKeyboard

class PrimaryButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private val binding = ViewPrimaryButtonBinding.inflate(LayoutInflater.from(context), this)
    private var isLoading = false
    private val duration = 100L
    private val interpolator = AccelerateDecelerateInterpolator()

    init {
        isClickable = true
        isFocusable = true

        context.withStyledAttributes(attrs, R.styleable.PrimaryButton) {
            val text = getString(R.styleable.PrimaryButton_text)
            val bgColor = getColor(
                R.styleable.PrimaryButton_backgroundColor,
                ContextCompat.getColor(context, R.color.primary_blue)
            )
            val iconRes = getResourceId(R.styleable.PrimaryButton_icon, 0)

            binding.tvText.text = text ?: "Button"
            binding.btnContainer.backgroundTintList = ColorStateList.valueOf(bgColor)

            if (iconRes != 0) {
                binding.ivIcon.setImageResource(iconRes)
                binding.ivIcon.visibility = VISIBLE
            } else {
                binding.ivIcon.visibility = GONE
            }

            if (text.isNullOrEmpty() && iconRes != 0) {
                val params = binding.ivIcon.layoutParams as LinearLayout.LayoutParams
                params.setMargins(0, 0, 0, 0)
                binding.ivIcon.layoutParams = params
                binding.llContent.gravity = Gravity.CENTER
            }
        }
    }

    fun setText(text: String?) {
        binding.tvText.text = text ?: ""
        binding.tvText.visibility = if (text.isNullOrEmpty()) GONE else VISIBLE
    }

    fun setIcon(@DrawableRes iconRes: Int?) {
        if (iconRes != null && iconRes != 0) {
            binding.ivIcon.setImageResource(iconRes)
            binding.ivIcon.visibility = VISIBLE
        } else {
            binding.ivIcon.visibility = GONE
        }
    }

    fun setLoading(loading: Boolean) {
        if (loading == isLoading) return
        isLoading = loading

        if (loading) {
            hideKeyboard()
            animateViews(binding.llContent, binding.progressBar)
            isEnabled = false
        } else {
            animateViews(binding.progressBar, binding.llContent)
            isEnabled = true
        }

        binding.btnContainer.isEnabled = !loading
        alpha = if (loading) 0.9f else 1f
    }

    private fun animateViews(fadeOut: View, fadeIn: View) {
        fadeOut.animate()
            .alpha(0f)
            .setDuration(duration)
            .setInterpolator(interpolator)
            .withEndAction {
                fadeOut.visibility = GONE
                fadeIn.alpha = 0f
                fadeIn.visibility = VISIBLE
                fadeIn.animate()
                    .alpha(1f)
                    .setDuration(duration)
                    .setInterpolator(interpolator)
                    .start()
            }.start()
    }

    fun enable(state: Boolean) {
        binding.btnContainer.isEnabled = state
        binding.btnContainer.alpha = if (state) 1f else 0.6f
    }
}

