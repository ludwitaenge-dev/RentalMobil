package com.jefri.carrent.ui.user.add_transaction.overview

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.repository.UserRepository
import kotlinx.coroutines.launch
import com.jefri.carrent.utils.result.Result

class OverviewTransactionViewModel(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _addOrderResult = MutableLiveData<Result<String>>()
    val addOrderResult: LiveData<Result<String>> get() = _addOrderResult

    fun addOrder(order: Order, nama: String, noTelp: String, alamat: String) {
        viewModelScope.launch {
            try {
                _addOrderResult.value = Result.Loading

                val userUpdates = mapOf(
                    "name" to nama,
                    "noTelp" to noTelp,
                    "alamat" to alamat
                )
                val updateResult = userRepository.updateUserData(userUpdates)
                if (updateResult is Result.Error) {
                    _addOrderResult.value = Result.Error("Gagal update data user: ${updateResult.message}")
                    return@launch
                }

                val result = userRepository.addOrder(order)
                _addOrderResult.value = result

            } catch (e: Exception) {
                _addOrderResult.value = Result.Error(e.message ?: "Unknown error")
            }
        }
    }
}