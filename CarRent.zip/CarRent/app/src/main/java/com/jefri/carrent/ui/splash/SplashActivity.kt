package com.jefri.carrent.ui.splash

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.jefri.carrent.databinding.ActivitySplashBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.admin.MainActivityAdmin
import com.jefri.carrent.ui.auth.role.SelectRoleActivity
import com.jefri.carrent.ui.mitra.MainActivityMitra
import com.jefri.carrent.ui.user.MainActivity
import com.jefri.carrent.utils.helpers.AlertHelper

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding

    private val splashViewModel by viewModels<SplashViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
    }

    private fun init() {
        setupObserver()
    }

    private fun setupObserver() {
        splashViewModel.splashState.observe(this) { state ->
            when (state) {
                is SplashState.Loading -> {}
                is SplashState.NotLoggedIn -> navigateTo(SelectRoleActivity::class.java)
                is SplashState.LoggedIn -> {
                    when (state.role) {
                        "user" -> navigateTo(MainActivity::class.java)
                        "mitra" -> navigateTo(MainActivityMitra::class.java)
                        "admin" -> navigateTo(MainActivityAdmin::class.java)
                    }
                }

                is SplashState.Error -> AlertHelper.showAlert(this, message = state.message)
            }
        }
    }

    private fun navigateTo(activity: Class<*>, clearTask: Boolean = true) {
        val intent = Intent(this, activity)
        if (clearTask) {
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        }

        startActivity(intent)
    }
}