package com.jefri.carrent.ui.user.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.jefri.carrent.R
import com.jefri.carrent.data.model.Muatan
import com.jefri.carrent.databinding.ItemMuatanBinding
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.toRupiah

class MuatanHomeAdapter(
    private val onItemClick: ((Muatan) -> Unit)? = null
) : ListAdapter<Muatan, MuatanHomeAdapter.MuatanViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MuatanViewHolder {
        val binding = ItemMuatanBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MuatanViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MuatanViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    inner class MuatanViewHolder(private val binding: ItemMuatanBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Muatan) {
            with(binding) {
                Glide.with(binding.ivMuatanImage.context)
                    .load(item.imageUrl)
                    .placeholder(R.drawable.bg_image_placeholder)
                    .centerCrop()
                    .into(binding.ivMuatanImage)

                tvRating.text = item.averageRating.toString()
                tvRatingCount.text =
                    binding.root.context.getString(R.string.total_rating_count, item.totalRatingCount)
                tvCapacity.text = item.kapasitas
                tvMitra.text = item.mitraName

                val price = item.harga.toRupiah()
                tvHarga.text = price

                if (item.isBooked) {
                    tvStatusLabel.show()
                    tvStatusLabel.text = "Sedang Dipesan"
                } else {
                    tvStatusLabel.hide()
                    root.setOnClickListener { onItemClick?.invoke(item) }
                }
            }
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Muatan>() {
            override fun areItemsTheSame(oldItem: Muatan, newItem: Muatan): Boolean =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: Muatan, newItem: Muatan): Boolean =
                oldItem == newItem
        }
    }
}