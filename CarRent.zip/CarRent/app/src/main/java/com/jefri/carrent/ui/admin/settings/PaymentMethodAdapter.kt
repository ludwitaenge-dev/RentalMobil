package com.jefri.carrent.ui.admin.settings

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.jefri.carrent.data.model.PaymentMethod
import com.jefri.carrent.databinding.ItemPaymentMethodAdminBinding

class PaymentMethodAdapter(private val onEditClick: (PaymentMethod) -> Unit) :
    ListAdapter<PaymentMethod, PaymentMethodAdapter.ViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPaymentMethodAdminBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemPaymentMethodAdminBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: PaymentMethod) {
            binding.tvPaymentName.text = item.name
            binding.tvPaymentNumber.text = item.number

            binding.cardMethodPayment.setOnClickListener {
                onEditClick(item)
            }

        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<PaymentMethod>() {
            override fun areItemsTheSame(oldItem: PaymentMethod, newItem: PaymentMethod) =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: PaymentMethod, newItem: PaymentMethod) =
                oldItem == newItem
        }
    }
}
