package com.jefri.carrent.custom_ui.input

import android.content.Context
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.AttributeSet
import com.jefri.carrent.utils.ext.toRupiahWithoutSymbol
import com.jefri.carrent.utils.helpers.ValidationUtils

class PriceInputView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : BaseInputView(context, attrs, defStyleAttr) {

    private var currentText = ""

    init {
        setHint("Harga")
        binding.etInput.inputType = InputType.TYPE_CLASS_NUMBER

        setupCurrencyFormatter()
    }

    private fun setupCurrencyFormatter() {
        binding.etInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(editable: Editable?) {
                val newText = editable.toString()

                if (newText == currentText) return

                val cleanText = newText.replace(Regex("\\D"), "")

                if (cleanText.isNotEmpty()) {
                    try {
                        val parsed = cleanText.toLong()
                        val formatted = parsed.toRupiahWithoutSymbol()
                        currentText = "Rp$formatted"

                        binding.etInput.removeTextChangedListener(this)
                        binding.etInput.setText(currentText)
                        binding.etInput.setSelection(currentText.length)
                        binding.etInput.addTextChangedListener(this)
                    } catch (_: Exception) { }
                } else {
                    currentText = ""
                    binding.etInput.removeTextChangedListener(this)
                    binding.etInput.setText("")
                    binding.etInput.addTextChangedListener(this)
                }
            }
        })
    }

    override fun validate(): Boolean {
        val priceText = getText()
        val price = priceText.toDoubleOrNull() ?: 0.0

        return if (!ValidationUtils.isNotEmpty(priceText)) {
            showError("Harga tidak boleh kosong")
            false
        } else if (price <= 0) {
            showError("Harga harus lebih dari 0")
            false
        } else {
            showError(null)
            true
        }
    }

    override fun getText(): String {
        val clean = super.getText().replace(Regex("[^\\d]"), "")
        return clean
    }
}