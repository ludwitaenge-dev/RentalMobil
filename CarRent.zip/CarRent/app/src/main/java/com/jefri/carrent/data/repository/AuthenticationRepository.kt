package com.jefri.carrent.data.repository

import android.util.Log
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import com.jefri.carrent.data.model.User
import com.jefri.carrent.data.services.datastore.UserPreferences
import com.jefri.carrent.data.services.firebase.AuthService
import com.jefri.carrent.data.services.firebase.ChatService
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.tasks.await

class AuthenticationRepository private constructor(
    private val firebaseAuthService: AuthService,
    private val preference: UserPreferences
) {
    fun isLoggedIn(): Boolean {
        var isAlreadyLogin = true
        if (!firebaseAuthService.isUserSignedIn()) isAlreadyLogin = false
        if (preference.getUid().toString().isEmpty()) isAlreadyLogin = false
        return isAlreadyLogin
    }

    suspend fun getUserDataFromFirestore(): User? {
        return try {
            val uid = getCurrentUser()?.uid ?: return null
            return firebaseAuthService.getFirestoreUser(uid)
        } catch (e: Exception) {
            null
        }
    }

    fun getCurrentUser(): FirebaseUser? {
        return firebaseAuthService.getCurrentUser()
    }

    suspend fun login(email: String, password: String, role: String): Result<String?> {
        return try {
            val result = firebaseAuthService.signInWithEmailPassword(email, password)
            when (result) {
                is Result.Success -> {
                    preference.saveUid(role)
                    Result.Success("Success")
                }
                is Result.Error -> {
                    Result.Error(result.message)
                }
                else -> Result.Error("Unknown error")
            }
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun register(name: String, email: String, password: String, role: String): Result<String?> {
        return try {
            val result = firebaseAuthService.createUserWithEmailPassword(email, password)
            when (result) {
                is Result.Success -> {
                    val isActive = role != "mitra"
                    val user = User(
                        uid = result.data.uid,
                        name = name,
                        role = role,
                        isActive = isActive,
                        isDeleted = false,
                    )

                    val firestoreResult = firebaseAuthService.createUserInFirestore(result.data, user)

                    if (firestoreResult is Result.Success && role != "admin") {
                        createDefaultChatWithAdmin(user)
                    }

                    firestoreResult
                }
                is Result.Error -> {
                    Result.Error(result.message)
                }
                else -> Result.Error("Unknown error")
            }
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    private suspend fun createDefaultChatWithAdmin(user: User) {
        try {
            val adminSnapshot = FirebaseFirestore.getInstance()
                .collection("users")
                .whereEqualTo("role", "admin")
                .limit(1)
                .get()
                .await()

            if (!adminSnapshot.isEmpty) {
                val admin = adminSnapshot.documents[0].toObject(User::class.java)
                if (admin != null) {
                    val chatService = ChatService(FirebaseDatabase.getInstance())
                    chatService.createChatRoomIfNotExists(
                        userId = user.uid,
                        adminId = admin.uid,
                        userName = user.name,
                        adminName = admin.name
                    )
                }
            }
        } catch (e: Exception) {
            Log.e("AuthRepository", "Error creating default chat: ${e.message}")
        }
    }


    suspend fun forgotPassword(email: String): Result<String> {
        return firebaseAuthService.sendPasswordResetEmail(email)
    }

    suspend fun getUsers(): List<User> {
        return firebaseAuthService.getAllNonAdminUsers()
    }

    suspend fun toggleUser(uid: String, newIsActive: Boolean): Boolean {
        val newIsDeleted = !newIsActive
        return firebaseAuthService.updateUserStatus(uid, newIsDeleted)
    }

    companion object {
        @Volatile
        private var INSTANCE: AuthenticationRepository? = null

        fun getInstance(firebaseAuthService: AuthService, preferences: UserPreferences): AuthenticationRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AuthenticationRepository(
                    firebaseAuthService,
                    preferences
                ).also {
                    INSTANCE = it
                }
            }
        }
    }
}