package com.jefri.carrent.data.services.firebase

import android.net.Uri
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.model.User
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.tasks.await
import java.util.UUID

class OrderService(
    private val firestore: FirebaseFirestore,
    private val storage: FirebaseStorage
) {
    suspend fun getOrdersData(
        uid: String? = null,
        mitraUid: String? = null,
        status: List<String>? = null
    ): Result<List<Order>> {
        return try {
            var query: Query = firestore.collection("orders")

            if (!uid.isNullOrEmpty()) {
                query = query.whereEqualTo("user.uid", uid)
            }

            if (!mitraUid.isNullOrEmpty()) {
                query = query.whereEqualTo("mobil.mitraId", mitraUid)
            }

            if (!status.isNullOrEmpty()) {
                query = query.whereIn("status", status)
            }

            val snapshot = query.get().await()
            val orders = snapshot.documents.mapNotNull { it.toObject(Order::class.java) }
            Result.Success(orders)
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun getOrdersActiveData(
        uid: String? = null,
    ): Result<List<Order>> {
        return try {
            val snapshot = firestore.collection("orders")
                .whereEqualTo("user.uid", uid)
                .get()
                .await()

            val orders = snapshot.documents.mapNotNull { it.toObject(Order::class.java) }
                .filter { it.status.lowercase() != "selesai" && it.status.lowercase() != "dibatalkan" }

            Result.Success(orders)
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun getCurrentOrder(orderId: String): Result<Order> {
        return try {
            val snapshot = firestore.collection("orders")
                .document(orderId)
                .get()
                .await()

            var order = snapshot.toObject(Order::class.java)

            if (order?.cancelBy != null) {
                val userSnapshot = firestore.collection("users")
                    .document(order.cancelBy)
                    .get()
                    .await()

                val user = userSnapshot.toObject(User::class.java)
                order = order.copy(
                    cancelBy = user?.name ?: order.cancelBy
                )
            }

            if (order != null) {
                Result.Success(order)
            } else {
                Result.Error("Order not found")
            }
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun addOrder(order: Order): Result<String> {
        return try {
            val docRef = firestore.collection("orders").add(order).await()

            firestore.collection("orders").document(docRef.id)
                .update("id", docRef.id).await()

            Result.Success(docRef.id)
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun uploadBuktiPembayaran(orderId: String, imageUri: Uri): Result<String> {
        return try {
            val fileName = "bukti_transfer/${orderId}_${UUID.randomUUID()}.jpg"
            val ref = storage.reference.child(fileName)

            ref.putFile(imageUri).await()

            val imageUrl = ref.downloadUrl.await().toString()

            firestore.collection("orders").document(orderId)
                .update(
                    mapOf(
                        "buktiTransfer" to imageUrl,
                        "status" to "menunggu_konfirmasi_admin"
                    )
                ).await()

            Result.Success(imageUrl)
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

    suspend fun acceptOrder(
        orderId: String,
        role: String,
        rating: Int? = null,
    ): Result<String> {
        when (role) {
            "admin" -> {
                return try {
                    val dataToUpdate = mapOf(
                        "status" to "menunggu_konfirmasi_mitra",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )

                    firestore.collection("orders")
                        .document(orderId)
                        .update(dataToUpdate)
                        .await()

                    Result.Success("Success")
                } catch (e: Exception) {
                    Result.Error(e.toString())
                }
            }
            "mitra" -> {
                return try {
                    val dataToUpdate = mapOf(
                        "status" to "diproses",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )

                    firestore.collection("orders")
                        .document(orderId)
                        .update(dataToUpdate)
                        .await()

                    Result.Success("Success")
                } catch (e: Exception) {
                    Result.Error(e.toString())
                }
            }
            else -> {
                return try {
                    val dataToUpdate = mapOf(
                        "status" to "selesai",
                        "rating" to rating,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )

                    val orderRef = firestore.collection("orders").document(orderId)
                    orderRef.update(dataToUpdate).await()

                    val orderSnapshot = orderRef.get().await()
                    val mobilId = orderSnapshot.getString("mobil.id")
                    if (mobilId != null && rating != null) {
                        updateMobilRating(mobilId, rating)
                    }

                    Result.Success("Success")
                } catch (e: Exception) {
                    Result.Error(e.toString())
                }
            }
        }
    }

    private suspend fun updateMobilRating(mobilId: String, newRating: Int) {
        val mobilRef = firestore.collection("mobil").document(mobilId)

        firestore.runTransaction { transaction ->
            val snapshot = transaction.get(mobilRef)
            val oldAvg = snapshot.getDouble("averageRating") ?: 0.0
            val oldCount = snapshot.getLong("totalRatingCount") ?: 0

            val newAvg = ((oldAvg * oldCount) + newRating) / (oldCount + 1)
            val newData = mapOf(
                "averageRating" to newAvg,
                "totalRatingCount" to oldCount + 1
            )

            transaction.update(mobilRef, newData)
        }.await()
    }

    suspend fun cancelOrder(
        orderId: String,
        reason: String,
        cancelBy: String?
    ): Result<String> {
        return try {
            val dataToUpdate = mapOf(
                "status" to "dibatalkan",
                "cancelReason" to reason,
                "cancelBy" to cancelBy,
                "updatedAt" to FieldValue.serverTimestamp()
            )

            firestore.collection("orders")
                .document(orderId)
                .update(dataToUpdate)
                .await()

            Result.Success("Success")
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }

}