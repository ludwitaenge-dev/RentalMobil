package com.jefri.carrent.custom_ui.bottom_sheet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.jefri.carrent.databinding.BottomsheetCancelTransactionBinding

class CancelTransactionBottomSheet(
    private val onConfirm: (
        reason: String,
        setLoading: (Boolean) -> Unit,
        dismiss: () -> Unit,
    ) -> Unit
) : BottomSheetDialogFragment() {

    private var _binding: BottomsheetCancelTransactionBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomsheetCancelTransactionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        with(binding) {
            btnBatalkan.setOnClickListener {
                val isValid = etAlasan.validate()
                if (!isValid) return@setOnClickListener

                btnBatalkan.setLoading(true)

                onConfirm(
                    etAlasan.getText(),
                    { isLoading ->
                        btnBatalkan.setLoading(isLoading)
                    },
                    {
                        dismiss()
                    },
                )
            }

            btnCancel.setOnClickListener {
                dismiss()
            }
        }
    }

    fun setLoading(state: Boolean) {
        binding.btnBatalkan.setLoading(state)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}