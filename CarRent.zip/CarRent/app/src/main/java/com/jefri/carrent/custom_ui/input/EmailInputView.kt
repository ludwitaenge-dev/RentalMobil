package com.jefri.carrent.custom_ui.input

import android.content.Context
import android.text.InputType
import android.util.AttributeSet
import androidx.core.content.ContextCompat.getString
import com.jefri.carrent.R
import com.jefri.carrent.utils.helpers.ValidationUtils

class EmailInputView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : BaseInputView(context, attrs, defStyleAttr) {

    init {
        setHint(getString(context, R.string.lorem_ipsum_gmail_com))
        binding.etInput.inputType = InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
    }

    override fun validate(): Boolean {
        val email = getText()
        return if (email.isEmpty()) {
            showError("Email tidak boleh kosong")
            false
        } else if(!ValidationUtils.isValidEmail(email)) {
            showError("Email tidak valid")
            false
        } else {
            showError(null)
            true
        }
    }
}
