package com.jefri.carrent.ui.admin.transaction

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.bumptech.glide.Glide
import com.jefri.carrent.R
import com.jefri.carrent.custom_ui.bottom_sheet.CancelTransactionBottomSheet
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.databinding.ActivityDetailTransactionAdminBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.setStatusStyle
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.ext.toReadableStatus
import com.jefri.carrent.utils.ext.toRupiah
import com.jefri.carrent.utils.helpers.DateHelper
import com.jefri.carrent.utils.result.Result

class DetailTransactionAdminActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailTransactionAdminBinding
    private var orderId: String? = null

    private val viewModel by viewModels<DetailTransactionAdminViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private var bottomSheet: CancelTransactionBottomSheet? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        binding = ActivityDetailTransactionAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
    }

    private fun init() {
        receiveIntentFromMain()
        observeOrderData()
        setupBtnListener()
        observeCancelTransaction()
        observeAcceptTransaction()
    }

    private fun observeOrderData() {
        viewModel.getCurrentOrderData(orderId.toString())
        viewModel.orderData.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.progressBar.show()
                    }

                    is Result.Success -> {
                        binding.progressBar.hide()
                        val data = result.data
                        setupOrderData(data)
                    }

                    is Result.Error -> {
                        binding.progressBar.hide()
                        showToast(result.toString())
                        finish()
                    }
                }
            }
        }
    }

    private fun observeAcceptTransaction() {
        viewModel.stateAcceptTransaction.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        binding.btnTerimas.setLoading(true)
                    }

                    is Result.Success -> {
                        binding.btnTerimas.setLoading(false)
                        showToast("Berhasil menerima transaksi")
                        setResult(RESULT_OK)
                        finish()
                    }

                    is Result.Error -> {
                        binding.btnTerimas.setLoading(false)
                        showToast(result.toString())
                    }
                }
            }
        }
    }

    private fun observeCancelTransaction() {
        viewModel.stateCancelTransaction.observe(this) { result ->
            if (result != null) {
                when (result) {
                    is Result.Loading -> {
                        bottomSheet?.setLoading(true)
                    }

                    is Result.Success -> {
                        bottomSheet?.setLoading(false)
                        bottomSheet?.dismiss()
                        showToast("Berhasil membatalkan transaksi")
                        setResult(RESULT_OK)
                        finish()
                    }

                    is Result.Error -> {
                        bottomSheet?.setLoading(false)
                        showToast(result.toString())
                    }
                }
            }
        }
    }

    private fun setupBtnListener() {
        with(binding) {
            btnTerimas.setOnClickListener {
                viewModel.acceptOrder(orderId = orderId.toString())
            }

            btnBatalkan.setOnClickListener {
                bottomSheet = CancelTransactionBottomSheet { reason, setLoading, dismiss ->
                    setLoading(true)
                    viewModel.cancelOrder(orderId = orderId.toString(), reason = reason)
                }
                bottomSheet?.show(supportFragmentManager, "CancelTransactionBottomSheet")
            }

            ivBack.setOnClickListener {
                finish()
            }
        }
    }

    private fun setupOrderData(order: Order) {
        with(binding) {
            tvOrderCode.text = order.code
            tvStatus.text = order.status.toReadableStatus()
            tvStatus.setStatusStyle(order.status)

            tvName.text = order.user?.name
            tvNotel.text = order.user?.noTelp
            tvAddress.text = order.user?.alamat
            tvDate.text = order.date

            tvMobil.text = order.mobil?.merk

            val hargaPerHari = order.mobil?.hargaPerHari
            val totalHari = DateHelper.getTotalDaysFromRange(order.date)

            tvHarga.text = hargaPerHari?.toRupiah()
            tvTotalHari.text = DateHelper.getTotalDaysFromRange(order.date).toString()
            tvTotal.text = (hargaPerHari?.times(totalHari))?.toRupiah()
            tvMetodePembayaran.text = order.metodePembayaran

            if (order.buktiTransfer.isNullOrEmpty()) {
                ivPreview.hide()
            } else {
                ivPreview.show()
            }

            btnTerimas.hide()
            btnBatalkan.hide()
            llDibatalkanOleh.hide()
            llDibatalkanKarena.hide()
            llDibatalkanTanggal.hide()

            Glide.with(ivPreview.context)
                .load(order.buktiTransfer)
                .placeholder(R.drawable.ic_upload)
                .centerCrop()
                .into(ivPreview)

            when (order.status) {
                "menunggu_konfirmasi_admin" -> {
                    btnTerimas.show()
                    btnBatalkan.show()
                }
                "dibatalkan" -> {
                    tvDibatalkan.text = order.cancelBy
                    tvDibatalkanKarena.text = order.cancelReason
                    tvDibatalkanTanggal.text = DateHelper.formatFirebaseTimestamp(order.updatedAt)

                    llDibatalkanOleh.show()
                    llDibatalkanKarena.show()
                    llDibatalkanTanggal.show()
                }
            }
        }
    }

    private fun receiveIntentFromMain() {
        orderId = intent.getStringExtra(EXTRA_ORDER_ID)
    }

    companion object {
        const val EXTRA_ORDER_ID = "extra_order_id"
    }
}