package com.jefri.carrent.ui.admin.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Chat
import com.jefri.carrent.data.repository.AdminRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ChatAdminViewModel(
    private val adminRepository: AdminRepository
) : ViewModel() {

    private val _chatList = MutableStateFlow<Result<List<Pair<String, Chat>>>>(
        Result.Loading)
    val chatList: StateFlow<Result<List<Pair<String, Chat>>>> = _chatList

    fun loadUserChats(userId: String) {
        viewModelScope.launch {
            adminRepository.getUserChats(userId).collectLatest { result ->
                _chatList.value = result
            }
        }
    }

    fun getUserId() = adminRepository.getCurrentUser()?.uid
}