package com.jefri.carrent.utils.ext

import java.text.NumberFormat
import java.util.Locale

fun Long.toRupiah(): String {
    val localeID = Locale.forLanguageTag("id-ID")
    val format = NumberFormat.getCurrencyInstance(localeID)
    format.minimumFractionDigits = 0
    format.maximumFractionDigits = 0
    return format.format(this)
}

fun Long.toRupiahWithoutSymbol(): String {
    val format = NumberFormat.getNumberInstance(Locale("id", "ID"))
    return format.format(this)
}
