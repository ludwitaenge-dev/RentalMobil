package com.jefri.carrent.ui.admin.user

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.jefri.carrent.data.model.User
import com.jefri.carrent.databinding.ItemUserBinding

class UserAdapter(
    private val onToggle: (User, Boolean) -> Unit
) : ListAdapter<User, UserAdapter.UserViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val binding = ItemUserBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return UserViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class UserViewHolder(private val binding: ItemUserBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(user: User) {
            with(binding) {
                tvName.text = user.name
                tvEmail.text = user.email

                switchActive.setOnCheckedChangeListener(null)
                switchActive.isChecked = !user.isDeleted

                switchActive.isClickable = !user.isUpdating
                switchActive.isFocusable = !user.isUpdating

                progressSmall.visibility =
                    if (user.isUpdating) View.VISIBLE else View.GONE

                switchActive.isEnabled = !user.isUpdating

                switchActive.setOnCheckedChangeListener { _, isChecked ->
                    onToggle(user, isChecked)
                }
            }
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<User>() {
            override fun areItemsTheSame(o: User, n: User) =
                o.uid == n.uid

            override fun areContentsTheSame(o: User, n: User) =
                o == n
        }
    }
}
