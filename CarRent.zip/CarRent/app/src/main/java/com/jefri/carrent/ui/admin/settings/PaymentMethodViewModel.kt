package com.jefri.carrent.ui.admin.settings

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.PaymentMethod
import com.jefri.carrent.data.repository.AdminRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch

class PaymentMethodViewModel(private val adminRepository: AdminRepository) : ViewModel() {

    private val _paymentMethods = MutableLiveData<Result<List<PaymentMethod>>>()
    val paymentMethods: LiveData<Result<List<PaymentMethod>>> = _paymentMethods

    private val _updateResult = MutableLiveData<Result<String>>()
    val updateResult: LiveData<Result<String>> = _updateResult

    fun getPaymentMethods() {
        _paymentMethods.value = Result.Loading
        viewModelScope.launch {
            _paymentMethods.value = adminRepository.getPaymentMethods()
        }
    }

    fun updatePaymentNumber(id: String, number: String) {
        _updateResult.value = Result.Loading
        viewModelScope.launch {
            val result = adminRepository.updatePaymentNumber(id, number)
            _updateResult.value = result
            if (result is Result.Success) {
                getPaymentMethods()
            }
        }
    }
}
