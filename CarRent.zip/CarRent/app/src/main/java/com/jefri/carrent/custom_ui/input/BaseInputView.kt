package com.jefri.carrent.custom_ui.input

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.widget.addTextChangedListener
import com.jefri.carrent.databinding.ViewCustomInputBinding

abstract class BaseInputView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr) {

    protected val binding = ViewCustomInputBinding.inflate(LayoutInflater.from(context), this, true)
    protected val til = binding.tilInput
    protected val et = binding.etInput

    abstract fun validate(): Boolean

    init {
        setupErrorClearOnTyping()
    }

    private fun setupErrorClearOnTyping() {
        et.addTextChangedListener {
            if (til.error != null) {
                showError(null)
            }
        }
    }

    fun setText(text: String?) {
        et.setText(text)
    }

    open fun getText(): String = et.text?.toString()?.trim().orEmpty()

    fun setHint(text: String) {
        et.hint = text
    }

    fun showError(message: String?) {
        til.error = message
    }
}