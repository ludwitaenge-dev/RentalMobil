package com.jefri.carrent.ui.user.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Chat
import com.jefri.carrent.data.repository.UserRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ChatViewModel(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _chatList = MutableStateFlow<Result<List<Pair<String, Chat>>>>(Result.Loading)
    val chatList: StateFlow<Result<List<Pair<String, Chat>>>> = _chatList

    fun loadUserChats(userId: String) {
        viewModelScope.launch {
            userRepository.getUserChats(userId).collectLatest { result ->
                _chatList.value = result
            }
        }
    }

    fun getUserId() = userRepository.getCurrentUser()?.uid


}