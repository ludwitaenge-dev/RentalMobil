package com.jefri.carrent.data.model

import android.os.Parcelable
import com.google.firebase.Timestamp
import kotlinx.parcelize.Parcelize

@Parcelize
data class Order(
    val id: String = "",
    val code: String = "",
    val user: User? = null,
    val mobil: Mobil? = null,
    val address: String = "",
    val date: String = "",
    val status: String = "",
    val metodePembayaran: String = "",
    val nomorPembayaran: String = "",
    val buktiTransfer: String? = null,
    val cancelBy: String? = null,
    val cancelReason: String? = null,
    val rating: Int? = null,
    val mitraAlamat: String? = null,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) : Parcelable


