package com.jefri.carrent.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.jefri.carrent.R
import com.jefri.carrent.data.model.Mobil
import com.jefri.carrent.databinding.ItemMobilBinding
import com.jefri.carrent.utils.ext.hide
import com.jefri.carrent.utils.ext.show
import com.jefri.carrent.utils.ext.toRupiah

class MobilAdapter(
    private val onClick: (Mobil) -> Unit
) :
    ListAdapter<Mobil, MobilAdapter.MobilViewHolder>(DIFF_CALLBACK) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MobilViewHolder {
        val binding = ItemMobilBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MobilViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MobilViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class MobilViewHolder(private val binding: ItemMobilBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(mobil: Mobil) {
            with(binding) {
                Glide.with(binding.imgMobil.context)
                    .load(mobil.fotoUrl)
                    .placeholder(R.drawable.bg_image_placeholder)
                    .centerCrop()
                    .into(binding.imgMobil)

                tvNamaMobil.text = mobil.merk
                tvHarga.text = mobil.hargaPerHari.toRupiah() + "/ Hari"
                tvMitra.text = mobil.mitraName
                tvRating.text = mobil.averageRating.toString()

                if (mobil.isBooked) {
                    tvStatusLabel.show()
                } else {
                    tvStatusLabel.hide()
                }

                root.setOnClickListener {
                    if (!mobil.isBooked) onClick(mobil)
                }
            }
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Mobil>() {
            override fun areItemsTheSame(oldItem: Mobil, newItem: Mobil): Boolean =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: Mobil, newItem: Mobil): Boolean =
                oldItem == newItem
        }
    }
}