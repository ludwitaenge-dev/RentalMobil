// Mendefinisikan package lokasi file SelectRoleViewModel
package com.jefri.carrent.ui.auth.role

// Import LiveData untuk mengamati perubahan data secara lifecycle-aware
import androidx.lifecycle.LiveData
// Import MutableLiveData untuk menyimpan dan mengubah nilai data
import androidx.lifecycle.MutableLiveData
// Import ViewModel sebagai kelas dasar arsitektur MVVM
import androidx.lifecycle.ViewModel

// Mendeklarasikan class SelectRoleViewModel yang mewarisi ViewModel
class SelectRoleViewModel : ViewModel() {

    // MutableLiveData untuk menyimpan role yang dipilih (private agar tidak bisa diubah dari luar)
    private val _selectedRole = MutableLiveData<Int>()
    
    // LiveData publik untuk di-observe oleh Activity/Fragment (read-only)
    val selectedRole: LiveData<Int> = _selectedRole

    // Fungsi untuk mengubah role yang digunakan di Activity
    fun selectRole(role: String) {
        
        // Mengubah nilai LiveData berdasarkan role yang dipilih
        _selectedRole.value = when (role) {
            
            "user" -> 1      // Jika role user, disimpan sebagai kode 1
            "vendor" -> 2    // Jika role vendor/mitra, disimpan sebagai kode 2
            "admin" -> 3     // Jika role admin, disimpan sebagai kode 3
            
            else -> 1        // Default ke user jika tidak dikenali
        }
    }

}