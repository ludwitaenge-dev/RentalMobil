package com.jefri.carrent.ui.user.add_transaction.add_data

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.datepicker.MaterialDatePicker
import com.jefri.carrent.R
import com.jefri.carrent.custom_ui.bottom_sheet.PaymentMethodBottomSheet
import com.jefri.carrent.data.model.Mobil
import com.jefri.carrent.data.model.Muatan
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.model.User
import com.jefri.carrent.databinding.ActivityAddTransactionDataBinding
import com.jefri.carrent.ui.ViewModelFactory
import com.jefri.carrent.ui.user.add_transaction.overview.OverviewTransactionActivity
import com.jefri.carrent.utils.ext.showToast
import com.jefri.carrent.utils.helpers.OrderHelper
import com.jefri.carrent.utils.result.Result
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AddTransactionDataActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddTransactionDataBinding
    private lateinit var user: User
    private var selectedPaymentNumber: String = ""

    private val addTransactionDataViewModel by viewModels<AddTransactionViewModel> {
        ViewModelFactory.getInstance(this)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.primary_blue)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        binding = ActivityAddTransactionDataBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        init()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun init() {
        observeUserData()
        setupBtnListener()
    }

    private fun observeUserData() {
        addTransactionDataViewModel.user.observe(this) { result ->
            when (result) {
                is Result.Loading -> {
                    binding.btnNext.isEnabled = false
                }
                is Result.Success -> {
                    binding.btnNext.isEnabled = true
                    user = result.data!!
                    binding.etName.setText(user.name)
                    binding.etNomorTelepon.setText(user.noTelp)
                    binding.etAlamat.setText(user.alamat)
                }
                is Result.Error -> {
                    binding.btnNext.isEnabled = true
                    showToast("Gagal ambil data user: ${result.message}")
                }
            }
        }
    }

    private fun receiveExtraMobil(): Mobil? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_MOBIL, Mobil::class.java)
        } else {
            intent.getParcelableExtra<Mobil>(EXTRA_MOBIL)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun setupBtnListener() {
        with (binding) {
            btnNext.setOnClickListener {
                val isValid = etName.validate() and
                        etNomorTelepon.validate() and
                        etAlamat.validate() and
                        etTanggal.text.toString().isNotEmpty() and
                        etMetodePembayaran.text.toString().isNotEmpty()

                if (!isValid) return@setOnClickListener

                val nama = etName.getText()
                val noTel = etNomorTelepon.getText()
                val address = etAlamat.getText()
                val date = etTanggal.text.toString()
                val metodePembayaran = etMetodePembayaran.text.toString()

                val selectedMobil = receiveExtraMobil()

                val order = Order(
                    code = OrderHelper.generateOrderCode(),
                    user = user,
                    mobil = selectedMobil,
                    address = address,
                    date = date,
                    metodePembayaran = metodePembayaran,
                    nomorPembayaran = selectedPaymentNumber,
                    status = "belum_dibayar",
                )

                val intent =
                    Intent(this@AddTransactionDataActivity, OverviewTransactionActivity::class.java)
                intent.putExtra("order", order)
                intent.putExtra("nama", nama)
                intent.putExtra("noTel", noTel)
                startActivity(intent)
            }

            etMetodePembayaran.setOnClickListener {
                val bottomSheet = PaymentMethodBottomSheet { selected ->
                    binding.etMetodePembayaran.setText(selected.name)
                    selectedPaymentNumber = selected.number
                }
                bottomSheet.show(supportFragmentManager, PAYMENT_BOTTOM_SHEET_TAG)
            }

            etTanggal.setOnClickListener {
                val picker = MaterialDatePicker.Builder.dateRangePicker()
                    .setTitleText("Pilih Rentang Tanggal")
                    .setSelection(
                        androidx.core.util.Pair(
                            MaterialDatePicker.todayInUtcMilliseconds(),
                            MaterialDatePicker.todayInUtcMilliseconds()
                        )
                    )
                    .build()

                picker.addOnPositiveButtonClickListener { selection ->
                    val startDate = selection.first
                    val endDate = selection.second

                    val sdf = SimpleDateFormat("dd MMM yyyy", Locale("id", "ID"))
                    val start = sdf.format(Date(startDate ?: 0))
                    val end = sdf.format(Date(endDate ?: 0))

                    etTanggal.setText("$start - $end")
                }

                picker.show(supportFragmentManager, "dateRangePicker")
            }

            ivBack.setOnClickListener {
                finish()
            }
        }
    }

    companion object {
        private const val PAYMENT_BOTTOM_SHEET_TAG = "PaymentMethodBottomSheet"
        const val EXTRA_MOBIL = "extra_mobil"
    }
}