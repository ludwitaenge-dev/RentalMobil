package com.jefri.carrent.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class PaymentMethod(
    val id: String = "",
    val name: String = "",
    val number: String = ""
) : Parcelable