package com.jefri.carrent.di

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.jefri.carrent.data.repository.AdminRepository
import com.jefri.carrent.data.repository.AuthenticationRepository
import com.jefri.carrent.data.repository.MitraRepository
import com.jefri.carrent.data.repository.UserRepository
import com.jefri.carrent.data.services.datastore.UserPreferences
import com.jefri.carrent.data.services.datastore.dataStore
import com.jefri.carrent.data.services.firebase.AuthService
import com.jefri.carrent.data.services.firebase.ChatService
import com.jefri.carrent.data.services.firebase.MobilService
import com.jefri.carrent.data.services.firebase.NotificationService
import com.jefri.carrent.data.services.firebase.OrderService
import com.jefri.carrent.data.services.firebase.PaymentService

object Injection {

    fun provideAuthRepository(context: Context): AuthenticationRepository {
        val preferences = UserPreferences.getInstance(context.dataStore)
        val firebaseAuth = FirebaseAuth.getInstance()
        val firestore = FirebaseFirestore.getInstance()
        val firebaseStorage = FirebaseStorage.getInstance()
        val firebaseAuthService = AuthService(firebaseAuth, firestore, firebaseStorage)
        return AuthenticationRepository.getInstance(firebaseAuthService, preferences)
    }

    fun provideUserRepository(): UserRepository {
        val firebaseAuth = FirebaseAuth.getInstance()
        val firestore = FirebaseFirestore.getInstance()
        val firebaseDatabase = FirebaseDatabase.getInstance()
        val firebaseStorage = FirebaseStorage.getInstance()

        val firebaseAuthService = AuthService(firebaseAuth, firestore, firebaseStorage)
        val mobilService = MobilService(firestore, firebaseStorage)
        val orderService = OrderService(firestore, firebaseStorage)
        val chatService = ChatService(firebaseDatabase)
        val notificationService = NotificationService(firestore, firebaseAuth)
        val paymentService = PaymentService(firestore)

        return UserRepository.getInstance(
            firebaseAuthService,
            chatService,
            mobilService,
            orderService,
            notificationService,
            paymentService
        )
    }

    fun provideAdminRepository(): AdminRepository {
        val firebaseAuth = FirebaseAuth.getInstance()
        val firestore = FirebaseFirestore.getInstance()
        val firebaseDatabase = FirebaseDatabase.getInstance()
        val firebaseStorage = FirebaseStorage.getInstance()

        val firebaseAuthService = AuthService(firebaseAuth, firestore, firebaseStorage)
        val orderService = OrderService(firestore, firebaseStorage)
        val chatService = ChatService(firebaseDatabase)
        val notificationService = NotificationService(firestore, firebaseAuth)
        val paymentService = PaymentService(firestore)

        return AdminRepository.getInstance(
            firebaseAuthService,
            chatService,
            orderService,
            notificationService,
            paymentService
        )
    }

    fun provideMitraRepository(): MitraRepository {
        val firebaseAuth = FirebaseAuth.getInstance()
        val firestore = FirebaseFirestore.getInstance()
        val firebaseDatabase = FirebaseDatabase.getInstance()
        val firebaseStorage = FirebaseStorage.getInstance()

        val firebaseAuthService = AuthService(firebaseAuth, firestore, firebaseStorage)
        val mobilService = MobilService(firestore, firebaseStorage)
        val orderService = OrderService(firestore, firebaseStorage)
        val chatService = ChatService(firebaseDatabase)
        val notificationService = NotificationService(firestore, firebaseAuth)

        return MitraRepository.getInstance(
            firebaseAuthService,
            chatService,
            mobilService,
            orderService,
            notificationService
        )
    }

}