// Mendefinisikan package lokasi file RegisterViewModel
package com.jefri.carrent.ui.auth.register

// Import LiveData untuk mengamati perubahan data secara lifecycle-aware
import androidx.lifecycle.LiveData
// Import MutableLiveData untuk mengubah nilai LiveData
import androidx.lifecycle.MutableLiveData
// Import ViewModel sebagai kelas dasar ViewModel
import androidx.lifecycle.ViewModel
// Import viewModelScope untuk menjalankan coroutine sesuai lifecycle ViewModel
import androidx.lifecycle.viewModelScope
// Import AuthenticationRepository sebagai penghubung ke sumber data (Firebase/API/database)
import com.jefri.carrent.data.repository.AuthenticationRepository
// Import coroutine launch untuk menjalankan proses asynchronous
import kotlinx.coroutines.launch
// Import sealed class Result untuk menangani state (Loading, Success, Error)
import com.jefri.carrent.utils.result.Result

// Mendeklarasikan class RegisterViewModel yang mewarisi ViewModel
class RegisterViewModel(

    // Dependency Injection repository untuk menangani proses autentikasi
    private val authenticationRepository: AuthenticationRepository

) : ViewModel() {

    // MutableLiveData untuk menyimpan dan mengubah state registrasi (private, hanya bisa diubah di ViewModel)
    private val _registerState = MutableLiveData<Result<String?>>()
    
    // LiveData publik yang bisa di-observe oleh Activity (read-only dari luar)
    val registerState: LiveData<Result<String?>>
        get() = _registerState

    // Fungsi register untuk mendaftarkan pengguna baru
    fun register(
        name: String,       // Parameter nama pengguna
        email: String,      // Parameter email pengguna
        password: String,   // Parameter password pengguna
        role: String,       // Parameter role (admin/user/mitra)
    ) = viewModelScope.launch {   // Menjalankan coroutine dalam lifecycle ViewModel
        
        // Mengubah state menjadi Loading sebelum proses registrasi dimulai
        _registerState.value = Result.Loading

        // Memanggil fungsi register pada repository
        // Biasanya akan membuat akun baru di Firebase Authentication
        // dan menyimpan data tambahan ke Firestore/Realtime Database
        val result = authenticationRepository.register(name, email, password, role)
        
        // Mengirim hasil registrasi (Success atau Error) ke LiveData
        _registerState.value = result
    }

}