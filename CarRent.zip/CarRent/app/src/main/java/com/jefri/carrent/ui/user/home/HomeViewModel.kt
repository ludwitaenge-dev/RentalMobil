package com.jefri.carrent.ui.user.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jefri.carrent.data.model.Muatan
import com.jefri.carrent.data.model.Order
import com.jefri.carrent.data.model.User
import com.jefri.carrent.data.repository.UserRepository
import com.jefri.carrent.utils.result.Result
import kotlinx.coroutines.launch
import java.util.Calendar

class HomeViewModel(
    private val userRepository: UserRepository,
) : ViewModel() {

    private val _muatanData = MutableLiveData<Result<List<User>>>()
    val muatanData: LiveData<Result<List<User>>> get() = _muatanData

    private val _orderData = MutableLiveData<Result<List<Order>>>()
    val orderData: LiveData<Result<List<Order>>> get() = _orderData

    private val _user = MutableLiveData<Result<User?>>()
    val user: LiveData<Result<User?>>
        get() = _user

    private val _isRefreshing = MediatorLiveData<Boolean>().apply { value = false }
    val isRefreshing: LiveData<Boolean> get() = _isRefreshing

    init {
        _isRefreshing.addSource(_orderData) { updateRefreshing() }
        _isRefreshing.addSource(_muatanData) { updateRefreshing() }

        getUserData()
        getOrderActiveData()
        getMuatanData()
    }

    private fun getOrderActiveData() {
        viewModelScope.launch {
            _orderData.value = Result.Loading
            val result = userRepository.getOrdersActiveData()
            _orderData.value = result
        }
    }

    private fun getMuatanData() {
        viewModelScope.launch {
            _muatanData.value = Result.Loading
            val result = userRepository.getMitraActiveData()
            _muatanData.value = result
        }
    }

    fun getUserData() {
        _user.value = Result.Loading

        viewModelScope.launch {
            try {
                _user.value = Result.Success(userRepository.getUserDataFromFirestore())
            } catch (e: Exception) {
                _user.value = Result.Error(e.message.toString())
            }
        }
    }

    private fun updateRefreshing() {
        val loadingOrder  = _orderData.value is Result.Loading
        val loadingMuatan = _muatanData.value is Result.Loading

        _isRefreshing.value = loadingOrder || loadingMuatan
    }

    fun refreshAll() {
        getOrderActiveData()
        getMuatanData()
    }

    fun getGreetingText(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 4..10 -> "Selamat Pagi,"
            in 11..14 -> "Selamat Siang,"
            in 15..17 -> "Selamat Sore,"
            else -> "Selamat Malam,"
        }
    }
}